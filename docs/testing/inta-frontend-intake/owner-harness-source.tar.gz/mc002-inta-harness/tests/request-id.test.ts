import { describe, expect, it } from 'vitest'
import { RequestIdGenerator } from '../src/request-id.js'

describe('RequestIdGenerator', () => {
  it('generates monotonic request IDs formatted as mc-int-<runId>-<caseId>-<seq>', () => {
    const gen = new RequestIdGenerator('runABC1234')
    const id1 = gen.next('T1')
    const id2 = gen.next('T1')
    const id3 = gen.next('T2')

    expect(id1).toBe('mc-int-runABC1234-T1-1')
    expect(id2).toBe('mc-int-runABC1234-T1-2')
    expect(id3).toBe('mc-int-runABC1234-T2-3')
    expect(id1.length).toBeLessThanOrEqual(128)
  })
})
