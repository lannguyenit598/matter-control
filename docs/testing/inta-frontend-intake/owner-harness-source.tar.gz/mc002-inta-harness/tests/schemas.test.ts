import { describe, expect, it } from 'vitest'
import {
  harnessCaseInputSchema,
  nativeUserSchema,
  ALLOWED_CASE_IDS,
} from '../src/schemas.js'

describe('harnessCaseInputSchema', () => {
  const valid = {
    runId: 'run12345678',
    caseId: 'T1',
  }

  it('accepts valid runId and caseId without refId', () => {
    const res = harnessCaseInputSchema.safeParse(valid)
    expect(res.success).toBe(true)
  })

  it('accepts valid refId when it is a lowercase canonical UUID', () => {
    const res = harnessCaseInputSchema.safeParse({
      ...valid,
      caseId: 'T2',
      refId: '0192e23b-6e9f-7b71-91ea-42b7e199db1c',
    })
    expect(res.success).toBe(true)
  })

  it('rejects refId if uppercase or malformed', () => {
    const resUpper = harnessCaseInputSchema.safeParse({
      ...valid,
      caseId: 'T2',
      refId: '0192E23B-6E9F-7B71-91EA-42B7E199DB1C',
    })
    expect(resUpper.success).toBe(false)

    const resMalformed = harnessCaseInputSchema.safeParse({
      ...valid,
      caseId: 'T2',
      refId: 'not-a-uuid',
    })
    expect(resMalformed.success).toBe(false)
  })

  it('rejects runId shorter than 8 or longer than 32 chars or with special characters', () => {
    expect(harnessCaseInputSchema.safeParse({ ...valid, runId: 'short' }).success).toBe(false)
    expect(harnessCaseInputSchema.safeParse({ ...valid, runId: 'a'.repeat(33) }).success).toBe(false)
    expect(harnessCaseInputSchema.safeParse({ ...valid, runId: 'invalid-char!' }).success).toBe(false)
  })

  it('allows all approved case IDs in allowlist', () => {
    for (const c of ALLOWED_CASE_IDS) {
      expect(harnessCaseInputSchema.safeParse({ ...valid, caseId: c }).success).toBe(true)
    }
  })

  it('rejects unknown caseId', () => {
    expect(harnessCaseInputSchema.safeParse({ ...valid, caseId: 'UNKNOWN_99' }).success).toBe(false)
    expect(harnessCaseInputSchema.safeParse({ ...valid, caseId: 'DELETE_USER' }).success).toBe(false)
  })

  it('rejects input with extra caller-controlled fields (strict object)', () => {
    expect(
      harnessCaseInputSchema.safeParse({
        ...valid,
        extraProxyHeader: 'foo',
      }).success,
    ).toBe(false)
  })
})

describe('nativeUserSchema', () => {
  it('validates Go native user payload', () => {
    const user = {
      id: '0192e23b-6e9f-7b71-91ea-42b7e199db1c',
      email: 'inta-a-run12345678@example.test',
      name: 'INTA_A_INITIAL',
      version: 1,
      createdAt: '2026-10-25T03:00:00Z',
      updatedAt: '2026-10-25T03:00:00Z',
    }
    const res = nativeUserSchema.safeParse(user)
    expect(res.success).toBe(true)
  })
})
