import { describe, expect, it } from 'vitest'
import { validateHarnessEnvironment, PRODUCT_AUTH_ENV_KEYS } from '../src/guards.js'

describe('validateHarnessEnvironment', () => {
  const cleanEnv = {
    MC_INTA_ENABLE: '1',
    NODE_ENV: 'development',
    MC_INTA_GO_BASE_URL: 'http://127.0.0.1:18086',
  }

  it('passes with clean development environment and MC_INTA_ENABLE=1', () => {
    const result = validateHarnessEnvironment(cleanEnv)
    expect(result.ok).toBe(true)
    if (result.ok) {
      expect(result.goBaseUrl).toBe('http://127.0.0.1:18086')
    }
  })

  it('fails with NOT_ENABLED (404) when MC_INTA_ENABLE is missing or not 1', () => {
    const r1 = validateHarnessEnvironment({ ...cleanEnv, MC_INTA_ENABLE: undefined })
    expect(r1.ok).toBe(false)
    if (!r1.ok) {
      expect(r1.status).toBe(404)
      expect(r1.reason).toContain('MC_INTA_ENABLE')
    }

    const r2 = validateHarnessEnvironment({ ...cleanEnv, MC_INTA_ENABLE: '0' })
    expect(r2.ok).toBe(false)
    if (!r2.ok) {
      expect(r2.status).toBe(404)
    }
  })

  it('refuses execution when NODE_ENV is production (403)', () => {
    const result = validateHarnessEnvironment({ ...cleanEnv, NODE_ENV: 'production' })
    expect(result.ok).toBe(false)
    if (!result.ok) {
      expect(result.status).toBe(403)
      expect(result.reason).toContain('production')
    }
  })

  it.each(PRODUCT_AUTH_ENV_KEYS)('refuses execution when product env %s is set (403)', (key) => {
    const envWithAuth = { ...cleanEnv, [key]: 'some-secret-or-mode' }
    const result = validateHarnessEnvironment(envWithAuth)
    expect(result.ok).toBe(false)
    if (!result.ok) {
      expect(result.status).toBe(403)
      expect(result.refusedKeys).toContain(key)
    }
  })

  it('enforces fixed Go base URL http://127.0.0.1:18086', () => {
    const result = validateHarnessEnvironment({ ...cleanEnv, MC_INTA_GO_BASE_URL: 'http://example.com' })
    expect(result.ok).toBe(false)
    if (!result.ok) {
      expect(result.status).toBe(403)
      expect(result.reason).toContain('127.0.0.1:18086')
    }
  })
})
