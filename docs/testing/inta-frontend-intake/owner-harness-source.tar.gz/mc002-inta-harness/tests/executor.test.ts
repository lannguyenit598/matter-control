import { describe, expect, it, vi, afterEach } from 'vitest'
import { executeCase } from '../src/executor.js'
import { RequestIdGenerator } from '../src/request-id.js'

describe('executor', () => {
  const runId = 'runTest1234'
  const goBaseUrl = 'http://127.0.0.1:18086'

  afterEach(() => {
    vi.restoreAllMocks()
  })

  it('executes T1 via app-client mode calling POST /api/v1/users with userA fixture', async () => {
    const fakeUserA = {
      id: '0192e23b-6e9f-7b71-91ea-42b7e199db1c',
      email: `inta-a-${runId}@example.test`,
      name: 'INTA_A_INITIAL',
      version: 1,
      createdAt: '2026-10-25T03:00:00Z',
      updatedAt: '2026-10-25T03:00:00Z',
    }

    const fetchMock = vi.fn().mockResolvedValue({
      ok: true,
      status: 201,
      text: async () => JSON.stringify(fakeUserA),
    })
    vi.stubGlobal('fetch', fetchMock)

    const reqIdGen = new RequestIdGenerator(runId)
    const result = await executeCase({
      runId,
      caseId: 'T1',
      reqIdGen,
      goBaseUrl,
      nextVersion: '16.4.2',
    })

    expect(result.substeps).toHaveLength(1)
    const step = result.substeps[0]
    expect(step.caseId).toBe('T1')
    expect(step.mode).toBe('app-client')
    expect(step.method).toBe('POST')
    expect(step.routeTemplate).toBe('/api/v1/users')
    expect(step.outcome).toBe('value')
    expect(step.value).toEqual(fakeUserA)
    expect(step.wire?.note).toBe('not-observable-via-client')

    expect(fetchMock).toHaveBeenCalledTimes(1)
    const callUrl = fetchMock.mock.calls[0][0].toString()
    expect(callUrl).toBe('http://127.0.0.1:18086/api/v1/users')
  })

  it('executes T4 with two substeps (malformed and uppercase UUIDs)', async () => {
    const fetchMock = vi.fn().mockResolvedValue({
      ok: false,
      status: 404,
      text: async () => JSON.stringify({ title: 'Not Found', status: 404 }),
    })
    vi.stubGlobal('fetch', fetchMock)

    const reqIdGen = new RequestIdGenerator(runId)
    const result = await executeCase({
      runId,
      caseId: 'T4',
      reqIdGen,
      goBaseUrl,
      nextVersion: '16.4.2',
    })

    expect(result.substeps).toHaveLength(2)
    expect(result.substeps[0].requestId).not.toBe(result.substeps[1].requestId)
    expect(result.substeps[0].outcome).toBe('error')
    expect(result.substeps[0].apiError?.code).toBe('NOT_FOUND')
    expect(result.substeps[1].outcome).toBe('error')
    expect(result.substeps[1].apiError?.code).toBe('NOT_FOUND')
    expect(fetchMock).toHaveBeenCalledTimes(2)
  })

  it('executes W1 via wire mode capturing status and headers', async () => {
    const fetchMock = vi.fn().mockResolvedValue({
      ok: true,
      status: 201,
      headers: new Headers({
        'content-type': 'application/json',
        location: '/api/v1/users/0192e23b-6e9f-7b71-91ea-42b7e199db1d',
        etag: '"1"',
        'x-request-id': 'mc-int-runTest1234-W1-1',
      }),
      text: async () => JSON.stringify({ id: '0192e23b-6e9f-7b71-91ea-42b7e199db1d', name: 'INTA_B_INITIAL' }),
    })
    vi.stubGlobal('fetch', fetchMock)

    const reqIdGen = new RequestIdGenerator(runId)
    const result = await executeCase({
      runId,
      caseId: 'W1',
      reqIdGen,
      goBaseUrl,
      nextVersion: '16.4.2',
    })

    expect(result.substeps).toHaveLength(1)
    const step = result.substeps[0]
    expect(step.caseId).toBe('W1')
    expect(step.mode).toBe('wire')
    expect(step.wire?.status).toBe(201)
    expect(step.wire?.headers?.location).toBe('/api/v1/users/0192e23b-6e9f-7b71-91ea-42b7e199db1d')
    expect(step.wire?.headers?.etag).toBe('"1"')
  })
})
