import { describe, expect, it } from 'vitest'
import { buildHarnessEnvelope, MAX_RETAINED_BODY_BYTES } from '../src/envelope.js'

describe('buildHarnessEnvelope', () => {
  it('caps retained body at 16KiB and sets truncated flag', () => {
    const smallData = { foo: 'bar' }
    const envSmall = buildHarnessEnvelope({
      runId: 'run12345678',
      caseId: 'T1',
      requestId: 'mc-int-run12345678-T1-1',
      mode: 'app-client',
      method: 'POST',
      routeTemplate: '/api/v1/users',
      startedAtUTC: '2026-10-25T03:00:00Z',
      latencyMs: 12,
      actualNextVersion: '16.4.2',
      harnessRevision: 'INTA-1',
      outcome: 'value',
      value: smallData,
      apiError: null,
      wire: null,
    })

    expect(envSmall.truncated).toBe(false)
    expect(envSmall.value).toEqual(smallData)

    const bigString = 'x'.repeat(MAX_RETAINED_BODY_BYTES + 500)
    const envBig = buildHarnessEnvelope({
      runId: 'run12345678',
      caseId: 'T1',
      requestId: 'mc-int-run12345678-T1-2',
      mode: 'wire',
      method: 'GET',
      routeTemplate: '/api/v1/users/{id}',
      startedAtUTC: '2026-10-25T03:00:00Z',
      latencyMs: 15,
      actualNextVersion: '16.4.2',
      harnessRevision: 'INTA-1',
      outcome: 'value',
      value: bigString,
      apiError: null,
      wire: {
        status: 200,
        headers: { 'content-type': 'application/json' },
      },
    })

    expect(envBig.truncated).toBe(true)
    expect(typeof envBig.value).toBe('string')
    expect((envBig.value as string).length).toBeLessThanOrEqual(MAX_RETAINED_BODY_BYTES)
  })
})
