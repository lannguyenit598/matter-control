import { httpRequest, ApiError } from '/tmp/mc002-inta-fe/src/lib/api/http-client'
import { buildHarnessEnvelope, type HarnessEnvelope } from './envelope'
import {
  getFixturesForRun,
  FIXED_MISSING_UUID,
  T4_MALFORMED_LITERAL,
  T4_UPPERCASE_LITERAL,
} from './fixtures'
import { nativeUserSchema, type CaseId } from './schemas'
import type { RequestIdGenerator } from './request-id'

export type ExecuteParams = {
  runId: string
  caseId: CaseId
  refId?: string
  reqIdGen: RequestIdGenerator
  goBaseUrl: string
  nextVersion: string
}

export type ExecutionResult = {
  runId: string
  caseId: CaseId
  substeps: HarnessEnvelope[]
}

const WIRE_HEADER_ALLOWLIST = [
  'content-type',
  'location',
  'etag',
  'x-request-id',
  'retry-after',
]

async function runClientSubstep(params: {
  runId: string
  caseId: string
  requestId: string
  method: string
  url: string
  routeTemplate: string
  body?: unknown
  headers?: Record<string, string>
  schema?: any
  nextVersion: string
}): Promise<HarnessEnvelope> {
  const startedAtUTC = new Date().toISOString()
  const startMs = Date.now()
  let outcome: 'value' | 'error' | 'aborted' = 'value'
  let value: unknown = null
  let apiError: HarnessEnvelope['apiError'] = null

  try {
    const data = await httpRequest(params.url, {
      method: params.method as any,
      body: params.body,
      headers: {
        ...params.headers,
        'X-Request-ID': params.requestId,
      },
      schema: params.schema,
      init: { cache: 'no-store' },
    })
    value = data
  } catch (err: any) {
    outcome = 'error'
    if (err instanceof ApiError) {
      apiError = {
        status: err.status,
        code: err.code,
        message: err.message,
        details: err.details,
      }
    } else {
      apiError = {
        status: 0,
        code: 'NETWORK_ERROR',
        message: String(err.message ?? err),
      }
    }
  }

  const latencyMs = Date.now() - startMs
  return buildHarnessEnvelope({
    runId: params.runId,
    caseId: params.caseId,
    requestId: params.requestId,
    mode: 'app-client',
    method: params.method,
    routeTemplate: params.routeTemplate,
    startedAtUTC,
    latencyMs,
    actualNextVersion: params.nextVersion,
    harnessRevision: 'INTA-1',
    outcome,
    value,
    apiError,
    wire: {
      status: null,
      headers: null,
      note: 'not-observable-via-client',
    },
    truncated: false,
  })
}

async function runWireSubstep(params: {
  runId: string
  caseId: string
  requestId: string
  method: string
  url: string
  routeTemplate: string
  body?: BodyInit
  headers?: Record<string, string>
  nextVersion: string
}): Promise<HarnessEnvelope> {
  const startedAtUTC = new Date().toISOString()
  const startMs = Date.now()
  let outcome: 'value' | 'error' | 'aborted' = 'value'
  let value: unknown = null
  let apiError: HarnessEnvelope['apiError'] = null
  let wireStatus: number | null = null
  let wireHeaders: Record<string, string> = {}

  try {
    const reqHeaders = new Headers(params.headers)
    reqHeaders.set('X-Request-ID', params.requestId)

    const response = await fetch(params.url, {
      method: params.method,
      headers: reqHeaders,
      body: params.body,
      cache: 'no-store',
    })

    wireStatus = response.status
    for (const [k, v] of response.headers.entries()) {
      if (WIRE_HEADER_ALLOWLIST.includes(k.toLowerCase())) {
        wireHeaders[k.toLowerCase()] = v
      }
    }

    const text = await response.text()
    try {
      value = JSON.parse(text)
    } catch {
      value = text
    }

    if (!response.ok) {
      outcome = 'error'
      apiError = {
        status: response.status,
        code: response.status === 404 ? 'NOT_FOUND' : 'HTTP_ERROR',
        message: `HTTP ${response.status}`,
        details: value,
      }
    }
  } catch (err: any) {
    outcome = 'error'
    apiError = {
      status: 0,
      code: 'NETWORK_ERROR',
      message: String(err.message ?? err),
    }
  }

  const latencyMs = Date.now() - startMs
  return buildHarnessEnvelope({
    runId: params.runId,
    caseId: params.caseId,
    requestId: params.requestId,
    mode: 'wire',
    method: params.method,
    routeTemplate: params.routeTemplate,
    startedAtUTC,
    latencyMs,
    actualNextVersion: params.nextVersion,
    harnessRevision: 'INTA-1',
    outcome,
    value,
    apiError,
    wire: {
      status: wireStatus,
      headers: wireHeaders,
    },
    truncated: false,
  })
}

export async function executeCase(params: ExecuteParams): Promise<ExecutionResult> {
  const { runId, caseId, refId, reqIdGen, goBaseUrl, nextVersion } = params
  const f = getFixturesForRun(runId)
  const substeps: HarnessEnvelope[] = []

  switch (caseId) {
    case 'T1': {
      const envelope = await runClientSubstep({
        runId,
        caseId: 'T1',
        requestId: reqIdGen.next('T1'),
        method: 'POST',
        url: `${goBaseUrl}/api/v1/users`,
        routeTemplate: '/api/v1/users',
        body: f.userA.initial,
        schema: nativeUserSchema,
        nextVersion,
      })
      substeps.push(envelope)
      break
    }

    case 'T2': {
      if (!refId) throw new Error('T2 requires refId (User A ID)')
      const envelope = await runClientSubstep({
        runId,
        caseId: 'T2',
        requestId: reqIdGen.next('T2'),
        method: 'GET',
        url: `${goBaseUrl}/api/v1/users/${refId}`,
        routeTemplate: '/api/v1/users/{id}',
        schema: nativeUserSchema,
        nextVersion,
      })
      substeps.push(envelope)
      break
    }

    case 'T3': {
      const envelope = await runClientSubstep({
        runId,
        caseId: 'T3',
        requestId: reqIdGen.next('T3'),
        method: 'GET',
        url: `${goBaseUrl}/api/v1/users/${FIXED_MISSING_UUID}`,
        routeTemplate: '/api/v1/users/{id}',
        nextVersion,
      })
      substeps.push(envelope)
      break
    }

    case 'T4': {
      // Substep 1: malformed literal
      const step1 = await runClientSubstep({
        runId,
        caseId: 'T4',
        requestId: reqIdGen.next('T4'),
        method: 'GET',
        url: `${goBaseUrl}/api/v1/users/${T4_MALFORMED_LITERAL}`,
        routeTemplate: '/api/v1/users/{id}',
        nextVersion,
      })
      substeps.push(step1)

      // Substep 2: uppercase literal
      const step2 = await runClientSubstep({
        runId,
        caseId: 'T4',
        requestId: reqIdGen.next('T4'),
        method: 'GET',
        url: `${goBaseUrl}/api/v1/users/${T4_UPPERCASE_LITERAL}`,
        routeTemplate: '/api/v1/users/{id}',
        nextVersion,
      })
      substeps.push(step2)
      break
    }

    case 'T5': {
      const step1 = await runClientSubstep({
        runId,
        caseId: 'T5',
        requestId: reqIdGen.next('T5'),
        method: 'POST',
        url: `${goBaseUrl}/api/v1/users`,
        routeTemplate: '/api/v1/users',
        body: f.invalidT5,
        nextVersion,
      })
      substeps.push(step1)

      if (refId) {
        const step2 = await runClientSubstep({
          runId,
          caseId: 'T5',
          requestId: reqIdGen.next('T5'),
          method: 'GET',
          url: `${goBaseUrl}/api/v1/users/${refId}`,
          routeTemplate: '/api/v1/users/{id}',
          schema: nativeUserSchema,
          nextVersion,
        })
        substeps.push(step2)
      }
      break
    }

    case 'T8': {
      const step1 = await runClientSubstep({
        runId,
        caseId: 'T8',
        requestId: reqIdGen.next('T8'),
        method: 'POST',
        url: `${goBaseUrl}/api/v1/users`,
        routeTemplate: '/api/v1/users',
        body: f.duplicateA,
        nextVersion,
      })
      substeps.push(step1)

      if (refId) {
        const step2 = await runClientSubstep({
          runId,
          caseId: 'T8',
          requestId: reqIdGen.next('T8'),
          method: 'GET',
          url: `${goBaseUrl}/api/v1/users/${refId}`,
          routeTemplate: '/api/v1/users/{id}',
          schema: nativeUserSchema,
          nextVersion,
        })
        substeps.push(step2)
      }
      break
    }

    case 'T9': {
      if (!refId) throw new Error('T9 requires refId (User A ID)')
      const envelope = await runClientSubstep({
        runId,
        caseId: 'T9',
        requestId: reqIdGen.next('T9'),
        method: 'PATCH',
        url: `${goBaseUrl}/api/v1/users/${refId}`,
        routeTemplate: '/api/v1/users/{id}',
        headers: { 'If-Match': '"1"' },
        body: f.userA.updated,
        schema: nativeUserSchema,
        nextVersion,
      })
      substeps.push(envelope)
      break
    }

    case 'T10': {
      if (!refId) throw new Error('T10 requires refId (User A ID)')
      // Stale PATCH
      const step1 = await runClientSubstep({
        runId,
        caseId: 'T10',
        requestId: reqIdGen.next('T10'),
        method: 'PATCH',
        url: `${goBaseUrl}/api/v1/users/${refId}`,
        routeTemplate: '/api/v1/users/{id}',
        headers: { 'If-Match': '"1"' },
        body: f.userA.stale,
        nextVersion,
      })
      substeps.push(step1)

      // Explicit read-only checkpoint
      const step2 = await runClientSubstep({
        runId,
        caseId: 'T10',
        requestId: reqIdGen.next('T10'),
        method: 'GET',
        url: `${goBaseUrl}/api/v1/users/${refId}`,
        routeTemplate: '/api/v1/users/{id}',
        schema: nativeUserSchema,
        nextVersion,
      })
      substeps.push(step2)
      break
    }

    case 'T11a': {
      if (!refId) throw new Error('T11a requires refId')
      const envelope = await runClientSubstep({
        runId,
        caseId: 'T11a',
        requestId: reqIdGen.next('T11a'),
        method: 'GET',
        url: `${goBaseUrl}/api/v1/users/${refId}`,
        routeTemplate: '/api/v1/users/{id}',
        nextVersion,
      })
      substeps.push(envelope)
      break
    }

    case 'T11b': {
      if (!refId) throw new Error('T11b requires refId')
      const envelope = await runClientSubstep({
        runId,
        caseId: 'T11b',
        requestId: reqIdGen.next('T11b'),
        method: 'PATCH',
        url: `${goBaseUrl}/api/v1/users/${refId}`,
        routeTemplate: '/api/v1/users/{id}',
        headers: { 'If-Match': '"2"' },
        body: f.userA.outage,
        nextVersion,
      })
      substeps.push(envelope)
      break
    }

    case 'T11c': {
      const envelope = await runClientSubstep({
        runId,
        caseId: 'T11c',
        requestId: reqIdGen.next('T11c'),
        method: 'POST',
        url: `${goBaseUrl}/api/v1/users`,
        routeTemplate: '/api/v1/users',
        body: f.userX.initial,
        nextVersion,
      })
      substeps.push(envelope)
      break
    }

    case 'T12': {
      if (!refId) throw new Error('T12 requires refId')
      const envelope = await runClientSubstep({
        runId,
        caseId: 'T12',
        requestId: reqIdGen.next('T12'),
        method: 'GET',
        url: `${goBaseUrl}/api/v1/users/${refId}`,
        routeTemplate: '/api/v1/users/{id}',
        nextVersion,
      })
      substeps.push(envelope)
      break
    }

    case 'INT-PERS-01':
    case 'INT-PERS-02':
    case 'INT-PERS-03':
    case 'INT-PERS-04': {
      if (!refId) throw new Error(`${caseId} requires refId`)
      const envelope = await runClientSubstep({
        runId,
        caseId,
        requestId: reqIdGen.next(caseId),
        method: 'GET',
        url: `${goBaseUrl}/api/v1/users/${refId}`,
        routeTemplate: '/api/v1/users/{id}',
        schema: nativeUserSchema,
        nextVersion,
      })
      substeps.push(envelope)
      break
    }

    case 'W1': {
      const envelope = await runWireSubstep({
        runId,
        caseId: 'W1',
        requestId: reqIdGen.next('W1'),
        method: 'POST',
        url: `${goBaseUrl}/api/v1/users`,
        routeTemplate: '/api/v1/users',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(f.userB.initial),
        nextVersion,
      })
      substeps.push(envelope)
      break
    }

    case 'W2': {
      if (!refId) throw new Error('W2 requires refId')
      const envelope = await runWireSubstep({
        runId,
        caseId: 'W2',
        requestId: reqIdGen.next('W2'),
        method: 'GET',
        url: `${goBaseUrl}/api/v1/users/${refId}`,
        routeTemplate: '/api/v1/users/{id}',
        nextVersion,
      })
      substeps.push(envelope)
      break
    }

    case 'W3': {
      const envelope = await runWireSubstep({
        runId,
        caseId: 'W3',
        requestId: reqIdGen.next('W3'),
        method: 'GET',
        url: `${goBaseUrl}/api/v1/users/${FIXED_MISSING_UUID}`,
        routeTemplate: '/api/v1/users/{id}',
        nextVersion,
      })
      substeps.push(envelope)
      break
    }

    case 'T6-W': {
      const envelope = await runWireSubstep({
        runId,
        caseId: 'T6-W',
        requestId: reqIdGen.next('T6-W'),
        method: 'POST',
        url: `${goBaseUrl}/api/v1/users`,
        routeTemplate: '/api/v1/users',
        headers: { 'Content-Type': 'application/json' },
        body: '{',
        nextVersion,
      })
      substeps.push(envelope)
      break
    }

    case 'T7-W': {
      const rawBytes = new TextEncoder().encode(
        JSON.stringify({ email: f.wireT7.email, name: f.wireT7.name }),
      )
      const envelope = await runWireSubstep({
        runId,
        caseId: 'T7-W',
        requestId: reqIdGen.next('T7-W'),
        method: 'POST',
        url: `${goBaseUrl}/api/v1/users`,
        routeTemplate: '/api/v1/users',
        headers: {}, // Deliberately omit Content-Type!
        body: rawBytes,
        nextVersion,
      })
      substeps.push(envelope)
      break
    }

    case 'W9': {
      if (!refId) throw new Error('W9 requires refId')
      const envelope = await runWireSubstep({
        runId,
        caseId: 'W9',
        requestId: reqIdGen.next('W9'),
        method: 'GET',
        url: `${goBaseUrl}/api/v1/users/${refId}`,
        routeTemplate: '/api/v1/users/{id}',
        nextVersion,
      })
      substeps.push(envelope)
      break
    }

    case 'W11': {
      if (!refId) throw new Error('W11 requires refId')
      const envelope = await runWireSubstep({
        runId,
        caseId: 'W11',
        requestId: reqIdGen.next('W11'),
        method: 'GET',
        url: `${goBaseUrl}/api/v1/users/${refId}`,
        routeTemplate: '/api/v1/users/{id}',
        nextVersion,
      })
      substeps.push(envelope)
      break
    }

    default: {
      const unhandled: never = caseId
      throw new Error(`Unhandled caseId: ${unhandled}`)
    }
  }

  return { runId, caseId, substeps }
}
