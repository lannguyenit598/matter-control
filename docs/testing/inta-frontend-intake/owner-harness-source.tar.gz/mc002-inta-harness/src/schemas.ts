import { z } from 'zod'

export const ALLOWED_CASE_IDS = [
  'T1',
  'T2',
  'T3',
  'T4',
  'T5',
  'T8',
  'T9',
  'T10',
  'T11a',
  'T11b',
  'T11c',
  'T12',
  'W1',
  'W2',
  'W3',
  'T6-W',
  'T7-W',
  'W9',
  'W11',
  'INT-PERS-01',
  'INT-PERS-02',
  'INT-PERS-03',
  'INT-PERS-04',
] as const

export type CaseId = (typeof ALLOWED_CASE_IDS)[number]

export const harnessCaseInputSchema = z
  .object({
    runId: z.string().regex(/^[a-zA-Z0-9]{8,32}$/, 'runId must be 8-32 alphanumeric characters'),
    caseId: z.enum(ALLOWED_CASE_IDS),
    refId: z
      .string()
      .regex(/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/, 'refId must be lowercase canonical UUID')
      .optional(),
  })
  .strict()

export type HarnessCaseInput = z.infer<typeof harnessCaseInputSchema>

export const nativeUserSchema = z.object({
  id: z.string().uuid(),
  email: z.string().email(),
  name: z.string().min(1),
  version: z.number().int().positive(),
  createdAt: z.string(),
  updatedAt: z.string(),
})

export type NativeUser = z.infer<typeof nativeUserSchema>
