export const MAX_RETAINED_BODY_BYTES = 16384

export type HarnessEnvelope = {
  runId: string
  caseId: string
  requestId: string
  mode: 'app-client' | 'wire'
  method: string
  routeTemplate: string
  startedAtUTC: string
  latencyMs: number
  actualNextVersion: string
  harnessRevision: string
  outcome: 'value' | 'error' | 'aborted'
  value: unknown
  apiError: {
    status: number
    code: string
    message: string
    details?: unknown
  } | null
  wire: {
    status: number | null
    headers: Record<string, string> | null
    note?: string
  } | null
  truncated: boolean
}

export function buildHarnessEnvelope(
  params: Omit<HarnessEnvelope, 'truncated'> & { truncated?: boolean },
): HarnessEnvelope {
  let val = params.value
  let truncated = params.truncated ?? false

  if (val !== null && val !== undefined) {
    if (typeof val === 'string') {
      const bytes = new TextEncoder().encode(val).length
      if (bytes > MAX_RETAINED_BODY_BYTES) {
        val = val.slice(0, MAX_RETAINED_BODY_BYTES)
        truncated = true
      }
    } else {
      const json = JSON.stringify(val)
      const bytes = new TextEncoder().encode(json).length
      if (bytes > MAX_RETAINED_BODY_BYTES) {
        val = json.slice(0, MAX_RETAINED_BODY_BYTES)
        truncated = true
      }
    }
  }

  return {
    ...params,
    value: val,
    truncated,
  }
}
