export class RequestIdGenerator {
  private seq = 0

  constructor(public readonly runId: string) {}

  next(caseId: string): string {
    this.seq += 1
    const id = `mc-int-${this.runId}-${caseId}-${this.seq}`
    if (id.length > 128) {
      throw new Error(`RequestId exceeds 128 characters: ${id}`)
    }
    return id
  }
}
