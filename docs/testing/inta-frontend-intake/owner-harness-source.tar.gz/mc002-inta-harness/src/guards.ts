export const PRODUCT_AUTH_ENV_KEYS = [
  'API_MODE',
  'API_TOKEN',
  'API_BASE_URL',
  'AUTH_ALLOW_ANONYMOUS',
] as const

export type ValidationResult =
  | { ok: true; goBaseUrl: string }
  | { ok: false; status: number; reason: string; refusedKeys?: string[] }

export function validateHarnessEnvironment(env: Record<string, string | undefined>): ValidationResult {
  if (env.MC_INTA_ENABLE !== '1') {
    return {
      ok: false,
      status: 404,
      reason: 'Harness disabled: MC_INTA_ENABLE=1 is required',
    }
  }

  if (env.NODE_ENV === 'production') {
    return {
      ok: false,
      status: 403,
      reason: 'Harness execution refused: NODE_ENV cannot be production',
    }
  }

  const refusedKeys: string[] = []
  for (const key of PRODUCT_AUTH_ENV_KEYS) {
    if (env[key] !== undefined && env[key] !== '') {
      refusedKeys.push(key)
    }
  }

  if (refusedKeys.length > 0) {
    return {
      ok: false,
      status: 403,
      refusedKeys,
      reason: `Harness execution refused: product auth env vars present (${refusedKeys.join(', ')})`,
    }
  }

  const goBaseUrl = env.MC_INTA_GO_BASE_URL ?? 'http://127.0.0.1:18086'
  if (goBaseUrl !== 'http://127.0.0.1:18086') {
    return {
      ok: false,
      status: 403,
      reason: `Fixed Go URL violation: expected http://127.0.0.1:18086 but received ${goBaseUrl}`,
    }
  }

  return { ok: true, goBaseUrl }
}
