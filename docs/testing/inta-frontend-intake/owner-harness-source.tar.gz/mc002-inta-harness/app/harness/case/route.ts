import { NextResponse } from 'next/server'
import { validateHarnessEnvironment } from '../../../src/guards'
import { harnessCaseInputSchema } from '../../../src/schemas'
import { executeCase } from '../../../src/executor'
import { RequestIdGenerator } from '../../../src/request-id'

const NO_STORE_HEADERS = {
  'Cache-Control': 'no-store, no-cache, must-revalidate',
  Pragma: 'no-cache',
}

let activeGen: RequestIdGenerator | null = null

function getRequestIdGen(runId: string): RequestIdGenerator {
  if (!activeGen || activeGen.runId !== runId) {
    activeGen = new RequestIdGenerator(runId)
  }
  return activeGen
}

export async function POST(request: Request) {
  // 1. Guard check: environment and refusal policies
  const envCheck = validateHarnessEnvironment(process.env)
  if (!envCheck.ok) {
    return NextResponse.json(
      { error: envCheck.reason, refusedKeys: (envCheck as any).refusedKeys },
      { status: envCheck.status, headers: NO_STORE_HEADERS },
    )
  }

  // 2. Parse request body
  let rawBody: unknown
  try {
    rawBody = await request.json()
  } catch {
    return NextResponse.json(
      { error: 'Invalid JSON body' },
      { status: 400, headers: NO_STORE_HEADERS },
    )
  }

  // 3. Strict allowlist validation
  const parsed = harnessCaseInputSchema.safeParse(rawBody)
  if (!parsed.success) {
    return NextResponse.json(
      {
        error: 'Bad Request: validation failed',
        details: parsed.error.issues.map((i) => ({ path: i.path, message: i.message })),
      },
      { status: 400, headers: NO_STORE_HEADERS },
    )
  }

  const { runId, caseId, refId } = parsed.data

  // 4. Execute case
  try {
    const reqIdGen = getRequestIdGen(runId)
    const result = await executeCase({
      runId,
      caseId,
      refId,
      reqIdGen,
      goBaseUrl: envCheck.goBaseUrl,
      nextVersion: '16.4.2',
    })

    return NextResponse.json(result, {
      status: 200,
      headers: NO_STORE_HEADERS,
    })
  } catch (err: any) {
    return NextResponse.json(
      { error: 'Execution error', message: String(err.message ?? err) },
      { status: 500, headers: NO_STORE_HEADERS },
    )
  }
}

export async function GET() {
  return NextResponse.json(
    { error: 'Method Not Allowed' },
    { status: 405, headers: { ...NO_STORE_HEADERS, Allow: 'POST' } },
  )
}

export async function PUT() {
  return GET()
}

export async function PATCH() {
  return GET()
}

export async function DELETE() {
  return GET()
}
