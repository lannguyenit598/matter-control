import { describe, expect, it, beforeEach, afterEach } from 'vitest'
import fs from 'node:fs'
import path from 'node:path'
import {
  HarnessDriver,
  generateRunId,
  validateRunId,
  assertNoRunIdCollision,
  CANONICAL_36_LOGICAL_IDS,
  UUIDV7_LOWERCASE_REGEX,
} from '../src/driver.js'
import type { HarnessEnvelope } from '../src/envelope.js'

describe('HarnessDriver (INTA-FE-R02)', () => {
  const testStateDir = path.join(process.cwd(), '.test-driver-state')
  const testEvidenceDir = path.join(process.cwd(), '.test-driver-evidence')

  beforeEach(() => {
    fs.mkdirSync(testStateDir, { recursive: true })
    fs.mkdirSync(testEvidenceDir, { recursive: true })
  })

  afterEach(() => {
    try {
      fs.rmSync(testStateDir, { recursive: true, force: true })
      fs.rmSync(testEvidenceDir, { recursive: true, force: true })
    } catch {}
  })

  it('generates valid 8-32 alphanumeric runId', () => {
    const runId = generateRunId()
    expect(validateRunId(runId)).toBe(true)
    expect(runId.length).toBeGreaterThanOrEqual(8)
    expect(runId.length).toBeLessThanOrEqual(32)
    expect(/^[a-zA-Z0-9]+$/.test(runId)).toBe(true)
  })

  it('refuses collision when evidence folder for runId already exists (R02)', () => {
    const existingRunId = 'existingrun1234'
    const collisionDir = path.join(testEvidenceDir, 'frontend', existingRunId)
    fs.mkdirSync(collisionDir, { recursive: true })

    expect(() =>
      assertNoRunIdCollision(existingRunId, testEvidenceDir, testStateDir),
    ).toThrow(/RunId collision refused: existing evidence found/)
  })

  it('contains all 36 required canonical logical IDs', () => {
    expect(CANONICAL_36_LOGICAL_IDS).toHaveLength(36)
    // Check key required IDs
    expect(CANONICAL_36_LOGICAL_IDS).toContain('INT-ENV-01')
    expect(CANONICAL_36_LOGICAL_IDS).toContain('INT-ENV-05')
    expect(CANONICAL_36_LOGICAL_IDS).toContain('INT-ENV-06')
    expect(CANONICAL_36_LOGICAL_IDS).toContain('INT-ENV-07')
    expect(CANONICAL_36_LOGICAL_IDS).toContain('T1')
    expect(CANONICAL_36_LOGICAL_IDS).toContain('T2')
    expect(CANONICAL_36_LOGICAL_IDS).toContain('T5')
    expect(CANONICAL_36_LOGICAL_IDS).toContain('T8')
    expect(CANONICAL_36_LOGICAL_IDS).toContain('T9')
    expect(CANONICAL_36_LOGICAL_IDS).toContain('T10')
    expect(CANONICAL_36_LOGICAL_IDS).toContain('T11a')
    expect(CANONICAL_36_LOGICAL_IDS).toContain('T11b')
    expect(CANONICAL_36_LOGICAL_IDS).toContain('T11c')
    expect(CANONICAL_36_LOGICAL_IDS).toContain('T12')
    expect(CANONICAL_36_LOGICAL_IDS).toContain('W1')
    expect(CANONICAL_36_LOGICAL_IDS).toContain('W9')
    expect(CANONICAL_36_LOGICAL_IDS).toContain('W11')
    expect(CANONICAL_36_LOGICAL_IDS).toContain('INT-PERS-01')
    expect(CANONICAL_36_LOGICAL_IDS).toContain('INT-PERS-02')
    expect(CANONICAL_36_LOGICAL_IDS).toContain('INT-PERS-03')
    expect(CANONICAL_36_LOGICAL_IDS).toContain('INT-PERS-04')
    expect(CANONICAL_36_LOGICAL_IDS).toContain('INT-COR-01')
    expect(CANONICAL_36_LOGICAL_IDS).toContain('INT-PRIV-01')
    expect(CANONICAL_36_LOGICAL_IDS).toContain('INT-ISO-01')
    expect(CANONICAL_36_LOGICAL_IDS).toContain('INT-ISO-02')
    expect(CANONICAL_36_LOGICAL_IDS).toContain('INT-ISO-03')
    expect(CANONICAL_36_LOGICAL_IDS).toContain('INT-CONF-01')
  })

  it('records Checkpoint A from valid T1 envelope and verifies RFC 3339 UTC timestamps (R01, R02)', () => {
    const driver = new HarnessDriver('drivertest123', testStateDir)
    const validT1Envelope: HarnessEnvelope = {
      runId: 'drivertest123',
      caseId: 'T1',
      requestId: 'mc-int-drivertest123-T1-1',
      mode: 'app-client',
      method: 'POST',
      routeTemplate: '/api/v1/users',
      startedAtUTC: '2026-10-25T03:00:00Z',
      latencyMs: 15,
      actualNextVersion: '16.4.2',
      harnessRevision: 'e25bbc6933264fc46a729e6a364a3bfa02d8038f',
      outcome: 'value',
      classification: 'success',
      value: {
        id: '0192e23b-6e9f-7b71-91ea-42b7e199db1c',
        email: 'inta-a-drivertest123@example.test',
        name: 'INTA_A_INITIAL',
        version: 1,
        created_at: '2026-10-25T03:00:00.123456Z',
        updated_at: '2026-10-25T03:00:00.123456Z',
      },
      apiError: null,
      wire: null,
      truncated: false,
    }

    const cp = driver.assertT1(validT1Envelope)
    expect(cp.id).toBe('0192e23b-6e9f-7b71-91ea-42b7e199db1c')
    expect(cp.version).toBe(1)
    expect(driver.state.assertions.get('T1')?.pass).toBe(true)

    // T2 assertion
    const validT2Envelope: HarnessEnvelope = {
      ...validT1Envelope,
      caseId: 'T2',
      requestId: 'mc-int-drivertest123-T2-1',
      method: 'GET',
      routeTemplate: '/api/v1/users/{id}',
    }
    expect(() => driver.assertT2(validT2Envelope)).not.toThrow()
    expect(driver.state.assertions.get('T2')?.pass).toBe(true)
  })

  it('blocks assertion acceptance when evidence is truncated (R05)', () => {
    const driver = new HarnessDriver('truncatetest1', testStateDir)
    const truncatedEnvelope: HarnessEnvelope = {
      runId: 'truncatetest1',
      caseId: 'T1',
      requestId: 'mc-int-truncatetest1-T1-1',
      mode: 'app-client',
      method: 'POST',
      routeTemplate: '/api/v1/users',
      startedAtUTC: '2026-10-25T03:00:00Z',
      latencyMs: 15,
      actualNextVersion: '16.4.2',
      harnessRevision: 'e25bbc6933264fc46a729e6a364a3bfa02d8038f',
      outcome: 'value',
      classification: 'success',
      value: 'truncated-string-content',
      apiError: null,
      wire: null,
      truncated: true,
    }

    expect(() => driver.assertT1(truncatedEnvelope)).toThrow(/T1 assertion blocked: envelope body was truncated/)
    expect(driver.state.assertions.get('T1')?.blocked).toBe(true)
  })

  it('pauses safely for upstream coordination before execution', () => {
    const driver = new HarnessDriver('pausetest123', testStateDir)
    driver.pauseForUpstreamCoordination(false)
    expect(driver.state.phase).toBe('PAUSED_WAITING_ENV')

    driver.pauseForUpstreamCoordination(true)
    expect(driver.state.phase).toBe('ENV_COORDINATED_READY')
  })

  it('validates UUIDv7 version digit and variant strictly (F01)', () => {
    // Valid UUIDv7 (version 7, variant 8, 9, a, or b)
    expect(UUIDV7_LOWERCASE_REGEX.test('0192e23b-6e9f-7b71-91ea-42b7e199db1c')).toBe(true)
    // Invalid: version 4
    expect(UUIDV7_LOWERCASE_REGEX.test('0192e23b-6e9f-4b71-91ea-42b7e199db1c')).toBe(false)
    // Invalid: uppercase
    expect(UUIDV7_LOWERCASE_REGEX.test('0192E23B-6E9F-7B71-91EA-42B7E199DB1C')).toBe(false)
  })

  it('refuses T1 when email or name does not match fixture A (F01)', () => {
    const driver = new HarnessDriver('fixtest1234', testStateDir)
    const baseEnvelope: HarnessEnvelope = {
      runId: 'fixtest1234',
      caseId: 'T1',
      requestId: 'mc-int-fixtest1234-T1-1',
      mode: 'app-client',
      method: 'POST',
      routeTemplate: '/api/v1/users',
      startedAtUTC: '2026-10-25T03:00:00Z',
      latencyMs: 15,
      actualNextVersion: '16.4.2',
      harnessRevision: '6e2f65b51e7ead3c84274e717f8f3bcaeccf9b91',
      outcome: 'value',
      classification: 'success',
      value: {
        id: '0192e23b-6e9f-7b71-91ea-42b7e199db1c',
        email: 'wrong-email@example.test',
        name: 'INTA_A_INITIAL',
        version: 1,
        created_at: '2026-10-25T03:00:00.000Z',
        updated_at: '2026-10-25T03:00:00.000Z',
      },
      apiError: null,
      wire: null,
      truncated: false,
    }

    expect(() => driver.assertT1(baseEnvelope)).toThrow(/email mismatch vs fixture A/)

    // Wrong name
    const wrongNameEnv: HarnessEnvelope = {
      ...baseEnvelope,
      value: {
        ...(baseEnvelope.value as any),
        email: 'inta-a-fixtest1234@example.test',
        name: 'WRONG_NAME',
      },
    }
    expect(() => driver.assertT1(wrongNameEnv)).toThrow(/name mismatch vs fixture A/)
  })

  it('enforces write-once envelope persistence and refuses duplicate mutation replay (F01)', () => {
    const driver = new HarnessDriver('wronce12345', testStateDir)
    const dummyEnvelope: HarnessEnvelope = {
      runId: 'wronce12345',
      caseId: 'T1',
      requestId: 'mc-int-wronce12345-T1-1',
      mode: 'app-client',
      method: 'POST',
      routeTemplate: '/api/v1/users',
      startedAtUTC: '2026-10-25T03:00:00Z',
      latencyMs: 10,
      actualNextVersion: '16.4.2',
      harnessRevision: '6e2f65b51e7ead3c84274e717f8f3bcaeccf9b91',
      outcome: 'value',
      classification: 'success',
      value: { id: '0192e23b-6e9f-7b71-91ea-42b7e199db1c' },
      apiError: null,
      wire: null,
      truncated: false,
    }

    // First write succeeds
    expect(() => driver.persistEnvelope('T1', [dummyEnvelope])).not.toThrow()

    // Idempotent byte-equal write succeeds without error
    expect(() => driver.persistEnvelope('T1', [dummyEnvelope])).not.toThrow()

    // Conflicting duplicate execution throws refusal
    const conflictingEnv: HarnessEnvelope = {
      ...dummyEnvelope,
      requestId: 'mc-int-wronce12345-T1-2', // Different requestId
    }
    expect(() => driver.persistEnvelope('T1', [conflictingEnv])).toThrow(
      /Duplicate case execution refused by write-once ledger: T1 already executed/,
    )
  })

  it('persists and restores durable checkpoints across restarts (F01)', () => {
    const runId = 'durable12345'
    const driver1 = new HarnessDriver(runId, testStateDir)

    const validT1Envelope: HarnessEnvelope = {
      runId,
      caseId: 'T1',
      requestId: `mc-int-${runId}-T1-1`,
      mode: 'app-client',
      method: 'POST',
      routeTemplate: '/api/v1/users',
      startedAtUTC: '2026-10-25T03:00:00Z',
      latencyMs: 15,
      actualNextVersion: '16.4.2',
      harnessRevision: '6e2f65b51e7ead3c84274e717f8f3bcaeccf9b91',
      outcome: 'value',
      classification: 'success',
      value: {
        id: '0192e23b-6e9f-7b71-91ea-42b7e199db1c',
        email: `inta-a-${runId}@example.test`,
        name: 'INTA_A_INITIAL',
        version: 1,
        created_at: '2026-10-25T03:00:00.123456Z',
        updated_at: '2026-10-25T03:00:00.123456Z',
      },
      apiError: null,
      wire: null,
      truncated: false,
    }

    driver1.assertT1(validT1Envelope)
    expect(driver1.state.checkpointA?.version).toBe(1)

    // Checkpoint file should exist on disk
    const cpFile = path.join(testStateDir, 'checkpoints', `${runId}.json`)
    expect(fs.existsSync(cpFile)).toBe(true)

    // Second driver instance simulating reload / resume (with allowResume=true)
    const driver2 = new HarnessDriver(runId, testStateDir, true)
    expect(driver2.state.checkpointA).not.toBeNull()
    expect(driver2.state.checkpointA?.id).toBe('0192e23b-6e9f-7b71-91ea-42b7e199db1c')
    expect(driver2.state.checkpointA?.version).toBe(1)
  })

  it('asserts T9 mutation and updates checkpoint to version 2 (F01)', () => {
    const runId = 't9mutation12'
    const driver = new HarnessDriver(runId, testStateDir)
    driver.state.checkpointA = {
      id: '0192e23b-6e9f-7b71-91ea-42b7e199db1c',
      email: `inta-a-${runId}@example.test`,
      name: 'INTA_A_INITIAL',
      version: 1,
      created_at: '2026-10-25T03:00:00Z',
      updated_at: '2026-10-25T03:00:00Z',
    }

    const t9Envelope: HarnessEnvelope = {
      runId,
      caseId: 'T9',
      requestId: `mc-int-${runId}-T9-1`,
      mode: 'app-client',
      method: 'PATCH',
      routeTemplate: '/api/v1/users/{id}',
      startedAtUTC: '2026-10-25T03:05:00Z',
      latencyMs: 12,
      actualNextVersion: '16.4.2',
      harnessRevision: '6e2f65b51e7ead3c84274e717f8f3bcaeccf9b91',
      outcome: 'value',
      classification: 'success',
      value: {
        id: '0192e23b-6e9f-7b71-91ea-42b7e199db1c',
        email: `inta-a-${runId}@example.test`,
        name: 'INTA_A_UPDATED',
        version: 2,
        created_at: '2026-10-25T03:00:00Z',
        updated_at: '2026-10-25T03:05:00Z',
      },
      apiError: null,
      wire: null,
      truncated: false,
    }

    const updatedCp = driver.assertT9(t9Envelope)
    expect(updatedCp.version).toBe(2)
    expect(updatedCp.name).toBe('INTA_A_UPDATED')
    expect(driver.state.checkpointA?.version).toBe(2)
  })

  it('asserts T11a native 503 problem details and marks T11c OUTCOME_UNKNOWN (F01)', () => {
    const runId = 'outagetest12'
    const driver = new HarnessDriver(runId, testStateDir)

    const t11aEnvelope: HarnessEnvelope = {
      runId,
      caseId: 'T11a',
      requestId: `mc-int-${runId}-T11a-1`,
      mode: 'app-client',
      method: 'GET',
      routeTemplate: '/api/v1/users/{id}',
      startedAtUTC: '2026-10-25T03:10:00Z',
      latencyMs: 5,
      actualNextVersion: '16.4.2',
      harnessRevision: '6e2f65b51e7ead3c84274e717f8f3bcaeccf9b91',
      outcome: 'apiError',
      classification: 'unavailable',
      value: null,
      apiError: {
        status: 503,
        code: 'HTTP_ERROR',
        message: 'service temporarily unavailable',
        details: {
          type: '/problems/unavailable',
          title: 'Service Unavailable',
          status: 503,
          detail: 'service temporarily unavailable',
          retryAfter: 1,
        },
      },
      wire: null,
      truncated: false,
    }

    expect(() => driver.assertT11a(t11aEnvelope)).not.toThrow()
    expect(driver.state.assertions.get('T11a')?.pass).toBe(true)

    // T11c: POST X during PG outage
    const t11cEnvelope: HarnessEnvelope = {
      ...t11aEnvelope,
      caseId: 'T11c',
      requestId: `mc-int-${runId}-T11c-1`,
      method: 'POST',
      routeTemplate: '/api/v1/users',
    }
    driver.assertT11c(t11cEnvelope)
    expect(driver.state.userXOutcome).toBe('OUTCOME_UNKNOWN')
  })

  it('refuses collision when counters.json has runId entry (F02)', () => {
    const runId = 'collisionRun123'
    const countersPath = path.join(testStateDir, 'counters.json')
    fs.writeFileSync(countersPath, JSON.stringify({ [runId]: 10 }), 'utf-8')

    expect(() =>
      assertNoRunIdCollision(runId, testEvidenceDir, testStateDir),
    ).toThrow(/RunId collision refused: existing counter found/)
  })

  it('enforces causal stage ordering: stage N requires stage N-1 completed (R2-F01)', async () => {
    const driver = new HarnessDriver('stageordertest', testStateDir)

    // Stage 2 cannot run before Stage 1
    await expect(driver.runStage(2, { confirmGoRestarted: true })).rejects.toThrow(
      /Stage 2 order violation: Stage 1 must be completed first/,
    )

    // Stage 3 cannot run before Stage 2
    await expect(driver.runStage(3, { confirmPgRestarted: true })).rejects.toThrow(
      /Stage 3 order violation: Stage 2 must be completed first/,
    )

    // Stage 4 cannot run before Stage 3
    await expect(driver.runStage(4)).rejects.toThrow(
      /Stage 4 order violation: Stage 3 must be completed first/,
    )

    // Stage 5 cannot run before Stage 4
    await expect(driver.runStage(5, { confirmPgStopped: true })).rejects.toThrow(
      /Stage 5 order violation: Stage 4 must be completed first/,
    )

    // Stage 6 cannot run before Stage 5
    await expect(driver.runStage(6, { confirmPgRecovered: true })).rejects.toThrow(
      /Stage 6 order violation: Stage 5 must be completed first/,
    )

    // Stage 7 cannot run before Stage 6
    await expect(driver.runStage(7, { confirmGoStopped: true })).rejects.toThrow(
      /Stage 7 order violation: Stage 6 must be completed first/,
    )
  })

  it('enforces explicit operator confirmation barriers before restart-dependent stages (R2-F01)', async () => {
    const driver = new HarnessDriver('confirmgates', testStateDir)
    // Mark stage 1 completed
    driver.markStageCompleted(1)
    driver.state.checkpointABaseline = {
      id: '0192e23b-6e9f-7b71-91ea-42b7e199db1c',
      email: 'inta-a-confirmgates@example.test',
      name: 'INTA_A_INITIAL',
      version: 1,
      created_at: '2026-10-25T03:00:00Z',
      updated_at: '2026-10-25T03:00:00Z',
    }

    // Stage 2 without --confirm-go-restarted pauses safely with 0 dispatches
    const r2 = await driver.runStage(2)
    expect(r2.ok).toBe(false)
    expect(r2.reason).toBe('PAUSED_WAITING_GO_RESTART_CONFIRMATION')
    expect(r2.executedCases).toHaveLength(0)

    // Mark stage 2 completed
    driver.markStageCompleted(2)
    // Stage 3 without --confirm-pg-restarted pauses safely with 0 dispatches
    const r3 = await driver.runStage(3)
    expect(r3.ok).toBe(false)
    expect(r3.reason).toBe('PAUSED_WAITING_PG_RESTART_CONFIRMATION')
    expect(r3.executedCases).toHaveLength(0)

    // Mark stage 4 completed
    driver.markStageCompleted(3)
    driver.markStageCompleted(4)
    driver.state.checkpointACurrent = { ...driver.state.checkpointABaseline, version: 2 }
    // Stage 5 without --confirm-pg-stopped pauses safely
    const r5 = await driver.runStage(5)
    expect(r5.ok).toBe(false)
    expect(r5.reason).toBe('PAUSED_WAITING_PG_STOP_CONFIRMATION')

    // Mark stage 5 completed
    driver.markStageCompleted(5)
    // Stage 6 without --confirm-pg-recovered pauses safely
    const r6 = await driver.runStage(6)
    expect(r6.ok).toBe(false)
    expect(r6.reason).toBe('PAUSED_WAITING_PG_RECOVERY_CONFIRMATION')

    // Mark stage 6 completed
    driver.markStageCompleted(6)
    // Stage 7 without --confirm-go-stopped pauses safely
    const r7 = await driver.runStage(7)
    expect(r7.ok).toBe(false)
    expect(r7.reason).toBe('PAUSED_WAITING_GO_STOP_CONFIRMATION')
  })

  it('reserves one-shot intent before dispatch and refuses replay of started/completed/unknown cases (R2-F02)', () => {
    const runId = 'intentguard1'
    const driver = new HarnessDriver(runId, testStateDir)

    // Reserving fresh case succeeds
    expect(() => driver.reserveSubstepIntent('T1')).not.toThrow()

    // Reserving an already started case throws refusal
    expect(() => driver.reserveSubstepIntent('T1')).toThrow(
      /Dispatch refused by one-shot intent guard: case T1 is already started/,
    )

    // Completing case
    driver.completeSubstepIntent('T1', 'completed')

    // Attempting to re-reserve completed case throws refusal
    expect(() => driver.reserveSubstepIntent('T1')).toThrow(
      /Dispatch refused by one-shot intent guard: case T1 is already completed/,
    )

    // T11c marked unknown
    driver.reserveSubstepIntent('T11c')
    driver.completeSubstepIntent('T11c', 'unknown')

    // Attempting to re-reserve T11c throws refusal (never retry unknown X)
    expect(() => driver.reserveSubstepIntent('T11c')).toThrow(
      /Dispatch refused by one-shot intent guard: case T11c is already unknown/,
    )
  })

  it('fails closed when substep intent status is corrupt (R2-F02)', () => {
    const runId = 'corruptintent'
    const driver = new HarnessDriver(runId, testStateDir)
    const statusFile = path.join(driver.substepsDir, 'T1.status')
    fs.writeFileSync(statusFile, '{ corrupt json !!!', 'utf-8')

    expect(() => driver.reserveSubstepIntent('T1')).toThrow(/Fail-closed: unreadable or corrupt substep status/)
  })

  it('asserts wire x-request-id echo strictly and fails on missing or mismatched header (R2-F06)', () => {
    const driver = new HarnessDriver('echotest1', testStateDir)
    const validW1Envelope: HarnessEnvelope = {
      runId: 'echotest1',
      caseId: 'W1',
      requestId: 'mc-int-echotest1-W1-1',
      mode: 'wire',
      method: 'POST',
      routeTemplate: '/api/v1/users',
      startedAtUTC: '2026-10-25T03:00:00Z',
      latencyMs: 15,
      actualNextVersion: '16.4.2',
      harnessRevision: '79322fcb2c72bb3db20d55f3f3fc860e7e7ee2dc',
      outcome: 'value',
      classification: 'success',
      value: { id: '0192e23b-6e9f-7b71-91ea-42b7e199db1c' },
      apiError: null,
      wire: {
        status: 201,
        headers: {
          location: '/api/v1/users/0192e23b-6e9f-7b71-91ea-42b7e199db1c',
          etag: '"1"',
          'content-type': 'application/json',
          'x-request-id': 'mc-int-echotest1-W1-1', // Correct echo
        },
      },
      truncated: false,
    }

    // Matching echo succeeds
    expect(() => driver.assertW1(validW1Envelope)).not.toThrow()

    // Mismatched echo throws
    const mismatchedEchoEnv: HarnessEnvelope = {
      ...validW1Envelope,
      wire: {
        ...validW1Envelope.wire!,
        headers: {
          ...validW1Envelope.wire!.headers!,
          'x-request-id': 'wrong-request-id',
        },
      },
    }
    expect(() => driver.assertW1(mismatchedEchoEnv)).toThrow(/wire x-request-id echo mismatch/)

    // Missing echo throws
    const missingEchoEnv: HarnessEnvelope = {
      ...validW1Envelope,
      wire: {
        ...validW1Envelope.wire!,
        headers: {
          location: '/api/v1/users/0192e23b-6e9f-7b71-91ea-42b7e199db1c',
          etag: '"1"',
          'content-type': 'application/json',
          // x-request-id omitted
        },
      },
    }
    expect(() => driver.assertW1(missingEchoEnv)).toThrow(/wire x-request-id echo mismatch/)
  })

  it('preflight allows resume for existing same-run assets, but fails closed on corrupt counters (R2-F03)', () => {
    const runId = 'resumepreflight'
    const evDir = path.join(testEvidenceDir, 'frontend', runId)
    fs.mkdirSync(evDir, { recursive: true })

    // allowResume=false refuses collision
    expect(() => assertNoRunIdCollision(runId, testEvidenceDir, testStateDir, false)).toThrow(
      /RunId collision refused: existing evidence found/,
    )

    // allowResume=true succeeds
    expect(() => assertNoRunIdCollision(runId, testEvidenceDir, testStateDir, true)).not.toThrow()

    // Corrupt counters.json throws fail-closed even with allowResume=true
    const countersPath = path.join(testStateDir, 'counters.json')
    fs.writeFileSync(countersPath, 'corrupt json not valid', 'utf-8')
    expect(() => assertNoRunIdCollision(runId, testEvidenceDir, testStateDir, true)).toThrow(
      /Fail-closed: unreadable or corrupt counter state/,
    )
  })

  it('persists durable assertions across driver reload and preserves immutable baseline checkpoint across phases (R2-F07)', () => {
    const runId = 'durableassertions'
    const driver1 = new HarnessDriver(runId, testStateDir)

    const validT1Envelope: HarnessEnvelope = {
      runId,
      caseId: 'T1',
      requestId: `mc-int-${runId}-T1-1`,
      mode: 'app-client',
      method: 'POST',
      routeTemplate: '/api/v1/users',
      startedAtUTC: '2026-10-25T03:00:00Z',
      latencyMs: 15,
      actualNextVersion: '16.4.2',
      harnessRevision: '79322fcb2c72bb3db20d55f3f3fc860e7e7ee2dc',
      outcome: 'value',
      classification: 'success',
      value: {
        id: '0192e23b-6e9f-7b71-91ea-42b7e199db1c',
        email: `inta-a-${runId}@example.test`,
        name: 'INTA_A_INITIAL',
        version: 1,
        created_at: '2026-10-25T03:00:00.123456Z',
        updated_at: '2026-10-25T03:00:00.123456Z',
      },
      apiError: null,
      wire: null,
      truncated: false,
    }

    driver1.assertT1(validT1Envelope)
    expect(driver1.state.checkpointABaseline?.version).toBe(1)
    expect(driver1.state.checkpointACurrent?.version).toBe(1)

    // Perform T9 mutation
    const t9Envelope: HarnessEnvelope = {
      runId,
      caseId: 'T9',
      requestId: `mc-int-${runId}-T9-1`,
      mode: 'app-client',
      method: 'PATCH',
      routeTemplate: '/api/v1/users/{id}',
      startedAtUTC: '2026-10-25T03:05:00Z',
      latencyMs: 12,
      actualNextVersion: '16.4.2',
      harnessRevision: '79322fcb2c72bb3db20d55f3f3fc860e7e7ee2dc',
      outcome: 'value',
      classification: 'success',
      value: {
        id: '0192e23b-6e9f-7b71-91ea-42b7e199db1c',
        email: `inta-a-${runId}@example.test`,
        name: 'INTA_A_UPDATED',
        version: 2,
        created_at: '2026-10-25T03:00:00Z',
        updated_at: '2026-10-25T03:05:00Z',
      },
      apiError: null,
      wire: null,
      truncated: false,
    }
    driver1.assertT9(t9Envelope)

    // Baseline remains immutable at version 1!
    expect(driver1.state.checkpointABaseline?.version).toBe(1)
    expect(driver1.state.checkpointACurrent?.version).toBe(2)

    // Create fresh instance with allowResume=true
    const driver2 = new HarnessDriver(runId, testStateDir, true)
    expect(driver2.state.checkpointABaseline?.version).toBe(1)
    expect(driver2.state.checkpointACurrent?.version).toBe(2)

    // Verify assertions are reloaded
    expect(driver2.state.assertions.size).toBeGreaterThanOrEqual(2)
    expect(driver2.state.assertions.get('T1')?.pass).toBe(true)
    expect(driver2.state.assertions.get('T9')?.pass).toBe(true)
  })
})
