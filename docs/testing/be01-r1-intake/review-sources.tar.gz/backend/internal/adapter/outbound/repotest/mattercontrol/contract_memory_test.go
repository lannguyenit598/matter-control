package mattercontrol_test

import (
	"testing"
	"time"

	"github.com/example/userapi/internal/adapter/outbound/repotest/mattercontrol"
)

// The shared spine contract runs against the in-memory double first: it must pass the
// same suite as the PostgreSQL adapter. The double's clock is monotonic but arbitrary.
func TestSuite_MemoryStore(t *testing.T) {
	mattercontrol.Suite(t, func(t *testing.T) mattercontrol.Bundle {
		base := time.Date(2026, 10, 25, 12, 0, 0, 0, time.UTC)
		n := 0
		store := mattercontrol.NewMemoryStore(func() time.Time {
			n++
			return base.Add(time.Duration(n) * time.Second)
		})
		return mattercontrol.Bundle{Store: store, World: mattercontrol.NewMemoryWorld(store)}
	})
}
