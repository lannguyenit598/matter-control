// Package mattercontrol is the shared contract-test kit for the MatterControl
// transaction spine (port.MatterStore + service). It provides an in-memory double
// with real transaction semantics and a World seeder/observer used by the shared
// suite; storage adapters run the same suite through the same World interface.
package mattercontrol

import (
	"context"
	"errors"
	"fmt"
	"sync"
	"time"

	"github.com/example/userapi/internal/core/domain/matter"
	"github.com/example/userapi/internal/core/port"
)

// ErrInjected is the sentinel carried by every injected seam failure so tests can
// distinguish seam errors from real defects.
var ErrInjected = errors.New("injected failure")

// Counts reports row counts by table, for atomicity assertions.
type Counts struct {
	Nodes            int
	Requirements     int
	Actions          int
	Events           int
	Receipts         int
	ReceiptMatters   int
	Audits           int
	Matters          int
	WorkspaceMembers int
	MatterMembers    int
}

// World provisions and observes the fixtures behind a MatterStore: identities,
// workspaces, memberships, matters and structural rows that this slice has no
// product command for. Implementations are for tests only.
type World interface {
	AddUser(id matter.ActorID)
	AddWorkspace(id matter.WorkspaceID)
	SetWorkspaceMembership(workspace matter.WorkspaceID, actor matter.ActorID, role matter.WorkspaceRole, status matter.MembershipStatus)
	AddMatter(id matter.MatterID, workspace matter.WorkspaceID)
	SetMatterMembership(m matter.MatterID, actor matter.ActorID, role matter.MatterRole, status matter.MembershipStatus)
	// InsertActionNode adds an ACTION node with its typed row: the kind-mismatch
	// fixture for uniform read outcomes.
	InsertActionNode(id matter.NodeID, m matter.MatterID)
	// SetElapsedBoundary pins a pending temporal boundary in the past of the store's
	// command clock, so the next command on the matter is due to process it
	// (BE01-F02 fixture).
	SetElapsedBoundary(m matter.MatterID)
	// SetFutureBoundary pins a pending temporal boundary after the store's command
	// clock: not due, safe to proceed, and it must be preserved by a successful
	// command.
	SetFutureBoundary(m matter.MatterID)
	// NextBoundary returns the matter's pending boundary instant (ok=false when the
	// header carries none).
	NextBoundary(m matter.MatterID) (time.Time, bool)
	Counts() Counts
	// Requirement returns the stored typed row (ok=false when absent).
	Requirement(id matter.RequirementID) (matter.Requirement, bool)
	Events() []matter.RequirementCreatedEvent
	Receipts() []matter.Receipt
	Audits() []matter.SecurityAuditEntry
	// Reopen returns a NEW MatterStore handle over the same data, simulating a
	// repository restart for replay tests.
	Reopen() port.MatterStore
}

// Store is the in-memory MatterStore double. Execute serializes on one mutex and
// provides rollback by restoring a deep copy of the state when fn fails; View reads
// a point-in-time copy. Per-matter lock fidelity is the postgres adapter's contract;
// the double guarantees the same observable atomicity and replay outcomes.
type Store struct {
	mu sync.Mutex

	matters       map[matter.MatterID]*matter.MatterHeader
	wsMemberships map[wsKey]matter.WorkspaceMembership
	mMemberships  map[mmKey]matter.MatterMembership
	nodes         map[matter.NodeID]matter.Node
	requirements  map[matter.RequirementID]matter.Requirement
	actions       map[matter.NodeID]bool
	events        []matter.RequirementCreatedEvent
	receipts      map[receiptKey]matter.Receipt
	audits        []matter.SecurityAuditEntry

	clock func() time.Time

	// FailAt injects a failure into the matching transaction step
	// ("insert_node", "insert_requirement", "append_event", "store_receipt",
	// "complete_matter"), asserting full rollback. The membership steps
	// ("membership_unavailable", "membership_unexpected") fail the membership
	// lookups in BOTH Execute transactions and View snapshots, proving that
	// storage failures stay distinct from absence (BE01-F03).
	FailAt string
	// CommitRollback, when set, makes a successful transaction fail at commit with a
	// KNOWN rollback (wraps port.ErrUnavailable); state is discarded.
	CommitRollback error
	// CommitUnknown, when set, makes a successful transaction commit but lose the
	// acknowledgement (wraps port.ErrOutcomeUnknown).
	CommitUnknown error
}

type (
	wsKey struct {
		ws    matter.WorkspaceID
		actor matter.ActorID
	}
	mmKey struct {
		m     matter.MatterID
		actor matter.ActorID
	}
	receiptKey struct {
		actor matter.ActorID
		key   matter.IdempotencyKey
	}
)

// NewMemoryStore returns an empty Store using the given clock (deterministic tests).
func NewMemoryStore(clock func() time.Time) *Store {
	return &Store{
		matters:       map[matter.MatterID]*matter.MatterHeader{},
		wsMemberships: map[wsKey]matter.WorkspaceMembership{},
		mMemberships:  map[mmKey]matter.MatterMembership{},
		nodes:         map[matter.NodeID]matter.Node{},
		requirements:  map[matter.RequirementID]matter.Requirement{},
		actions:       map[matter.NodeID]bool{},
		receipts:      map[receiptKey]matter.Receipt{},
		clock:         clock,
	}
}

// SetFailAt injects a failure into the matching transaction step ("" clears).
func (s *Store) SetFailAt(step string) { s.FailAt = step }

// SetCommitRollback simulates a known commit abort (nil clears).
func (s *Store) SetCommitRollback(err error) { s.CommitRollback = err }

// SetCommitUnknown simulates a lost commit acknowledgement (nil clears).
func (s *Store) SetCommitUnknown(err error) { s.CommitUnknown = err }

// snapshot deep-copies the state so a failed transaction can be discarded. Struct values
// are copied shallowly: rows are insert-only in this slice, so aliasing pointer fields
// across the copy cannot leak a rolled-back mutation.
func (s *Store) snapshot() *Store {
	cp := &Store{clock: s.clock}
	cp.matters = make(map[matter.MatterID]*matter.MatterHeader, len(s.matters))
	for k, v := range s.matters {
		h := *v
		if h.NextBoundaryAt != nil {
			t := *h.NextBoundaryAt
			h.NextBoundaryAt = &t
		}
		cp.matters[k] = &h
	}
	cp.wsMemberships = make(map[wsKey]matter.WorkspaceMembership, len(s.wsMemberships))
	for k, v := range s.wsMemberships {
		cp.wsMemberships[k] = v
	}
	cp.mMemberships = make(map[mmKey]matter.MatterMembership, len(s.mMemberships))
	for k, v := range s.mMemberships {
		cp.mMemberships[k] = v
	}
	cp.nodes = make(map[matter.NodeID]matter.Node, len(s.nodes))
	for k, v := range s.nodes {
		cp.nodes[k] = v
	}
	cp.requirements = make(map[matter.RequirementID]matter.Requirement, len(s.requirements))
	for k, v := range s.requirements {
		r := v
		cp.requirements[k] = r
	}
	cp.actions = make(map[matter.NodeID]bool, len(s.actions))
	for k, v := range s.actions {
		cp.actions[k] = v
	}
	cp.events = append([]matter.RequirementCreatedEvent(nil), s.events...)
	cp.receipts = make(map[receiptKey]matter.Receipt, len(s.receipts))
	for k, v := range s.receipts {
		rc := v
		rc.Matters = append([]matter.MatterID(nil), v.Matters...)
		if v.Snapshot != nil {
			snap := *v.Snapshot
			rc.Snapshot = &snap
		}
		if v.PurgeAfter != nil {
			t := *v.PurgeAfter
			rc.PurgeAfter = &t
		}
		cp.receipts[k] = rc
	}
	cp.audits = append([]matter.SecurityAuditEntry(nil), s.audits...)
	return cp
}

// Execute implements port.MatterStore with unconditional transaction semantics.
func (s *Store) Execute(ctx context.Context, matterID matter.MatterID, fn func(tx port.MatterTx) error) error {
	if err := ctx.Err(); err != nil {
		return fmt.Errorf("matter store: %w: %w", port.ErrUnavailable, err)
	}
	s.mu.Lock()
	defer s.mu.Unlock()

	header, ok := s.matters[matterID]
	if !ok {
		return port.ErrNotFound
	}
	tCmd := s.clock()
	if header.LastRecordedAt.After(tCmd) {
		tCmd = header.LastRecordedAt
	}

	work := s.snapshot()
	workHeader, _ := work.matters[matterID]
	tx := &memTx{store: work, header: *workHeader, tCmd: tCmd, failAt: s.FailAt}
	if err := fn(tx); err != nil {
		return err // rolled back: work is discarded
	}
	if s.CommitRollback != nil {
		return fmt.Errorf("matter store commit: %w: %w", port.ErrUnavailable, s.CommitRollback)
	}
	s.adopt(work)
	if s.CommitUnknown != nil {
		return fmt.Errorf("matter store commit: %w: %w", port.ErrOutcomeUnknown, s.CommitUnknown)
	}
	return nil
}

// adopt replaces the live state with the committed working copy.
func (s *Store) adopt(work *Store) {
	s.matters = work.matters
	s.wsMemberships = work.wsMemberships
	s.mMemberships = work.mMemberships
	s.nodes = work.nodes
	s.requirements = work.requirements
	s.actions = work.actions
	s.events = work.events
	s.receipts = work.receipts
	s.audits = work.audits
}

// View implements port.MatterStore with a point-in-time copy.
func (s *Store) View(ctx context.Context, fn func(snap port.MatterSnapshot) error) error {
	if err := ctx.Err(); err != nil {
		return fmt.Errorf("matter store: %w: %w", port.ErrUnavailable, err)
	}
	s.mu.Lock()
	frozen := s.snapshot()
	asOf := s.clock()
	failAt := s.FailAt
	s.mu.Unlock()
	return fn(&memSnapshot{state: frozen, asOf: asOf, failAt: failAt})
}

type memTx struct {
	store  *Store
	header matter.MatterHeader
	tCmd   time.Time
	failAt string
}

func (t *memTx) Matter() matter.MatterHeader { return t.header }
func (t *memTx) TCmd() time.Time             { return t.tCmd }

func (t *memTx) fail(step string) error {
	if t.failAt == step {
		return fmt.Errorf("injected failure at %s", step)
	}
	return nil
}

// membershipFailure returns the injected membership lookup error for the given step
// name, or nil when the step does not match. Unavailable mirrors the adapters'
// wrapped ErrUnavailable shape; unexpected is any non-ErrNotFound failure. Only
// ErrNotFound (never injected here) means absence.
func membershipFailure(failAt, step string) error {
	switch failAt {
	case step + "_unavailable":
		return fmt.Errorf("memory store: %w: %w", port.ErrUnavailable, ErrInjected)
	case step + "_unexpected":
		return fmt.Errorf("memory store: %w", ErrInjected)
	}
	return nil
}

func (t *memTx) WorkspaceMembership(_ context.Context, ws matter.WorkspaceID, actor matter.ActorID) (matter.WorkspaceMembership, error) {
	if err := membershipFailure(t.failAt, "membership"); err != nil {
		return matter.WorkspaceMembership{}, err
	}
	m, ok := t.store.wsMemberships[wsKey{ws, actor}]
	if !ok {
		return matter.WorkspaceMembership{}, port.ErrNotFound
	}
	return m, nil
}

func (t *memTx) MatterMembership(_ context.Context, m matter.MatterID, actor matter.ActorID) (matter.MatterMembership, error) {
	if err := membershipFailure(t.failAt, "membership"); err != nil {
		return matter.MatterMembership{}, err
	}
	mm, ok := t.store.mMemberships[mmKey{m, actor}]
	if !ok {
		return matter.MatterMembership{}, port.ErrNotFound
	}
	return mm, nil
}

func (t *memTx) Receipt(_ context.Context, actor matter.ActorID, key matter.IdempotencyKey) (matter.Receipt, error) {
	rc, ok := t.store.receipts[receiptKey{actor, key}]
	if !ok {
		return matter.Receipt{}, port.ErrNotFound
	}
	return rc, nil
}

func (t *memTx) InsertNode(_ context.Context, node matter.Node) error {
	if err := t.fail("insert_node"); err != nil {
		return err
	}
	if _, exists := t.store.nodes[node.ID]; exists {
		return fmt.Errorf("memory: node %s already exists", node.ID)
	}
	t.store.nodes[node.ID] = node
	return nil
}

func (t *memTx) InsertRequirement(_ context.Context, r matter.Requirement) error {
	if err := t.fail("insert_requirement"); err != nil {
		return err
	}
	if _, exists := t.store.requirements[r.ID]; exists {
		return fmt.Errorf("memory: requirement %s already exists", r.ID)
	}
	t.store.requirements[r.ID] = r
	return nil
}

func (t *memTx) AppendRequirementCreated(_ context.Context, e matter.RequirementCreatedEvent) error {
	if err := t.fail("append_event"); err != nil {
		return err
	}
	t.store.events = append(t.store.events, e)
	return nil
}

func (t *memTx) StoreReceipt(_ context.Context, rc matter.Receipt) error {
	if err := t.fail("store_receipt"); err != nil {
		return err
	}
	k := receiptKey{rc.ActorID, rc.IdempotencyKey}
	if _, exists := t.store.receipts[k]; exists {
		return fmt.Errorf("memory receipt: %w", port.ErrIdempotencyKeyReuse)
	}
	t.store.receipts[k] = rc
	return nil
}

func (t *memTx) CompleteMatter(_ context.Context, seq int64, tCmd time.Time) error {
	if err := t.fail("complete_matter"); err != nil {
		return err
	}
	h := t.store.matters[t.header.MatterID]
	h.EventSeq = seq
	h.LastRecordedAt = tCmd
	h.BoundariesAppliedUntil = tCmd
	h.Revision++
	t.store.matters[t.header.MatterID] = h
	return nil
}

func (t *memTx) RecordSecurityAudit(_ context.Context, e matter.SecurityAuditEntry) error {
	t.store.audits = append(t.store.audits, e)
	return nil
}

type memSnapshot struct {
	state  *Store
	asOf   time.Time
	failAt string
}

func (s *memSnapshot) AsOf() time.Time { return s.asOf }

func (s *memSnapshot) RequirementByID(_ context.Context, id matter.RequirementID) (matter.Requirement, matter.MatterID, error) {
	r, ok := s.state.requirements[id]
	if !ok {
		// Absent typed row covers nonexistent ids and ACTION nodes alike: uniform outcome.
		return matter.Requirement{}, "", port.ErrNotFound
	}
	return r, r.MatterID, nil
}

func (s *memSnapshot) MatterHeader(_ context.Context, id matter.MatterID) (matter.MatterHeader, error) {
	h, ok := s.state.matters[id]
	if !ok {
		return matter.MatterHeader{}, port.ErrNotFound
	}
	return *h, nil
}

func (s *memSnapshot) WorkspaceMembership(_ context.Context, ws matter.WorkspaceID, actor matter.ActorID) (matter.WorkspaceMembership, error) {
	if err := membershipFailure(s.failAt, "membership"); err != nil {
		return matter.WorkspaceMembership{}, err
	}
	m, ok := s.state.wsMemberships[wsKey{ws, actor}]
	if !ok {
		return matter.WorkspaceMembership{}, port.ErrNotFound
	}
	return m, nil
}

func (s *memSnapshot) MatterMembership(_ context.Context, m matter.MatterID, actor matter.ActorID) (matter.MatterMembership, error) {
	if err := membershipFailure(s.failAt, "membership"); err != nil {
		return matter.MatterMembership{}, err
	}
	mm, ok := s.state.mMemberships[mmKey{m, actor}]
	if !ok {
		return matter.MatterMembership{}, port.ErrNotFound
	}
	return mm, nil
}

// MemoryWorld is the World implementation over a Store.
type MemoryWorld struct {
	store *Store
}

// NewMemoryWorld wires a World around store.
func NewMemoryWorld(store *Store) *MemoryWorld { return &MemoryWorld{store: store} }

// Store exposes the underlying store.
func (w *MemoryWorld) Store() *Store { return w.store }

func (w *MemoryWorld) AddUser(matter.ActorID) {}

// AddWorkspace is a no-op in the double: workspace facts live on memberships and the
// matter header, and this slice has no workspace commands to observe.
func (w *MemoryWorld) AddWorkspace(matter.WorkspaceID) {}

func (w *MemoryWorld) SetWorkspaceMembership(workspace matter.WorkspaceID, actor matter.ActorID, role matter.WorkspaceRole, status matter.MembershipStatus) {
	w.store.mu.Lock()
	defer w.store.mu.Unlock()
	w.store.wsMemberships[wsKey{workspace, actor}] = matter.WorkspaceMembership{
		WorkspaceID: workspace, ActorID: actor, Role: role, Status: status,
	}
}

func (w *MemoryWorld) AddMatter(id matter.MatterID, workspace matter.WorkspaceID) {
	w.store.mu.Lock()
	defer w.store.mu.Unlock()
	w.store.matters[id] = &matter.MatterHeader{MatterID: id, WorkspaceID: workspace}
}

func (w *MemoryWorld) SetMatterMembership(m matter.MatterID, actor matter.ActorID, role matter.MatterRole, status matter.MembershipStatus) {
	w.store.mu.Lock()
	defer w.store.mu.Unlock()
	w.store.mMemberships[mmKey{m, actor}] = matter.MatterMembership{
		MatterID: m, ActorID: actor, Role: role, Status: status,
	}
}

func (w *MemoryWorld) InsertActionNode(id matter.NodeID, m matter.MatterID) {
	w.store.mu.Lock()
	defer w.store.mu.Unlock()
	w.store.nodes[id] = matter.Node{ID: id, MatterID: m, Kind: matter.NodeAction}
	w.store.actions[id] = true
}

// SetElapsedBoundary pins a pending boundary one tick before the next command
// instant: with the deterministic clock, every later command on the matter is due
// to process it.
func (w *MemoryWorld) SetElapsedBoundary(m matter.MatterID) {
	w.store.mu.Lock()
	defer w.store.mu.Unlock()
	h, ok := w.store.matters[m]
	if !ok {
		panic("mattercontrol: SetElapsedBoundary on unknown matter " + m)
	}
	due := w.store.clock().Add(-time.Second)
	h.NextBoundaryAt = &due
}

// SetFutureBoundary pins a pending boundary well after the command clock.
func (w *MemoryWorld) SetFutureBoundary(m matter.MatterID) {
	w.store.mu.Lock()
	defer w.store.mu.Unlock()
	h, ok := w.store.matters[m]
	if !ok {
		panic("mattercontrol: SetFutureBoundary on unknown matter " + m)
	}
	due := w.store.clock().Add(time.Hour)
	h.NextBoundaryAt = &due
}

// NextBoundary reports the matter's pending boundary, if any.
func (w *MemoryWorld) NextBoundary(m matter.MatterID) (time.Time, bool) {
	w.store.mu.Lock()
	defer w.store.mu.Unlock()
	h, ok := w.store.matters[m]
	if !ok || h.NextBoundaryAt == nil {
		return time.Time{}, false
	}
	return *h.NextBoundaryAt, true
}

func (w *MemoryWorld) Counts() Counts {
	w.store.mu.Lock()
	defer w.store.mu.Unlock()
	totalReceiptMatters := 0
	for _, rc := range w.store.receipts {
		totalReceiptMatters += len(rc.Matters)
	}
	return Counts{
		Nodes:            len(w.store.nodes),
		Requirements:     len(w.store.requirements),
		Actions:          len(w.store.actions),
		Events:           len(w.store.events),
		Receipts:         len(w.store.receipts),
		ReceiptMatters:   totalReceiptMatters,
		Audits:           len(w.store.audits),
		Matters:          len(w.store.matters),
		WorkspaceMembers: len(w.store.wsMemberships),
		MatterMembers:    len(w.store.mMemberships),
	}
}

func (w *MemoryWorld) Requirement(id matter.RequirementID) (matter.Requirement, bool) {
	w.store.mu.Lock()
	defer w.store.mu.Unlock()
	r, ok := w.store.requirements[id]
	return r, ok
}

func (w *MemoryWorld) Events() []matter.RequirementCreatedEvent {
	w.store.mu.Lock()
	defer w.store.mu.Unlock()
	return append([]matter.RequirementCreatedEvent(nil), w.store.events...)
}

func (w *MemoryWorld) Receipts() []matter.Receipt {
	w.store.mu.Lock()
	defer w.store.mu.Unlock()
	out := make([]matter.Receipt, 0, len(w.store.receipts))
	for _, rc := range w.store.receipts {
		out = append(out, rc)
	}
	return out
}

func (w *MemoryWorld) Audits() []matter.SecurityAuditEntry {
	w.store.mu.Lock()
	defer w.store.mu.Unlock()
	return append([]matter.SecurityAuditEntry(nil), w.store.audits...)
}

// Reopen returns the same store handle: the double has no connection lifecycle.
func (w *MemoryWorld) Reopen() port.MatterStore { return w.store }
