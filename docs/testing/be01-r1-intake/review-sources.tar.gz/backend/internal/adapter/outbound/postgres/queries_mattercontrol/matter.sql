-- Named queries for the MatterControl transaction spine (mcsqlc). Explicit columns;
-- parameters cast where sqlc would infer a narrower type.

-- name: LockMatter :one
SELECT id AS matter_id, workspace_id, event_seq, revision, last_recorded_at,
       boundaries_applied_until, next_boundary_at,
       GREATEST(clock_timestamp(), last_recorded_at)::timestamptz AS t_cmd
FROM matters WHERE id = $1 FOR UPDATE;

-- name: GetMatterHeader :one
SELECT id AS matter_id, workspace_id, event_seq, revision, last_recorded_at,
       boundaries_applied_until, next_boundary_at
FROM matters WHERE id = $1;

-- name: GetSnapshotAsOf :one
SELECT clock_timestamp()::timestamptz AS as_of;

-- name: GetWorkspaceMembershipForShare :one
SELECT workspace_id, user_id, role, status, revision
FROM workspace_memberships WHERE workspace_id = $1 AND user_id = $2 FOR SHARE;

-- name: GetWorkspaceMembership :one
SELECT workspace_id, user_id, role, status, revision
FROM workspace_memberships WHERE workspace_id = $1 AND user_id = $2;

-- name: GetMatterMembershipForShare :one
SELECT matter_id, user_id, role, status, revision
FROM matter_memberships WHERE matter_id = $1 AND user_id = $2 FOR SHARE;

-- name: GetMatterMembership :one
SELECT matter_id, user_id, role, status, revision
FROM matter_memberships WHERE matter_id = $1 AND user_id = $2;

-- name: FindReceipt :one
SELECT actor_id, idempotency_key, request_hash, scope_kind, workspace_id, matter_id,
       status_code, response, committed_at, purge_after
FROM command_receipts WHERE actor_id = $1 AND idempotency_key = $2;

-- name: ListReceiptMatters :many
SELECT represented_matter_id FROM command_receipt_matters
WHERE actor_id = $1 AND idempotency_key = $2;

-- name: InsertGraphNode :exec
INSERT INTO graph_nodes (id, matter_id, kind) VALUES ($1, $2, $3);

-- name: InsertRequirement :exec
INSERT INTO requirements (id, kind, matter_id, title, outcome, execution_state,
                          dependency_state, verification_state, verification_applicability,
                          proof_epoch, revision)
VALUES ($1, 'REQUIREMENT', $2, $3, $4, $5, $6, $7, $8, $9, $10);

-- name: InsertRequirementCreatedEvent :exec
INSERT INTO domain_events (matter_id, seq, id, type, schema_version, actor_kind, actor_id,
                           target_kind, target_id, effective_at, recorded_at, command_key, after)
VALUES ($1, $2, $3, 'requirement.created', 1, 'USER', $4, 'REQUIREMENT', $5, $6, $7, $8, $9);

-- name: InsertCommandReceipt :exec
INSERT INTO command_receipts (actor_id, idempotency_key, request_hash, scope_kind,
                              workspace_id, matter_id, status_code, response, committed_at, purge_after)
VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10);

-- name: InsertCommandReceiptMatter :exec
INSERT INTO command_receipt_matters (actor_id, idempotency_key, represented_matter_id)
VALUES ($1, $2, $3);

-- name: CompleteMatter :exec
-- The service refuses any boundary due at t_cmd before mutating, so a next_boundary_at
-- that still exists here is strictly in the future and must be preserved, never
-- silently cleared: an unevaluated boundary stays pending.
UPDATE matters SET event_seq = $2, last_recorded_at = $3, boundaries_applied_until = $3,
                   revision = revision + 1
WHERE id = $1;

-- name: InsertSecurityAuditEvent :exec
INSERT INTO security_audit_events (id, occurred_at, actor_id, operation, outcome,
                                   requested_resource_kind, requested_id_hash)
VALUES ($1, $2, $3, $4, $5, $6, $7);

-- name: GetRequirementByID :one
SELECT id, matter_id, title, outcome, execution_state, dependency_state,
       verification_state, verification_applicability, applicability_reason,
       proof_epoch, workstream_id, owner_user_id, due_at, revision
FROM requirements WHERE id = $1;
