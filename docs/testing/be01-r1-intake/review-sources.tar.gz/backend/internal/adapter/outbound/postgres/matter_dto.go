package postgres

import (
	"encoding/hex"
	"encoding/json"
	"fmt"
	"time"

	"github.com/google/uuid"
	"github.com/jackc/pgx/v5/pgtype"

	"github.com/example/userapi/internal/adapter/outbound/postgres/mcsqlc"
	"github.com/example/userapi/internal/core/domain/matter"
)

// Receipt and event payloads are adapter-owned DTOs: the domain has no JSON tags, so
// serialization lives at the persistence boundary, following the repository convention.

type requirementDTO struct {
	ID                        string  `json:"id"`
	MatterID                  string  `json:"matterId"`
	Title                     string  `json:"title"`
	Outcome                   string  `json:"outcome"`
	ExecutionState            string  `json:"executionState"`
	DependencyState           string  `json:"dependencyState"`
	VerificationState         string  `json:"verificationState"`
	VerificationApplicability string  `json:"verificationApplicability"`
	ApplicabilityReason       *string `json:"applicabilityReason"`
	ProofEpoch                int64   `json:"proofEpoch"`
	WorkstreamID              *string `json:"workstreamId"`
	OwnerActorID              *string `json:"ownerActorId"`
	DueAt                     *string `json:"dueAt"`
	Revision                  int64   `json:"revision"`
}

type createdResultDTO struct {
	Requirement    requirementDTO `json:"requirement"`
	Seq            int64          `json:"seq"`
	RecordedAt     string         `json:"recordedAt"`
	IdempotencyKey string         `json:"idempotencyKey"`
	RequestHash    string         `json:"requestHash"`
}

func requirementToDTO(r matter.Requirement) requirementDTO {
	dto := requirementDTO{
		ID:                        r.ID.String(),
		MatterID:                  r.MatterID.String(),
		Title:                     r.Title,
		Outcome:                   r.Outcome,
		ExecutionState:            string(r.ExecutionState),
		DependencyState:           string(r.DependencyState),
		VerificationState:         string(r.VerificationState),
		VerificationApplicability: string(r.VerificationApplicability),
		ApplicabilityReason:       r.ApplicabilityReason,
		ProofEpoch:                r.ProofEpoch,
		Revision:                  r.Revision,
	}
	if r.WorkstreamID != nil {
		s := r.WorkstreamID.String()
		dto.WorkstreamID = &s
	}
	if r.OwnerActorID != nil {
		s := r.OwnerActorID.String()
		dto.OwnerActorID = &s
	}
	// Create fixes DueAt to nil; no temporal serialization exists in this slice.
	return dto
}

func (d requirementDTO) toDomain() matter.Requirement {
	r := matter.Requirement{
		ID:                        matter.RequirementID(d.ID),
		MatterID:                  matter.MatterID(d.MatterID),
		Title:                     d.Title,
		Outcome:                   d.Outcome,
		ExecutionState:            matter.ExecutionState(d.ExecutionState),
		DependencyState:           matter.DependencyState(d.DependencyState),
		VerificationState:         matter.VerificationState(d.VerificationState),
		VerificationApplicability: matter.VerificationApplicability(d.VerificationApplicability),
		ApplicabilityReason:       d.ApplicabilityReason,
		ProofEpoch:                d.ProofEpoch,
		Revision:                  d.Revision,
	}
	if d.WorkstreamID != nil {
		id := matter.WorkstreamID(*d.WorkstreamID)
		r.WorkstreamID = &id
	}
	if d.OwnerActorID != nil {
		id := matter.ActorID(*d.OwnerActorID)
		r.OwnerActorID = &id
	}
	return r
}

func encodeRequirementJSON(r matter.Requirement) ([]byte, error) {
	b, err := json.Marshal(requirementToDTO(r))
	if err != nil {
		return nil, fmt.Errorf("marshal requirement: %w", err)
	}
	return b, nil
}

func encodeCreatedResultJSON(res *matter.RequirementCreatedResult) ([]byte, error) {
	if res == nil {
		return nil, fmt.Errorf("nil receipt snapshot")
	}
	dto := createdResultDTO{
		Requirement:    requirementToDTO(res.Requirement),
		Seq:            res.Seq,
		RecordedAt:     res.RecordedAt.UTC().Format(time.RFC3339Nano),
		IdempotencyKey: res.IdempotencyKey.String(),
		RequestHash:    res.RequestHash.String(),
	}
	b, err := json.Marshal(dto)
	if err != nil {
		return nil, fmt.Errorf("marshal receipt snapshot: %w", err)
	}
	return b, nil
}

func decodeCreatedResult(b []byte) (*matter.RequirementCreatedResult, error) {
	var dto createdResultDTO
	if err := json.Unmarshal(b, &dto); err != nil {
		return nil, fmt.Errorf("unmarshal receipt snapshot: %w", err)
	}
	recordedAt, err := time.Parse(time.RFC3339Nano, dto.RecordedAt)
	if err != nil {
		return nil, fmt.Errorf("receipt snapshot recordedAt: %w", err)
	}
	// Replayed stays false in stored snapshots; the service marks replayed copies.
	return &matter.RequirementCreatedResult{
		Requirement:    dto.Requirement.toDomain(),
		Seq:            dto.Seq,
		RecordedAt:     recordedAt.UTC(),
		IdempotencyKey: matter.IdempotencyKey(dto.IdempotencyKey),
		RequestHash:    matter.RequestHash(dto.RequestHash),
	}, nil
}

func requirementFromRow(row mcsqlc.GetRequirementByIDRow) (matter.Requirement, error) {
	r := matter.Requirement{
		ID:                        matter.RequirementID(row.ID),
		MatterID:                  matter.MatterID(row.MatterID),
		Title:                     row.Title,
		Outcome:                   row.Outcome,
		ExecutionState:            matter.ExecutionState(row.ExecutionState),
		DependencyState:           matter.DependencyState(row.DependencyState),
		VerificationState:         matter.VerificationState(row.VerificationState),
		VerificationApplicability: matter.VerificationApplicability(row.VerificationApplicability),
		ProofEpoch:                int64(row.ProofEpoch),
		Revision:                  row.Revision,
	}
	if row.ApplicabilityReason.Valid {
		s := row.ApplicabilityReason.String
		r.ApplicabilityReason = &s
	}
	if row.WorkstreamID.Valid {
		id := matter.WorkstreamID(uuid.UUID(row.WorkstreamID.Bytes).String())
		r.WorkstreamID = &id
	}
	if row.OwnerUserID.Valid {
		id := matter.ActorID(uuid.UUID(row.OwnerUserID.Bytes).String())
		r.OwnerActorID = &id
	}
	if row.DueAt.Valid {
		t := row.DueAt.Time.UTC()
		r.DueAt = &t
	}
	return r, nil
}

// hexHash decodes the 64-character hex fingerprint into bytes for BYTEA storage.
func hexHash(h matter.RequestHash) ([]byte, error) {
	b, err := hex.DecodeString(h.String())
	if err != nil {
		return nil, fmt.Errorf("matter store: decode request hash: %w", err)
	}
	return b, nil
}

func uuidPtr(u pgtype.UUID) *matter.MatterID {
	if !u.Valid {
		return nil
	}
	id := matter.MatterID(uuid.UUID(u.Bytes).String())
	return &id
}

func uuidVal(id *matter.MatterID) pgtype.UUID {
	if id == nil {
		return pgtype.UUID{}
	}
	parsed, err := uuid.Parse(id.String())
	if err != nil {
		return pgtype.UUID{}
	}
	return pgtype.UUID{Bytes: parsed, Valid: true}
}

func uuidString(s string) pgtype.UUID {
	parsed, err := uuid.Parse(s)
	if err != nil {
		return pgtype.UUID{}
	}
	return pgtype.UUID{Bytes: parsed, Valid: true}
}

func timestamptzPtr(t pgtype.Timestamptz) *time.Time {
	if !t.Valid {
		return nil
	}
	v := t.Time.UTC()
	return &v
}

func timestamptzVal(t *time.Time) pgtype.Timestamptz {
	if t == nil {
		return pgtype.Timestamptz{}
	}
	return pgtype.Timestamptz{Time: t.UTC(), Valid: true}
}

func pgText(s string) pgtype.Text {
	if s == "" {
		return pgtype.Text{}
	}
	return pgtype.Text{String: s, Valid: true}
}
