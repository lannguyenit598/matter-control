package port

import "errors"

// Use-case outcome errors shared by all aggregates. These belong to the application layer,
// not domain: "not found" and "concurrent modification" are read/write outcomes,
// not business rules. Add context by wrapping, for example
// fmt.Errorf("user %s: %w", id, port.ErrNotFound); compare with errors.Is.
// Repositories return bare sentinels; services add context.
var (
	ErrNotFound = errors.New("not found")
	// ErrVersionConflict means the record changed since it was read (optimistic locking).
	ErrVersionConflict = errors.New("version conflict")
	// ErrUnavailable means storage is temporarily unreachable or busy (connection failure,
	// administrator termination, statement timeout, pool exhaustion, lock/deadlock conditions).
	// It maps to a retryable HTTP 503. A failed write's outcome is unknown, never "not applied".
	ErrUnavailable = errors.New("service temporarily unavailable")
	// ErrForbidden means the caller is an active member of the matter but the role lacks
	// the operation (use-case outcome, not a business rule).
	ErrForbidden = errors.New("forbidden")
	// ErrIdempotencyKeyReuse means the same (actor, idempotency key) pair was presented
	// with a different command fingerprint. The stored outcome of the earlier command is
	// never returned in this case.
	ErrIdempotencyKeyReuse = errors.New("idempotency key already used for a different command")
	// ErrOutcomeUnknown means a command reached its commit point but the acknowledgement
	// was lost: the command may or may not have committed. Callers must never treat this
	// as proof of rollback and must retry with the SAME idempotency key.
	ErrOutcomeUnknown = errors.New("command outcome unknown")
)
