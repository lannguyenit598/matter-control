# Mimosa Security Scan

- Scan: `scan-2026-10-26T00-40-19.307Z-e324c2f15ce2`
- Created: 2026-10-26T00:40:19.307Z
- Depth: deep
- Run status: **inconclusive**
- Findings: 1 (0 business-logic candidate)
- 覆盖缺口:
  - 调用图部分不完整:部分调用为动态派发或超出分析规模,跨文件可达性可能不完整
- Verdict effect: `none`

## Findings

### HIGH · 硬编码凭据 (docs/testing/inta-returns/environment/env-intamvnmoems3pd/provision-command.py:46)

static · static-finding

POSTGRES_PASSWORD 的凭据值直接写在源码中，提交后可能造成密钥泄露。


---

This report is a projection of sealed JSON artifacts. It is not runtime verification.
