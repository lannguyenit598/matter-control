import { describe, expect, it, beforeEach, afterEach } from 'vitest'
import fs from 'node:fs'
import path from 'node:path'
import {
  HarnessDriver,
  generateRunId,
  validateRunId,
  assertNoRunIdCollision,
  CANONICAL_36_LOGICAL_IDS,
  UUIDV7_LOWERCASE_REGEX,
} from '../src/driver.js'
import type { HarnessEnvelope } from '../src/envelope.js'

describe('HarnessDriver (INTA-FE-R02)', () => {
  const testStateDir = path.join(process.cwd(), '.test-driver-state')
  const testEvidenceDir = path.join(process.cwd(), '.test-driver-evidence')

  beforeEach(() => {
    fs.mkdirSync(testStateDir, { recursive: true })
    fs.mkdirSync(testEvidenceDir, { recursive: true })
  })

  afterEach(() => {
    try {
      fs.rmSync(testStateDir, { recursive: true, force: true })
      fs.rmSync(testEvidenceDir, { recursive: true, force: true })
    } catch {}
  })

  it('generates valid 8-32 alphanumeric runId', () => {
    const runId = generateRunId()
    expect(validateRunId(runId)).toBe(true)
    expect(runId.length).toBeGreaterThanOrEqual(8)
    expect(runId.length).toBeLessThanOrEqual(32)
    expect(/^[a-zA-Z0-9]+$/.test(runId)).toBe(true)
  })

  it('refuses collision when evidence folder for runId already exists (R02)', () => {
    const existingRunId = 'existingrun1234'
    const collisionDir = path.join(testEvidenceDir, 'frontend', existingRunId)
    fs.mkdirSync(collisionDir, { recursive: true })

    expect(() =>
      assertNoRunIdCollision(existingRunId, testEvidenceDir, testStateDir),
    ).toThrow(/RunId collision refused: existing evidence found/)
  })

  it('contains all 36 required canonical logical IDs', () => {
    expect(CANONICAL_36_LOGICAL_IDS).toHaveLength(36)
    // Check key required IDs
    expect(CANONICAL_36_LOGICAL_IDS).toContain('INT-ENV-01')
    expect(CANONICAL_36_LOGICAL_IDS).toContain('INT-ENV-05')
    expect(CANONICAL_36_LOGICAL_IDS).toContain('INT-ENV-06')
    expect(CANONICAL_36_LOGICAL_IDS).toContain('INT-ENV-07')
    expect(CANONICAL_36_LOGICAL_IDS).toContain('T1')
    expect(CANONICAL_36_LOGICAL_IDS).toContain('T2')
    expect(CANONICAL_36_LOGICAL_IDS).toContain('T5')
    expect(CANONICAL_36_LOGICAL_IDS).toContain('T8')
    expect(CANONICAL_36_LOGICAL_IDS).toContain('T9')
    expect(CANONICAL_36_LOGICAL_IDS).toContain('T10')
    expect(CANONICAL_36_LOGICAL_IDS).toContain('T11a')
    expect(CANONICAL_36_LOGICAL_IDS).toContain('T11b')
    expect(CANONICAL_36_LOGICAL_IDS).toContain('T11c')
    expect(CANONICAL_36_LOGICAL_IDS).toContain('T12')
    expect(CANONICAL_36_LOGICAL_IDS).toContain('W1')
    expect(CANONICAL_36_LOGICAL_IDS).toContain('W9')
    expect(CANONICAL_36_LOGICAL_IDS).toContain('W11')
    expect(CANONICAL_36_LOGICAL_IDS).toContain('INT-PERS-01')
    expect(CANONICAL_36_LOGICAL_IDS).toContain('INT-PERS-02')
    expect(CANONICAL_36_LOGICAL_IDS).toContain('INT-PERS-03')
    expect(CANONICAL_36_LOGICAL_IDS).toContain('INT-PERS-04')
    expect(CANONICAL_36_LOGICAL_IDS).toContain('INT-COR-01')
    expect(CANONICAL_36_LOGICAL_IDS).toContain('INT-PRIV-01')
    expect(CANONICAL_36_LOGICAL_IDS).toContain('INT-ISO-01')
    expect(CANONICAL_36_LOGICAL_IDS).toContain('INT-ISO-02')
    expect(CANONICAL_36_LOGICAL_IDS).toContain('INT-ISO-03')
    expect(CANONICAL_36_LOGICAL_IDS).toContain('INT-CONF-01')
  })

  it('records Checkpoint A from valid T1 envelope and verifies RFC 3339 UTC timestamps (R01, R02)', () => {
    const driver = new HarnessDriver('drivertest123', testStateDir)
    const validT1Envelope: HarnessEnvelope = {
      runId: 'drivertest123',
      caseId: 'T1',
      requestId: 'mc-int-drivertest123-T1-1',
      mode: 'app-client',
      method: 'POST',
      routeTemplate: '/api/v1/users',
      startedAtUTC: '2026-10-25T03:00:00Z',
      latencyMs: 15,
      actualNextVersion: '16.4.2',
      harnessRevision: 'e25bbc6933264fc46a729e6a364a3bfa02d8038f',
      outcome: 'value',
      classification: 'success',
      value: {
        id: '0192e23b-6e9f-7b71-91ea-42b7e199db1c',
        email: 'inta-a-drivertest123@example.test',
        name: 'INTA_A_INITIAL',
        version: 1,
        created_at: '2026-10-25T03:00:00.123456Z',
        updated_at: '2026-10-25T03:00:00.123456Z',
      },
      apiError: null,
      wire: null,
      truncated: false,
    }

    const cp = driver.assertT1(validT1Envelope)
    expect(cp.id).toBe('0192e23b-6e9f-7b71-91ea-42b7e199db1c')
    expect(cp.version).toBe(1)
    expect(driver.state.assertions.get('T1')?.pass).toBe(true)

    // T2 assertion
    const validT2Envelope: HarnessEnvelope = {
      ...validT1Envelope,
      caseId: 'T2',
      requestId: 'mc-int-drivertest123-T2-1',
      method: 'GET',
      routeTemplate: '/api/v1/users/{id}',
    }
    expect(() => driver.assertT2(validT2Envelope)).not.toThrow()
    expect(driver.state.assertions.get('T2')?.pass).toBe(true)
  })

  it('blocks assertion acceptance when evidence is truncated (R05)', () => {
    const driver = new HarnessDriver('truncatetest1', testStateDir)
    const truncatedEnvelope: HarnessEnvelope = {
      runId: 'truncatetest1',
      caseId: 'T1',
      requestId: 'mc-int-truncatetest1-T1-1',
      mode: 'app-client',
      method: 'POST',
      routeTemplate: '/api/v1/users',
      startedAtUTC: '2026-10-25T03:00:00Z',
      latencyMs: 15,
      actualNextVersion: '16.4.2',
      harnessRevision: 'e25bbc6933264fc46a729e6a364a3bfa02d8038f',
      outcome: 'value',
      classification: 'success',
      value: 'truncated-string-content',
      apiError: null,
      wire: null,
      truncated: true,
    }

    expect(() => driver.assertT1(truncatedEnvelope)).toThrow(/T1 assertion blocked: envelope body was truncated/)
    expect(driver.state.assertions.get('T1')?.blocked).toBe(true)
  })

  it('pauses safely for upstream coordination before execution', () => {
    const driver = new HarnessDriver('pausetest123', testStateDir)
    driver.pauseForUpstreamCoordination(false)
    expect(driver.state.phase).toBe('PAUSED_WAITING_ENV')

    driver.pauseForUpstreamCoordination(true)
    expect(driver.state.phase).toBe('ENV_COORDINATED_READY')
  })

  it('validates UUIDv7 version digit and variant strictly (F01)', () => {
    // Valid UUIDv7 (version 7, variant 8, 9, a, or b)
    expect(UUIDV7_LOWERCASE_REGEX.test('0192e23b-6e9f-7b71-91ea-42b7e199db1c')).toBe(true)
    // Invalid: version 4
    expect(UUIDV7_LOWERCASE_REGEX.test('0192e23b-6e9f-4b71-91ea-42b7e199db1c')).toBe(false)
    // Invalid: uppercase
    expect(UUIDV7_LOWERCASE_REGEX.test('0192E23B-6E9F-7B71-91EA-42B7E199DB1C')).toBe(false)
  })

  it('refuses T1 when email or name does not match fixture A (F01)', () => {
    const driver = new HarnessDriver('fixtest1234', testStateDir)
    const baseEnvelope: HarnessEnvelope = {
      runId: 'fixtest1234',
      caseId: 'T1',
      requestId: 'mc-int-fixtest1234-T1-1',
      mode: 'app-client',
      method: 'POST',
      routeTemplate: '/api/v1/users',
      startedAtUTC: '2026-10-25T03:00:00Z',
      latencyMs: 15,
      actualNextVersion: '16.4.2',
      harnessRevision: '6e2f65b51e7ead3c84274e717f8f3bcaeccf9b91',
      outcome: 'value',
      classification: 'success',
      value: {
        id: '0192e23b-6e9f-7b71-91ea-42b7e199db1c',
        email: 'wrong-email@example.test',
        name: 'INTA_A_INITIAL',
        version: 1,
        created_at: '2026-10-25T03:00:00.000Z',
        updated_at: '2026-10-25T03:00:00.000Z',
      },
      apiError: null,
      wire: null,
      truncated: false,
    }

    expect(() => driver.assertT1(baseEnvelope)).toThrow(/email mismatch vs fixture A/)

    // Wrong name
    const wrongNameEnv: HarnessEnvelope = {
      ...baseEnvelope,
      value: {
        ...(baseEnvelope.value as any),
        email: 'inta-a-fixtest1234@example.test',
        name: 'WRONG_NAME',
      },
    }
    expect(() => driver.assertT1(wrongNameEnv)).toThrow(/name mismatch vs fixture A/)
  })

  it('enforces write-once envelope persistence and refuses duplicate mutation replay (F01)', () => {
    const driver = new HarnessDriver('wronce12345', testStateDir)
    const dummyEnvelope: HarnessEnvelope = {
      runId: 'wronce12345',
      caseId: 'T1',
      requestId: 'mc-int-wronce12345-T1-1',
      mode: 'app-client',
      method: 'POST',
      routeTemplate: '/api/v1/users',
      startedAtUTC: '2026-10-25T03:00:00Z',
      latencyMs: 10,
      actualNextVersion: '16.4.2',
      harnessRevision: '6e2f65b51e7ead3c84274e717f8f3bcaeccf9b91',
      outcome: 'value',
      classification: 'success',
      value: { id: '0192e23b-6e9f-7b71-91ea-42b7e199db1c' },
      apiError: null,
      wire: null,
      truncated: false,
    }

    // First write succeeds
    expect(() => driver.persistEnvelope('T1', [dummyEnvelope])).not.toThrow()

    // Idempotent byte-equal write succeeds without error
    expect(() => driver.persistEnvelope('T1', [dummyEnvelope])).not.toThrow()

    // Conflicting duplicate execution throws refusal
    const conflictingEnv: HarnessEnvelope = {
      ...dummyEnvelope,
      requestId: 'mc-int-wronce12345-T1-2', // Different requestId
    }
    expect(() => driver.persistEnvelope('T1', [conflictingEnv])).toThrow(
      /Duplicate case execution refused by write-once ledger: T1 already executed/,
    )
  })

  it('persists and restores durable checkpoints across restarts (F01)', () => {
    const runId = 'durable12345'
    const driver1 = new HarnessDriver(runId, testStateDir)

    const validT1Envelope: HarnessEnvelope = {
      runId,
      caseId: 'T1',
      requestId: `mc-int-${runId}-T1-1`,
      mode: 'app-client',
      method: 'POST',
      routeTemplate: '/api/v1/users',
      startedAtUTC: '2026-10-25T03:00:00Z',
      latencyMs: 15,
      actualNextVersion: '16.4.2',
      harnessRevision: '6e2f65b51e7ead3c84274e717f8f3bcaeccf9b91',
      outcome: 'value',
      classification: 'success',
      value: {
        id: '0192e23b-6e9f-7b71-91ea-42b7e199db1c',
        email: `inta-a-${runId}@example.test`,
        name: 'INTA_A_INITIAL',
        version: 1,
        created_at: '2026-10-25T03:00:00.123456Z',
        updated_at: '2026-10-25T03:00:00.123456Z',
      },
      apiError: null,
      wire: null,
      truncated: false,
    }

    driver1.assertT1(validT1Envelope)
    expect(driver1.state.checkpointA?.version).toBe(1)

    // Checkpoint file should exist on disk
    const cpFile = path.join(testStateDir, 'checkpoints', `${runId}.json`)
    expect(fs.existsSync(cpFile)).toBe(true)

    // Second driver instance simulating reload / resume (with allowResume=true)
    const driver2 = new HarnessDriver(runId, testStateDir, true)
    expect(driver2.state.checkpointA).not.toBeNull()
    expect(driver2.state.checkpointA?.id).toBe('0192e23b-6e9f-7b71-91ea-42b7e199db1c')
    expect(driver2.state.checkpointA?.version).toBe(1)
  })

  it('asserts T9 mutation and updates checkpoint to version 2 (F01)', () => {
    const runId = 't9mutation12'
    const driver = new HarnessDriver(runId, testStateDir)
    driver.state.checkpointA = {
      id: '0192e23b-6e9f-7b71-91ea-42b7e199db1c',
      email: `inta-a-${runId}@example.test`,
      name: 'INTA_A_INITIAL',
      version: 1,
      created_at: '2026-10-25T03:00:00Z',
      updated_at: '2026-10-25T03:00:00Z',
    }

    const t9Envelope: HarnessEnvelope = {
      runId,
      caseId: 'T9',
      requestId: `mc-int-${runId}-T9-1`,
      mode: 'app-client',
      method: 'PATCH',
      routeTemplate: '/api/v1/users/{id}',
      startedAtUTC: '2026-10-25T03:05:00Z',
      latencyMs: 12,
      actualNextVersion: '16.4.2',
      harnessRevision: '6e2f65b51e7ead3c84274e717f8f3bcaeccf9b91',
      outcome: 'value',
      classification: 'success',
      value: {
        id: '0192e23b-6e9f-7b71-91ea-42b7e199db1c',
        email: `inta-a-${runId}@example.test`,
        name: 'INTA_A_UPDATED',
        version: 2,
        created_at: '2026-10-25T03:00:00Z',
        updated_at: '2026-10-25T03:05:00Z',
      },
      apiError: null,
      wire: null,
      truncated: false,
    }

    const updatedCp = driver.assertT9(t9Envelope)
    expect(updatedCp.version).toBe(2)
    expect(updatedCp.name).toBe('INTA_A_UPDATED')
    expect(driver.state.checkpointA?.version).toBe(2)
  })

  it('asserts T11a native 503 problem details and marks T11c OUTCOME_UNKNOWN (F01)', () => {
    const runId = 'outagetest12'
    const driver = new HarnessDriver(runId, testStateDir)

    const t11aEnvelope: HarnessEnvelope = {
      runId,
      caseId: 'T11a',
      requestId: `mc-int-${runId}-T11a-1`,
      mode: 'app-client',
      method: 'GET',
      routeTemplate: '/api/v1/users/{id}',
      startedAtUTC: '2026-10-25T03:10:00Z',
      latencyMs: 5,
      actualNextVersion: '16.4.2',
      harnessRevision: '6e2f65b51e7ead3c84274e717f8f3bcaeccf9b91',
      outcome: 'apiError',
      classification: 'unavailable',
      value: null,
      apiError: {
        status: 503,
        code: 'HTTP_ERROR',
        message: 'service temporarily unavailable',
        details: {
          type: '/problems/unavailable',
          title: 'Service Unavailable',
          status: 503,
          detail: 'service temporarily unavailable',
          retryAfter: 1,
        },
      },
      wire: null,
      truncated: false,
    }

    expect(() => driver.assertT11a(t11aEnvelope)).not.toThrow()
    expect(driver.state.assertions.get('T11a')?.pass).toBe(true)

    // T11c: POST X during PG outage
    const t11cEnvelope: HarnessEnvelope = {
      ...t11aEnvelope,
      caseId: 'T11c',
      requestId: `mc-int-${runId}-T11c-1`,
      method: 'POST',
      routeTemplate: '/api/v1/users',
    }
    driver.assertT11c(t11cEnvelope)
    expect(driver.state.userXOutcome).toBe('OUTCOME_UNKNOWN')
  })

  it('refuses collision when counters.json has runId entry (F02)', () => {
    const runId = 'collisionRun123'
    const countersPath = path.join(testStateDir, 'counters.json')
    fs.writeFileSync(countersPath, JSON.stringify({ [runId]: 10 }), 'utf-8')

    expect(() =>
      assertNoRunIdCollision(runId, testEvidenceDir, testStateDir),
    ).toThrow(/RunId collision refused: existing counter found/)
  })
})
