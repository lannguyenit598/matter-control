#!/usr/bin/env bash
# ==============================================================================
# MC-002-INTA-FE — Owned Process Graceful Stop Script (INTA-FE-R08, F07)
# Stop ONLY the exact recorded owned PID from .run-state/harness.pid.
# Validates strictly that PID is a positive integer and belongs to harness.
# NEVER kill by port, never use lsof/xargs kill, never killall.
# ==============================================================================
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
HARNESS_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"
PID_FILE="${HARNESS_ROOT}/.run-state/harness.pid"
PROVENANCE_FILE="${HARNESS_ROOT}/.run-state/harness.provenance"

echo "[$(date -u +"%Y-%m-%dT%H:%M:%SZ")] Stopping owned harness process..."

if [[ ! -f "${PID_FILE}" ]]; then
  echo "[$(date -u +"%Y-%m-%dT%H:%M:%SZ")] No PID file found at ${PID_FILE}. Harness process is not running or already stopped."
  exit 0
fi

TARGET_PID="$(cat "${PID_FILE}" | tr -d '[:space:]')"

if [[ -z "${TARGET_PID}" ]]; then
  echo "[$(date -u +"%Y-%m-%dT%H:%M:%SZ")] PID file was empty. Removing ${PID_FILE} with zero signals sent."
  rm -f "${PID_FILE}"
  exit 0
fi

# Strict numeric validation: must be positive integer (>= 1) (F07)
if [[ ! "${TARGET_PID}" =~ ^[1-9][0-9]*$ ]]; then
  echo "[$(date -u +"%Y-%m-%dT%H:%M:%SZ")] ERROR: Refusing invalid PID format '${TARGET_PID}' in ${PID_FILE} (must be a positive integer). Zero signals sent." >&2
  exit 1
fi

# Verify process is running
if ! kill -0 "${TARGET_PID}" 2>/dev/null; then
  echo "[$(date -u +"%Y-%m-%dT%H:%M:%SZ")] Process ${TARGET_PID} is not running. Stale PID file removed with zero signals sent."
  rm -f "${PID_FILE}" "${PROVENANCE_FILE}"
  exit 0
fi

# Verify process identity / ownership before sending any signal (F07)
PROC_CMD="$(ps -p "${TARGET_PID}" -o command= 2>/dev/null || true)"
if [[ ! "${PROC_CMD}" =~ (next|node|mc002-inta-harness) ]]; then
  echo "[$(date -u +"%Y-%m-%dT%H:%M:%SZ")] ERROR: Target PID ${TARGET_PID} command does not match harness ownership (${PROC_CMD}). Refusing to signal foreign process." >&2
  exit 1
fi

echo "[$(date -u +"%Y-%m-%dT%H:%M:%SZ")] Sending SIGTERM to verified owned PID ${TARGET_PID} (${PROC_CMD})..."
kill -TERM "${TARGET_PID}" || true

# Wait up to 5 seconds for graceful exit
WAITED=0
while kill -0 "${TARGET_PID}" 2>/dev/null && [ ${WAITED} -lt 50 ]; do
  sleep 0.1
  WAITED=$((WAITED + 1))
done

if kill -0 "${TARGET_PID}" 2>/dev/null; then
  echo "[$(date -u +"%Y-%m-%dT%H:%M:%SZ")] Process ${TARGET_PID} did not stop gracefully within 5s. Sending SIGKILL to owned PID..."
  kill -KILL "${TARGET_PID}" || true
  sleep 0.2
else
  echo "[$(date -u +"%Y-%m-%dT%H:%M:%SZ")] Process ${TARGET_PID} stopped gracefully."
fi

rm -f "${PID_FILE}" "${PROVENANCE_FILE}"
echo "[$(date -u +"%Y-%m-%dT%H:%M:%SZ")] Stopped owned PID ${TARGET_PID}. PID file removed."

# Verify port 18085 closed verification (F07)
if command -v nc >/dev/null 2>&1; then
  if nc -z 127.0.0.1 18085 2>/dev/null; then
    echo "[$(date -u +"%Y-%m-%dT%H:%M:%SZ")] WARNING: Port 18085 still in use after stopping PID ${TARGET_PID}." >&2
  else
    echo "[$(date -u +"%Y-%m-%dT%H:%M:%SZ")] Port 18085 verified closed."
  fi
fi

exit 0
