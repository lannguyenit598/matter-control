import fs from 'node:fs'
import path from 'node:path'
import url from 'node:url'
import { execSync } from 'node:child_process'
import {
  ALLOWED_CASE_IDS,
  type CaseId,
  REF_ID_REQUIRED_CASE_IDS,
  REF_ID_FORBIDDEN_CASE_IDS,
} from './schemas.ts'
import type { HarnessEnvelope } from './envelope.ts'
import { getFixturesForRun } from './fixtures.ts'

export interface CheckpointUserA {
  id: string
  email: string
  name: string
  version: number
  created_at: string
  updated_at: string
}

export interface DriverState {
  runId: string
  phase: string
  checkpointA: CheckpointUserA | null
  checkpointBId: string | null
  userXOutcome: 'OUTCOME_UNKNOWN' | null
  envelopes: Map<string, HarnessEnvelope[]>
  assertions: Map<string, { pass: boolean; notes: string; blocked?: boolean }>
}

export const CANONICAL_36_LOGICAL_IDS = [
  'INT-ENV-01',
  'INT-ENV-02',
  'INT-ENV-03',
  'INT-ENV-04',
  'INT-ENV-05',
  'INT-ENV-06',
  'INT-ENV-07',
  'T1',
  'T2',
  'W1',
  'W2',
  'T3',
  'T4',
  'T5',
  'T8',
  'W3',
  'T6-W',
  'T7-W',
  'INT-PERS-01',
  'INT-PERS-02',
  'T9',
  'W9',
  'T10',
  'T11a',
  'T11b',
  'T11c',
  'W11',
  'INT-PERS-03',
  'INT-PERS-04',
  'T12',
  'INT-COR-01',
  'INT-PRIV-01',
  'INT-ISO-01',
  'INT-ISO-02',
  'INT-ISO-03',
  'INT-CONF-01',
] as const

export type LogicalTestId = (typeof CANONICAL_36_LOGICAL_IDS)[number]

/**
 * Validates that an alphanumeric runId is 8-32 characters.
 */
export function validateRunId(runId: string): boolean {
  return /^[a-zA-Z0-9]{8,32}$/.test(runId)
}

/**
 * Generates an alphanumeric runId between 8 and 32 characters.
 */
export function generateRunId(prefix = 'inta'): string {
  const ts = Date.now().toString(36)
  const rand = Math.floor(Math.random() * 10000).toString(36)
  const runId = `${prefix}${ts}${rand}`.toLowerCase()
  if (runId.length < 8) {
    return runId.padEnd(8, '0')
  }
  if (runId.length > 32) {
    return runId.slice(0, 32)
  }
  return runId
}

/**
 * Refuses execution if runId collides with existing owned evidence, containers or state (F02).
 */
export function assertNoRunIdCollision(
  runId: string,
  evidenceBaseDir = '/tmp/mc002-inta-evidence',
  stateBaseDir = path.join(process.cwd(), '.run-state'),
  allowResume = false,
): void {
  if (!validateRunId(runId)) {
    throw new Error(`Invalid runId format (must be 8-32 alphanumeric): ${runId}`)
  }

  // 1. Check existing evidence directories
  const evidenceCheckDirs = [
    path.join(evidenceBaseDir, 'frontend', runId),
    path.join(evidenceBaseDir, 'backend', runId),
    path.join(evidenceBaseDir, 'environment', runId),
    path.join(evidenceBaseDir, 'qa', runId),
  ]
  for (const dir of evidenceCheckDirs) {
    if (fs.existsSync(dir)) {
      throw new Error(`RunId collision refused: existing evidence found at ${dir}`)
    }
  }

  // 2. Check local run state
  if (!allowResume) {
    // Check real counters.json file (F02)
    const countersPath = path.join(stateBaseDir, 'counters.json')
    if (fs.existsSync(countersPath)) {
      try {
        const data = JSON.parse(fs.readFileSync(countersPath, 'utf-8'))
        if (data[runId] !== undefined) {
          throw new Error(`RunId collision refused: existing counter found for ${runId} in ${countersPath}`)
        }
      } catch (err: any) {
        if (err.message?.includes('RunId collision refused')) throw err
      }
    }

    // Check checkpoints
    const checkpointPath = path.join(stateBaseDir, 'checkpoints', `${runId}.json`)
    if (fs.existsSync(checkpointPath)) {
      throw new Error(`RunId collision refused: existing checkpoint found at ${checkpointPath}`)
    }

    // Check envelopes
    const envelopePath = path.join(stateBaseDir, 'envelopes', runId)
    if (fs.existsSync(envelopePath)) {
      throw new Error(`RunId collision refused: existing run state found at ${envelopePath}`)
    }
  }

  // 3. Check for existing docker container mc002-inta-pg-<runId> if docker is available
  try {
    const containerName = `mc002-inta-pg-${runId}`
    const out = execSync(`docker ps -a --filter name=${containerName} --format "{{.Names}}"`, {
      encoding: 'utf-8',
      stdio: ['ignore', 'pipe', 'ignore'],
    }).trim()
    if (out.includes(containerName)) {
      throw new Error(`RunId collision refused: existing Docker container found: ${containerName}`)
    }
  } catch (err: any) {
    if (err.message?.includes('RunId collision refused')) {
      throw err
    }
  }
}

/**
 * RFC 3339 UTC timestamp check with 0-6 fraction digits.
 */
export const RFC3339_UTC_REGEX =
  /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d{1,6})?Z$/

/**
 * Canonical lowercase UUIDv7 check with version digit 7 and RFC 4122 variant (F01).
 */
export const UUIDV7_LOWERCASE_REGEX =
  /^[0-9a-f]{8}-[0-9a-f]{4}-7[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/

export class HarnessDriver {
  public readonly runId: string
  public readonly stateDir: string
  public readonly envelopeDir: string
  public readonly checkpointDir: string
  public state: DriverState

  constructor(runId?: string, stateDir?: string, allowResume = false) {
    this.runId = runId ?? generateRunId()
    this.stateDir = stateDir ?? process.env.MC_INTA_STATE_DIR ?? path.join(process.cwd(), '.run-state')
    this.envelopeDir = path.join(this.stateDir, 'envelopes', this.runId)
    this.checkpointDir = path.join(this.stateDir, 'checkpoints')

    assertNoRunIdCollision(this.runId, undefined, this.stateDir, allowResume)

    fs.mkdirSync(this.envelopeDir, { recursive: true })
    fs.mkdirSync(this.checkpointDir, { recursive: true })

    this.state = {
      runId: this.runId,
      phase: 'INITIALIZED',
      checkpointA: null,
      checkpointBId: null,
      userXOutcome: null,
      envelopes: new Map(),
      assertions: new Map(),
    }

    if (allowResume) {
      this.loadCheckpoint()
    }
  }

  /**
   * Loads durable checkpoint from disk if present (F01).
   */
  public loadCheckpoint(): boolean {
    const cpPath = path.join(this.checkpointDir, `${this.runId}.json`)
    if (!fs.existsSync(cpPath)) return false
    try {
      const data = JSON.parse(fs.readFileSync(cpPath, 'utf-8'))
      this.state.phase = data.phase ?? this.state.phase
      this.state.checkpointA = data.checkpointA ?? null
      this.state.checkpointBId = data.checkpointBId ?? null
      this.state.userXOutcome = data.userXOutcome ?? null
      return true
    } catch (err: any) {
      throw new Error(`Failed to load checkpoint from ${cpPath}: ${err.message}`)
    }
  }

  /**
   * Persists durable write-once checkpoint to disk atomically (F01).
   */
  public saveCheckpoint(): void {
    const checkpointData = {
      runId: this.runId,
      phase: this.state.phase,
      checkpointA: this.state.checkpointA,
      checkpointBId: this.state.checkpointBId,
      userXOutcome: this.state.userXOutcome,
      updatedAtUTC: new Date().toISOString(),
    }
    const cpPath = path.join(this.checkpointDir, `${this.runId}.json`)
    const tmpPath = path.join(
      this.checkpointDir,
      `.${this.runId}.${process.pid}.${Date.now()}.${Math.random().toString(36).slice(2)}.tmp`,
    )
    fs.writeFileSync(tmpPath, JSON.stringify(checkpointData, null, 2), 'utf-8')
    fs.renameSync(tmpPath, cpPath)
  }

  /**
   * Persists an envelope to disk with write-once ledger enforcement (F01).
   * Refuses duplicate execution unless byte-identical.
   */
  public persistEnvelope(caseId: string, envelopes: HarnessEnvelope[]): void {
    this.state.envelopes.set(caseId, envelopes)
    const outPath = path.join(this.envelopeDir, `${caseId}.json`)
    const serialized = JSON.stringify(envelopes, null, 2)

    if (fs.existsSync(outPath)) {
      const existing = fs.readFileSync(outPath, 'utf-8')
      if (existing === serialized) {
        return // Idempotent byte-equal write
      }
      throw new Error(
        `Duplicate case execution refused by write-once ledger: ${caseId} already executed with different content for runId ${this.runId}`,
      )
    }

    const tmpPath = path.join(
      this.envelopeDir,
      `.${caseId}.${process.pid}.${Date.now()}.${Math.random().toString(36).slice(2)}.tmp`,
    )
    fs.writeFileSync(tmpPath, serialized, 'utf-8')
    fs.renameSync(tmpPath, outPath)
  }

  /**
   * Records an assertion result. If truncated evidence is detected, blocks body/equality assertions.
   */
  public recordAssertion(
    caseId: string,
    pass: boolean,
    notes: string,
    truncated = false,
  ): void {
    if (truncated) {
      this.state.assertions.set(caseId, {
        pass: false,
        blocked: true,
        notes: `BLOCKED: Body truncated (>16KiB cap) — cannot establish assertion (${notes})`,
      })
      return
    }
    this.state.assertions.set(caseId, { pass, notes })
  }

  /**
   * Asserts User A created state in T1 and saves immutable checkpoint (F01).
   */
  public assertT1(envelope: HarnessEnvelope): CheckpointUserA {
    if (envelope.truncated) {
      this.recordAssertion('T1', false, 'Envelope body truncated', true)
      throw new Error('T1 assertion blocked: envelope body was truncated')
    }

    if (envelope.outcome !== 'value' || !envelope.value) {
      this.recordAssertion('T1', false, `Expected outcome value, got ${envelope.outcome}`)
      throw new Error(`T1 failed: unexpected outcome ${envelope.outcome}`)
    }

    const val = envelope.value as any
    if (!UUIDV7_LOWERCASE_REGEX.test(val.id)) {
      this.recordAssertion('T1', false, `Invalid User A id format (must be lowercase UUIDv7): ${val.id}`)
      throw new Error(`T1 failed: invalid User A id format: ${val.id}`)
    }

    const f = getFixturesForRun(this.runId)
    if (val.email !== f.userA.initial.email) {
      this.recordAssertion('T1', false, `Expected email ${f.userA.initial.email}, got ${val.email}`)
      throw new Error(`T1 failed: email mismatch vs fixture A: ${val.email}`)
    }

    if (val.name !== f.userA.initial.name) {
      this.recordAssertion('T1', false, `Expected name ${f.userA.initial.name}, got ${val.name}`)
      throw new Error(`T1 failed: name mismatch vs fixture A: ${val.name}`)
    }

    if (val.version !== 1) {
      this.recordAssertion('T1', false, `Expected version 1, got ${val.version}`)
      throw new Error(`T1 failed: expected version 1, got ${val.version}`)
    }

    if (!RFC3339_UTC_REGEX.test(val.created_at)) {
      this.recordAssertion('T1', false, `Invalid created_at RFC 3339: ${val.created_at}`)
      throw new Error(`T1 failed: invalid created_at RFC 3339 UTC: ${val.created_at}`)
    }

    if (!RFC3339_UTC_REGEX.test(val.updated_at)) {
      this.recordAssertion('T1', false, `Invalid updated_at RFC 3339: ${val.updated_at}`)
      throw new Error(`T1 failed: invalid updated_at RFC 3339 UTC: ${val.updated_at}`)
    }

    this.state.checkpointA = {
      id: val.id,
      email: val.email,
      name: val.name,
      version: val.version,
      created_at: val.created_at,
      updated_at: val.updated_at,
    }

    this.saveCheckpoint()
    this.recordAssertion('T1', true, 'User A created with version 1, valid UUIDv7 and RFC 3339 UTC timestamps')
    return this.state.checkpointA
  }

  /**
   * Asserts T2 readback matches T1 checkpoint field-for-field.
   */
  public assertT2(envelope: HarnessEnvelope): void {
    if (!this.state.checkpointA) {
      throw new Error('T2 assertion error: Checkpoint A missing')
    }
    if (envelope.truncated) {
      this.recordAssertion('T2', false, 'Envelope body truncated', true)
      throw new Error('T2 assertion blocked: envelope body was truncated')
    }

    const val = envelope.value as any
    const cp = this.state.checkpointA

    const match =
      val.id === cp.id &&
      val.email === cp.email &&
      val.name === cp.name &&
      val.version === cp.version &&
      val.created_at === cp.created_at &&
      val.updated_at === cp.updated_at

    if (!match) {
      this.recordAssertion('T2', false, 'T2 readback does not match T1 checkpoint field-for-field')
      throw new Error('T2 failed: readback mismatch vs checkpoint A')
    }

    this.recordAssertion('T2', true, 'T2 readback matches T1 checkpoint field-for-field')
  }

  /**
   * Asserts W1 User B wire creation headers and status (F01).
   */
  public assertW1(envelope: HarnessEnvelope): string {
    if (envelope.truncated) {
      this.recordAssertion('W1', false, 'Envelope body truncated', true)
      throw new Error('W1 assertion blocked: envelope body was truncated')
    }
    if (envelope.wire?.status !== 201) {
      this.recordAssertion('W1', false, `Expected wire status 201, got ${envelope.wire?.status}`)
      throw new Error(`W1 failed: expected wire status 201, got ${envelope.wire?.status}`)
    }

    const val = envelope.value as any
    if (!val?.id || !UUIDV7_LOWERCASE_REGEX.test(val.id)) {
      this.recordAssertion('W1', false, `Invalid User B id format: ${val?.id}`)
      throw new Error(`W1 failed: invalid User B id format: ${val?.id}`)
    }

    const loc = envelope.wire?.headers?.location
    const expectedLoc = `/api/v1/users/${val.id}`
    if (loc !== expectedLoc) {
      this.recordAssertion('W1', false, `Expected Location header ${expectedLoc}, got ${loc}`)
      throw new Error(`W1 failed: Location header mismatch: expected ${expectedLoc}, got ${loc}`)
    }

    const etag = envelope.wire?.headers?.etag
    if (etag !== '"1"') {
      this.recordAssertion('W1', false, `Expected ETag "1", got ${etag}`)
      throw new Error(`W1 failed: ETag mismatch: expected "1", got ${etag}`)
    }

    const contentType = envelope.wire?.headers?.['content-type']
    if (!contentType?.includes('application/json')) {
      this.recordAssertion('W1', false, `Expected content-type application/json, got ${contentType}`)
      throw new Error(`W1 failed: content-type mismatch: got ${contentType}`)
    }

    this.state.checkpointBId = val.id
    this.saveCheckpoint()
    this.recordAssertion('W1', true, 'User B created with 201, valid Location, ETag "1", and JSON content-type')
    return val.id
  }

  /**
   * Asserts W2 wire read User A before T9 (F01).
   */
  public assertW2(envelope: HarnessEnvelope): void {
    if (envelope.wire?.status !== 200) {
      this.recordAssertion('W2', false, `Expected wire status 200, got ${envelope.wire?.status}`)
      throw new Error(`W2 failed: expected wire status 200, got ${envelope.wire?.status}`)
    }
    const etag = envelope.wire?.headers?.etag
    if (etag !== '"1"') {
      this.recordAssertion('W2', false, `Expected ETag "1", got ${etag}`)
      throw new Error(`W2 failed: ETag mismatch: expected "1", got ${etag}`)
    }
    this.recordAssertion('W2', true, 'W2 read User A with 200 and ETag "1"')
  }

  /**
   * Asserts T3 missing UUID -> 404 / NOT_FOUND (F01).
   */
  public assertT3(envelope: HarnessEnvelope): void {
    if (envelope.outcome !== 'apiError' || envelope.apiError?.status !== 404 || envelope.apiError?.code !== 'NOT_FOUND') {
      this.recordAssertion('T3', false, `Expected 404/NOT_FOUND, got ${envelope.outcome}/${envelope.apiError?.code}`)
      throw new Error(`T3 failed: expected 404/NOT_FOUND, got ${envelope.outcome}`)
    }
    this.recordAssertion('T3', true, 'T3 missing UUID returned 404 NOT_FOUND')
  }

  /**
   * Asserts T4 malformed and uppercase UUIDs -> two distinct 404 observations (F01).
   */
  public assertT4(envelopes: HarnessEnvelope[]): void {
    if (envelopes.length !== 2) {
      this.recordAssertion('T4', false, `Expected 2 substeps, got ${envelopes.length}`)
      throw new Error(`T4 failed: expected 2 substeps, got ${envelopes.length}`)
    }
    if (envelopes[0].requestId === envelopes[1].requestId) {
      this.recordAssertion('T4', false, 'Expected unique request IDs for T4 substeps')
      throw new Error('T4 failed: substep request IDs collided')
    }
    for (let i = 0; i < 2; i++) {
      const step = envelopes[i]
      if (step.outcome !== 'apiError' || step.apiError?.status !== 404 || step.apiError?.code !== 'NOT_FOUND') {
        this.recordAssertion('T4', false, `Substep ${i} expected 404/NOT_FOUND, got ${step.outcome}`)
        throw new Error(`T4 failed on substep ${i}: expected 404/NOT_FOUND`)
      }
    }
    this.recordAssertion('T4', true, 'T4 executed two distinct 404 NOT_FOUND substeps with unique request IDs')
  }

  /**
   * Asserts T5 invalid name -> 422 and User A readback unchanged (F01).
   */
  public assertT5(envelopes: HarnessEnvelope[]): void {
    if (envelopes.length !== 2) {
      throw new Error(`T5 expected 2 substeps, got ${envelopes.length}`)
    }
    const [substep0, substep1] = envelopes
    if (substep0.outcome !== 'apiError' || substep0.apiError?.status !== 422 || substep0.apiError?.code !== 'VALIDATION_ERROR') {
      this.recordAssertion('T5', false, `Substep 0 expected 422/VALIDATION_ERROR, got ${substep0.outcome}`)
      throw new Error(`T5 failed on substep 0: expected 422/VALIDATION_ERROR`)
    }
    this.assertT2(substep1)
    this.recordAssertion('T5', true, 'T5 rejected empty name with 422 and verified User A unchanged')
  }

  /**
   * Asserts T8 duplicate email -> 409 and User A readback unchanged (F01).
   */
  public assertT8(envelopes: HarnessEnvelope[]): void {
    if (envelopes.length !== 2) {
      throw new Error(`T8 expected 2 substeps, got ${envelopes.length}`)
    }
    const [substep0, substep1] = envelopes
    if (substep0.outcome !== 'apiError' || substep0.apiError?.status !== 409 || substep0.apiError?.code !== 'HTTP_ERROR') {
      this.recordAssertion('T8', false, `Substep 0 expected 409/HTTP_ERROR, got ${substep0.outcome}`)
      throw new Error(`T8 failed on substep 0: expected 409/HTTP_ERROR`)
    }
    this.assertT2(substep1)
    this.recordAssertion('T8', true, 'T8 rejected duplicate email with 409 and verified User A unchanged')
  }

  /**
   * Asserts W3 wire GET missing UUID -> 404 / application/problem+json (F01).
   */
  public assertW3(envelope: HarnessEnvelope): void {
    if (envelope.wire?.status !== 404) {
      this.recordAssertion('W3', false, `Expected wire status 404, got ${envelope.wire?.status}`)
      throw new Error(`W3 failed: expected wire status 404`)
    }
    const ct = envelope.wire?.headers?.['content-type']
    if (!ct?.includes('application/problem+json')) {
      this.recordAssertion('W3', false, `Expected application/problem+json, got ${ct}`)
      throw new Error(`W3 failed: content-type mismatch: got ${ct}`)
    }
    this.recordAssertion('W3', true, 'W3 returned 404 with application/problem+json')
  }

  /**
   * Asserts T6-W wire POST malformed JSON -> 400 / application/problem+json (F01).
   */
  public assertT6W(envelope: HarnessEnvelope): void {
    if (envelope.wire?.status !== 400) {
      this.recordAssertion('T6-W', false, `Expected wire status 400, got ${envelope.wire?.status}`)
      throw new Error(`T6-W failed: expected wire status 400`)
    }
    const ct = envelope.wire?.headers?.['content-type']
    if (!ct?.includes('application/problem+json')) {
      this.recordAssertion('T6-W', false, `Expected application/problem+json, got ${ct}`)
      throw new Error(`T6-W failed: content-type mismatch: got ${ct}`)
    }
    this.recordAssertion('T6-W', true, 'T6-W returned 400 with application/problem+json')
  }

  /**
   * Asserts T7-W wire POST missing content-type -> 415 / application/problem+json (F01).
   */
  public assertT7W(envelope: HarnessEnvelope): void {
    if (envelope.wire?.status !== 415) {
      this.recordAssertion('T7-W', false, `Expected wire status 415, got ${envelope.wire?.status}`)
      throw new Error(`T7-W failed: expected wire status 415`)
    }
    const ct = envelope.wire?.headers?.['content-type']
    if (!ct?.includes('application/problem+json')) {
      this.recordAssertion('T7-W', false, `Expected application/problem+json, got ${ct}`)
      throw new Error(`T7-W failed: content-type mismatch: got ${ct}`)
    }
    this.recordAssertion('T7-W', true, 'T7-W returned 415 with application/problem+json')
  }

  /**
   * Asserts INT-PERS-01 readback after Go restart (F01).
   */
  public assertPers01(envelope: HarnessEnvelope): void {
    this.assertT2(envelope)
    this.recordAssertion('INT-PERS-01', true, 'INT-PERS-01 verified User A unchanged across Go restart')
  }

  /**
   * Asserts INT-PERS-02 readback after PG restart (F01).
   */
  public assertPers02(envelope: HarnessEnvelope): void {
    this.assertT2(envelope)
    this.recordAssertion('INT-PERS-02', true, 'INT-PERS-02 verified User A unchanged across PostgreSQL restart')
  }

  /**
   * Asserts T9 PATCH User A -> version 2 and updated name (F01).
   */
  public assertT9(envelope: HarnessEnvelope): CheckpointUserA {
    if (!this.state.checkpointA) {
      throw new Error('T9 assertion error: Checkpoint A missing')
    }
    if (envelope.truncated) {
      this.recordAssertion('T9', false, 'Envelope body truncated', true)
      throw new Error('T9 assertion blocked: envelope body was truncated')
    }
    if (envelope.outcome !== 'value' || !envelope.value) {
      this.recordAssertion('T9', false, `Expected outcome value, got ${envelope.outcome}`)
      throw new Error(`T9 failed: unexpected outcome ${envelope.outcome}`)
    }

    const val = envelope.value as any
    const cp = this.state.checkpointA

    if (val.id !== cp.id) {
      this.recordAssertion('T9', false, `Expected id ${cp.id}, got ${val.id}`)
      throw new Error(`T9 failed: id mismatch`)
    }
    if (val.version !== 2) {
      this.recordAssertion('T9', false, `Expected version 2, got ${val.version}`)
      throw new Error(`T9 failed: expected version 2, got ${val.version}`)
    }
    if (val.name !== 'INTA_A_UPDATED') {
      this.recordAssertion('T9', false, `Expected name INTA_A_UPDATED, got ${val.name}`)
      throw new Error(`T9 failed: expected name INTA_A_UPDATED, got ${val.name}`)
    }

    this.state.checkpointA = {
      ...cp,
      version: 2,
      name: 'INTA_A_UPDATED',
      updated_at: val.updated_at,
    }
    this.saveCheckpoint()
    this.recordAssertion('T9', true, 'T9 updated User A to version 2 with name INTA_A_UPDATED')
    return this.state.checkpointA
  }

  /**
   * Asserts W9 wire GET User A after T9 -> ETag "2" (F01).
   */
  public assertW9(envelope: HarnessEnvelope): void {
    if (envelope.wire?.status !== 200) {
      this.recordAssertion('W9', false, `Expected wire status 200, got ${envelope.wire?.status}`)
      throw new Error(`W9 failed: expected wire status 200`)
    }
    const etag = envelope.wire?.headers?.etag
    if (etag !== '"2"') {
      this.recordAssertion('W9', false, `Expected ETag "2", got ${etag}`)
      throw new Error(`W9 failed: expected ETag "2", got ${etag}`)
    }
    this.recordAssertion('W9', true, 'W9 read User A with 200 and ETag "2"')
  }

  /**
   * Asserts T10 stale update -> 412 and User A version 2 preserved (F01).
   */
  public assertT10(envelopes: HarnessEnvelope[]): void {
    if (envelopes.length !== 2) {
      throw new Error(`T10 expected 2 substeps, got ${envelopes.length}`)
    }
    const [substep0, substep1] = envelopes
    if (substep0.outcome !== 'apiError' || substep0.apiError?.status !== 412 || substep0.apiError?.code !== 'HTTP_ERROR') {
      this.recordAssertion('T10', false, `Substep 0 expected 412/HTTP_ERROR, got ${substep0.outcome}`)
      throw new Error(`T10 failed on substep 0: expected 412/HTTP_ERROR`)
    }
    this.assertT2(substep1)
    this.recordAssertion('T10', true, 'T10 rejected stale update with 412 and verified User A version 2 preserved')
  }

  /**
   * Asserts T11a GET A during PG outage -> 503 unavailable with native literals (F01).
   */
  public assertT11a(envelope: HarnessEnvelope): void {
    if (envelope.outcome !== 'apiError' || envelope.apiError?.status !== 503) {
      this.recordAssertion('T11a', false, `Expected 503, got ${envelope.outcome}`)
      throw new Error(`T11a failed: expected 503, got ${envelope.outcome}`)
    }
    if (envelope.classification !== 'unavailable') {
      this.recordAssertion('T11a', false, `Expected classification unavailable, got ${envelope.classification}`)
      throw new Error(`T11a failed: expected classification unavailable`)
    }
    const details = envelope.apiError?.details as any
    if (details?.type !== '/problems/unavailable' || details?.retryAfter !== 1 || !details?.detail?.includes('service temporarily unavailable')) {
      this.recordAssertion('T11a', false, `Native 503 problem detail mismatch: ${JSON.stringify(details)}`)
      throw new Error(`T11a failed: native problem detail mismatch`)
    }
    this.recordAssertion('T11a', true, 'T11a returned 503 unavailable with native problem literals (/problems/unavailable, retryAfter: 1)')
  }

  /**
   * Asserts T11b PATCH A during PG outage -> 503 unavailable (F01).
   */
  public assertT11b(envelope: HarnessEnvelope): void {
    if (envelope.outcome !== 'apiError' || envelope.apiError?.status !== 503) {
      this.recordAssertion('T11b', false, `Expected 503, got ${envelope.outcome}`)
      throw new Error(`T11b failed: expected 503`)
    }
    if (envelope.classification !== 'unavailable') {
      this.recordAssertion('T11b', false, `Expected classification unavailable, got ${envelope.classification}`)
      throw new Error(`T11b failed: expected classification unavailable`)
    }
    this.recordAssertion('T11b', true, 'T11b returned 503 unavailable')
  }

  /**
   * Asserts T11c POST X during PG outage -> 503 unavailable, userXOutcome = OUTCOME_UNKNOWN (F01).
   */
  public assertT11c(envelope: HarnessEnvelope): void {
    if (envelope.outcome !== 'apiError' || envelope.apiError?.status !== 503) {
      this.recordAssertion('T11c', false, `Expected 503, got ${envelope.outcome}`)
      throw new Error(`T11c failed: expected 503`)
    }
    if (envelope.classification !== 'unavailable') {
      this.recordAssertion('T11c', false, `Expected classification unavailable, got ${envelope.classification}`)
      throw new Error(`T11c failed: expected classification unavailable`)
    }
    this.state.userXOutcome = 'OUTCOME_UNKNOWN'
    this.saveCheckpoint()
    this.recordAssertion('T11c', true, 'T11c returned 503 unavailable; User X outcome marked OUTCOME_UNKNOWN (no replay/probe)')
  }

  /**
   * Asserts W11 wire GET A during PG outage -> 503 / application/problem+json (F01).
   */
  public assertW11(envelope: HarnessEnvelope): void {
    if (envelope.wire?.status !== 503) {
      this.recordAssertion('W11', false, `Expected wire status 503, got ${envelope.wire?.status}`)
      throw new Error(`W11 failed: expected wire status 503`)
    }
    const ct = envelope.wire?.headers?.['content-type']
    if (!ct?.includes('application/problem+json')) {
      this.recordAssertion('W11', false, `Expected application/problem+json, got ${ct}`)
      throw new Error(`W11 failed: content-type mismatch: got ${ct}`)
    }
    this.recordAssertion('W11', true, 'W11 returned 503 with application/problem+json')
  }

  /**
   * Asserts INT-PERS-03 recovery readback (F01).
   */
  public assertPers03(envelope: HarnessEnvelope): void {
    this.assertT2(envelope)
    this.recordAssertion('INT-PERS-03', true, 'INT-PERS-03 verified User A recovery state after PG restart')
  }

  /**
   * Asserts INT-PERS-04 recovery readback (F01).
   */
  public assertPers04(envelope: HarnessEnvelope): void {
    this.assertT2(envelope)
    this.recordAssertion('INT-PERS-04', true, 'INT-PERS-04 verified User A read-only recovery')
  }

  /**
   * Asserts T12 GET A after Go stopped -> status 0, NETWORK_ERROR, unavailable (F01).
   */
  public assertT12(envelope: HarnessEnvelope): void {
    if (envelope.outcome !== 'apiError' || envelope.apiError?.status !== 0 || envelope.apiError?.code !== 'NETWORK_ERROR') {
      this.recordAssertion('T12', false, `Expected status 0/NETWORK_ERROR, got ${envelope.outcome}/${envelope.apiError?.code}`)
      throw new Error(`T12 failed: expected status 0/NETWORK_ERROR`)
    }
    if (envelope.classification !== 'unavailable') {
      this.recordAssertion('T12', false, `Expected classification unavailable, got ${envelope.classification}`)
      throw new Error(`T12 failed: expected classification unavailable`)
    }
    this.recordAssertion('T12', true, 'T12 verified NETWORK_ERROR and unavailable classification after Go shutdown')
  }

  /**
   * Pauses safely before any upstream action until Codex ENV handoff and owner readiness.
   */
  public pauseForUpstreamCoordination(envReady: boolean): void {
    if (!envReady) {
      this.state.phase = 'PAUSED_WAITING_ENV'
      return
    }
    this.state.phase = 'ENV_COORDINATED_READY'
  }

  /**
   * Checks driver-only upstream readiness gate (F01).
   * Refuses upstream phase execution if environment is not verified ready.
   */
  public checkEnvReadiness(envReadyOption?: boolean): boolean {
    const isReady = Boolean(envReadyOption || process.env.MC_INTA_ENV_READY === '1')
    if (!isReady) {
      this.state.phase = 'PAUSED_WAITING_ENV'
      return false
    }
    return true
  }

  /**
   * Dispatches a single case to the local Next.js dev server endpoint (F01).
   */
  public async dispatchCaseToHarness(
    caseId: CaseId,
    refId?: string,
    harnessBaseUrl = 'http://127.0.0.1:18085',
  ): Promise<HarnessEnvelope[]> {
    const payload: { runId: string; caseId: CaseId; refId?: string } = {
      runId: this.runId,
      caseId,
    }
    if (refId) {
      payload.refId = refId
    }

    const response = await fetch(`${harnessBaseUrl}/harness/case`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(payload),
      cache: 'no-store',
    })

    if (!response.ok) {
      const errText = await response.text()
      throw new Error(
        `Harness dispatch failed for ${caseId}: HTTP ${response.status} ${response.statusText} — ${errText}`,
      )
    }

    const json = (await response.json()) as any
    if (!json?.substeps || !Array.isArray(json.substeps)) {
      throw new Error(`Malformed harness response for ${caseId}: missing substeps array`)
    }

    return json.substeps as HarnessEnvelope[]
  }

  /**
   * Executes a specific phase runner command (F01).
   * Gated in driver only; pauses safely if environment not ready.
   */
  public async runPhase(
    phaseNum: number,
    options?: { envReady?: boolean; harnessBaseUrl?: string },
  ): Promise<{ ok: boolean; reason?: string; executedCases: string[] }> {
    if (!this.checkEnvReadiness(options?.envReady)) {
      console.log(`[DRIVER_PAUSED] Phase ${phaseNum} paused: upstream environment not verified ready.`)
      console.log('Set MC_INTA_ENV_READY=1 or pass --env-ready after Codex/ZCode verified handoff.')
      return { ok: false, reason: 'PAUSED_WAITING_ENV', executedCases: [] }
    }

    const harnessBaseUrl = options?.harnessBaseUrl ?? 'http://127.0.0.1:18085'
    const executedCases: string[] = []

    switch (phaseNum) {
      case 1: {
        // Phase 1: Baseline and Initial Negatives (T1, T2, W1, W2, T3, T4, T5, T8, W3, T6-W, T7-W)
        console.log(`[DRIVER] Executing Phase 1 (Baseline & Initial Negatives) for runId ${this.runId}...`)
        
        // T1: POST User A
        const t1Steps = await this.dispatchCaseToHarness('T1', undefined, harnessBaseUrl)
        this.persistEnvelope('T1', t1Steps)
        const cpA = this.assertT1(t1Steps[0])
        executedCases.push('T1')

        // T2: GET User A
        const t2Steps = await this.dispatchCaseToHarness('T2', cpA.id, harnessBaseUrl)
        this.persistEnvelope('T2', t2Steps)
        this.assertT2(t2Steps[0])
        executedCases.push('T2')

        // W1: POST User B (wire)
        const w1Steps = await this.dispatchCaseToHarness('W1', undefined, harnessBaseUrl)
        this.persistEnvelope('W1', w1Steps)
        this.assertW1(w1Steps[0])
        executedCases.push('W1')

        // W2: GET User A (wire)
        const w2Steps = await this.dispatchCaseToHarness('W2', cpA.id, harnessBaseUrl)
        this.persistEnvelope('W2', w2Steps)
        this.assertW2(w2Steps[0])
        executedCases.push('W2')

        // T3: GET missing UUID
        const t3Steps = await this.dispatchCaseToHarness('T3', undefined, harnessBaseUrl)
        this.persistEnvelope('T3', t3Steps)
        this.assertT3(t3Steps[0])
        executedCases.push('T3')

        // T4: Malformed and uppercase UUIDs
        const t4Steps = await this.dispatchCaseToHarness('T4', undefined, harnessBaseUrl)
        this.persistEnvelope('T4', t4Steps)
        this.assertT4(t4Steps)
        executedCases.push('T4')

        // T5: Invalid name (422) + User A readback
        const t5Steps = await this.dispatchCaseToHarness('T5', cpA.id, harnessBaseUrl)
        this.persistEnvelope('T5', t5Steps)
        this.assertT5(t5Steps)
        executedCases.push('T5')

        // T8: Duplicate email (409) + User A readback
        const t8Steps = await this.dispatchCaseToHarness('T8', cpA.id, harnessBaseUrl)
        this.persistEnvelope('T8', t8Steps)
        this.assertT8(t8Steps)
        executedCases.push('T8')

        // W3: GET missing UUID (wire 404)
        const w3Steps = await this.dispatchCaseToHarness('W3', undefined, harnessBaseUrl)
        this.persistEnvelope('W3', w3Steps)
        this.assertW3(w3Steps[0])
        executedCases.push('W3')

        // T6-W: Malformed JSON (wire 400)
        const t6wSteps = await this.dispatchCaseToHarness('T6-W', undefined, harnessBaseUrl)
        this.persistEnvelope('T6-W', t6wSteps)
        this.assertT6W(t6wSteps[0])
        executedCases.push('T6-W')

        // T7-W: Missing content-type (wire 415)
        const t7wSteps = await this.dispatchCaseToHarness('T7-W', undefined, harnessBaseUrl)
        this.persistEnvelope('T7-W', t7wSteps)
        this.assertT7W(t7wSteps[0])
        executedCases.push('T7-W')

        this.state.phase = 'PHASE_1_COMPLETED'
        this.saveCheckpoint()

        console.log('\n[LIFECYCLE_COORDINATION] Phase 1 completed successfully.')
        console.log('Checkpoint User A persisted to .run-state/checkpoints/' + this.runId + '.json')
        console.log('>>> External owner action required: ZCode restart Go binary (INT-PERS-01). <<<')
        console.log('>>> Then Codex stop and restart PostgreSQL container (INT-PERS-02). <<<')
        console.log('Run phase 2 once restarts are completed.')
        return { ok: true, executedCases }
      }

      case 2: {
        // Phase 2: Restarts and Persistence Verification (INT-PERS-01, INT-PERS-02)
        console.log(`[DRIVER] Executing Phase 2 (Persistence Verification) for runId ${this.runId}...`)
        if (!this.state.checkpointA) {
          throw new Error('Phase 2 error: Checkpoint A missing. Run phase 1 first.')
        }

        // INT-PERS-01: GET User A after Go restart
        const pers01Steps = await this.dispatchCaseToHarness('INT-PERS-01', this.state.checkpointA.id, harnessBaseUrl)
        this.persistEnvelope('INT-PERS-01', pers01Steps)
        this.assertPers01(pers01Steps[0])
        executedCases.push('INT-PERS-01')

        // INT-PERS-02: GET User A after PG restart
        const pers02Steps = await this.dispatchCaseToHarness('INT-PERS-02', this.state.checkpointA.id, harnessBaseUrl)
        this.persistEnvelope('INT-PERS-02', pers02Steps)
        this.assertPers02(pers02Steps[0])
        executedCases.push('INT-PERS-02')

        this.state.phase = 'PHASE_2_COMPLETED'
        this.saveCheckpoint()

        console.log('\n[LIFECYCLE_COORDINATION] Phase 2 completed successfully.')
        console.log('User A verified unchanged across Go and PostgreSQL restarts.')
        console.log('Next: Run phase 3 for mutations and stale update.')
        return { ok: true, executedCases }
      }

      case 3: {
        // Phase 3: Mutations & Stale Update (T9, W9, T10)
        console.log(`[DRIVER] Executing Phase 3 (Mutations & Stale Update) for runId ${this.runId}...`)
        if (!this.state.checkpointA) {
          throw new Error('Phase 3 error: Checkpoint A missing. Run phase 1 first.')
        }

        // T9: PATCH User A with If-Match "1"
        const t9Steps = await this.dispatchCaseToHarness('T9', this.state.checkpointA.id, harnessBaseUrl)
        this.persistEnvelope('T9', t9Steps)
        this.assertT9(t9Steps[0])
        executedCases.push('T9')

        // W9: Wire GET User A -> ETag "2"
        const w9Steps = await this.dispatchCaseToHarness('W9', this.state.checkpointA.id, harnessBaseUrl)
        this.persistEnvelope('W9', w9Steps)
        this.assertW9(w9Steps[0])
        executedCases.push('W9')

        // T10: PATCH User A with stale If-Match "1" (412) + readback
        const t10Steps = await this.dispatchCaseToHarness('T10', this.state.checkpointA.id, harnessBaseUrl)
        this.persistEnvelope('T10', t10Steps)
        this.assertT10(t10Steps)
        executedCases.push('T10')

        this.state.phase = 'PHASE_3_COMPLETED'
        this.saveCheckpoint()

        console.log('\n[LIFECYCLE_COORDINATION] Phase 3 completed successfully.')
        console.log('User A updated to version 2; stale update 412 verified.')
        console.log('>>> External owner action required: Codex stop PostgreSQL container for T11 outage (keep Go running). <<<')
        console.log('Run phase 4 once PostgreSQL is stopped.')
        return { ok: true, executedCases }
      }

      case 4: {
        // Phase 4: Outage, Recovery and Shutdown (T11a, T11b, T11c, W11, INT-PERS-03, INT-PERS-04, T12)
        console.log(`[DRIVER] Executing Phase 4 (Outage, Recovery & Shutdown) for runId ${this.runId}...`)
        if (!this.state.checkpointA) {
          throw new Error('Phase 4 error: Checkpoint A missing. Run phase 1 first.')
        }

        // T11a: GET User A during PG outage
        const t11aSteps = await this.dispatchCaseToHarness('T11a', this.state.checkpointA.id, harnessBaseUrl)
        this.persistEnvelope('T11a', t11aSteps)
        this.assertT11a(t11aSteps[0])
        executedCases.push('T11a')

        // T11b: PATCH User A during PG outage
        const t11bSteps = await this.dispatchCaseToHarness('T11b', this.state.checkpointA.id, harnessBaseUrl)
        this.persistEnvelope('T11b', t11bSteps)
        this.assertT11b(t11bSteps[0])
        executedCases.push('T11b')

        // T11c: POST User X during PG outage
        const t11cSteps = await this.dispatchCaseToHarness('T11c', undefined, harnessBaseUrl)
        this.persistEnvelope('T11c', t11cSteps)
        this.assertT11c(t11cSteps[0])
        executedCases.push('T11c')

        // W11: Wire GET User A during PG outage
        const w11Steps = await this.dispatchCaseToHarness('W11', this.state.checkpointA.id, harnessBaseUrl)
        this.persistEnvelope('W11', w11Steps)
        this.assertW11(w11Steps[0])
        executedCases.push('W11')

        console.log('\n[LIFECYCLE_COORDINATION] Outage cases asserted (T11a/b/c, W11).')
        console.log('>>> External owner action required: Codex restart PostgreSQL container without restarting Go. <<<')
        console.log('>>> Then ZCode stop Go binary for T12. <<<')

        // INT-PERS-03: Recovery readback
        const pers03Steps = await this.dispatchCaseToHarness('INT-PERS-03', this.state.checkpointA.id, harnessBaseUrl)
        this.persistEnvelope('INT-PERS-03', pers03Steps)
        this.assertPers03(pers03Steps[0])
        executedCases.push('INT-PERS-03')

        // INT-PERS-04: Read-only recovery
        const pers04Steps = await this.dispatchCaseToHarness('INT-PERS-04', this.state.checkpointA.id, harnessBaseUrl)
        this.persistEnvelope('INT-PERS-04', pers04Steps)
        this.assertPers04(pers04Steps[0])
        executedCases.push('INT-PERS-04')

        // T12: GET User A after Go stopped
        const t12Steps = await this.dispatchCaseToHarness('T12', this.state.checkpointA.id, harnessBaseUrl)
        this.persistEnvelope('T12', t12Steps)
        this.assertT12(t12Steps[0])
        executedCases.push('T12')

        this.state.phase = 'PHASE_4_COMPLETED'
        this.saveCheckpoint()

        console.log('\n[LIFECYCLE_COORDINATION] Phase 4 completed successfully.')
        console.log('All 36 logical IDs and procedure milestones completed.')
        return { ok: true, executedCases }
      }

      default:
        throw new Error(`Unknown phase number: ${phaseNum} (must be 1, 2, 3, or 4)`)
    }
  }
}

/**
 * CLI runner main function (F01).
 */
export async function main(argv: string[] = process.argv.slice(2)): Promise<void> {
  const args = argv
  const cmd = args[0] ?? 'help'

  if (cmd === 'help' || cmd === '--help' || cmd === '-h') {
    console.log('MC-002-INTA-FE Executable Phase Runner')
    console.log('Usage:')
    console.log('  node src/driver.ts phase1 [--runId=<id>] [--env-ready] [--state-dir=<dir>]')
    console.log('  node src/driver.ts phase2 [--runId=<id>] [--env-ready] [--state-dir=<dir>]')
    console.log('  node src/driver.ts phase3 [--runId=<id>] [--env-ready] [--state-dir=<dir>]')
    console.log('  node src/driver.ts phase4 [--runId=<id>] [--env-ready] [--state-dir=<dir>]')
    console.log('  node src/driver.ts status [--runId=<id>] [--state-dir=<dir>]')
    process.exit(0)
  }

  let runId: string | undefined
  let envReady = false
  let stateDir: string | undefined
  let harnessUrl: string | undefined

  for (const arg of args.slice(1)) {
    if (arg.startsWith('--runId=')) {
      runId = arg.slice(8)
    } else if (arg === '--env-ready') {
      envReady = true
    } else if (arg.startsWith('--state-dir=')) {
      stateDir = arg.slice(12)
    } else if (arg.startsWith('--harness-url=')) {
      harnessUrl = arg.slice(14)
    }
  }

  const allowResume = cmd !== 'phase1'
  const driver = new HarnessDriver(runId, stateDir, allowResume)

  if (cmd === 'status') {
    console.log('--- Harness Driver State ---')
    console.log(`runId: ${driver.runId}`)
    console.log(`phase: ${driver.state.phase}`)
    console.log(`checkpointA: ${JSON.stringify(driver.state.checkpointA)}`)
    console.log(`checkpointBId: ${driver.state.checkpointBId}`)
    console.log(`userXOutcome: ${driver.state.userXOutcome}`)
    console.log(`persistedEnvelopes: ${driver.state.envelopes.size}`)
    console.log(`assertions: ${driver.state.assertions.size}`)
    process.exit(0)
  }

  const phaseMatch = cmd.match(/^phase([1-4])$/)
  if (phaseMatch) {
    const phaseNum = parseInt(phaseMatch[1], 10)
    const result = await driver.runPhase(phaseNum, { envReady, harnessBaseUrl: harnessUrl })
    if (!result.ok) {
      process.exit(2) // Paused waiting env exit code
    }
    process.exit(0)
  }

  console.error(`Unknown command: ${cmd}. Run 'node src/driver.ts help' for usage.`)
  process.exit(1)
}

if (process.argv[1]) {
  try {
    const isMain = url.fileURLToPath(import.meta.url) === fs.realpathSync(process.argv[1])
    if (isMain) {
      main().catch((err) => {
        console.error('Fatal error in driver:', err)
        process.exit(1)
      })
    }
  } catch {}
}
