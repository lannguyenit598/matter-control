import type { NextConfig } from 'next'
import { validateHarnessStartup } from './src/guards'

// Startup guard (INTA-FE-R07):
// Refuses Next.js dev server startup before listening if environment is invalid or unsafe.
if (process.env.NODE_ENV !== 'test' && !process.env.VITEST) {
  validateHarnessStartup(process.env)
}

const nextConfig: NextConfig = {}

export default nextConfig
