import http from 'node:http'
import fs from 'node:fs'
import path from 'node:path'
import { spawn } from 'node:child_process'

const HARNESS_PORT = 18085
const UPSTREAM_PORT = 18086
const HARNESS_HOST = '127.0.0.1'
const HARNESS_BASE_URL = `http://${HARNESS_HOST}:${HARNESS_PORT}`

const RUN_ID = 'inta20261025a' // Valid 8-32 alphanumeric runId
const STATE_DIR = path.join(process.cwd(), '.run-state')
const PID_FILE = path.join(STATE_DIR, 'harness.pid')

fs.mkdirSync(STATE_DIR, { recursive: true })

interface GuardCheckResult {
  checkNum: number
  name: string
  method: string
  url: string
  payload?: any
  headers?: Record<string, string>
  expectedStatus: number | string
  actualStatus: number | string
  actualHeaders?: Record<string, string>
  actualBodyText: string
  parsedBody?: any
  pass: boolean
  failureReason?: string
}

async function waitForServer(url: string, timeoutMs = 15000): Promise<boolean> {
  const start = Date.now()
  while (Date.now() - start < timeoutMs) {
    try {
      const res = await fetch(url, { method: 'GET', cache: 'no-store' })
      if (res.status === 405 || res.status === 200 || res.status === 404) {
        return true
      }
    } catch {
      // Server not ready yet
    }
    await new Promise((r) => setTimeout(r, 200))
  }
  return false
}

async function isPortInUse(port: number): Promise<boolean> {
  return new Promise((resolve) => {
    const server = http.createServer()
    server.once('error', (err: any) => {
      if (err.code === 'EADDRINUSE') {
        resolve(true)
      } else {
        resolve(false)
      }
    })
    server.once('listening', () => {
      server.close(() => resolve(false))
    })
    server.listen(port, HARNESS_HOST)
  })
}

async function stopOwnedHarness(pid: number): Promise<void> {
  console.log(`[${new Date().toISOString()}] Sending SIGTERM to owned PID ${pid}...`)
  try {
    process.kill(pid, 'SIGTERM')
  } catch {
    // Already stopped
  }

  const start = Date.now()
  while (Date.now() - start < 5000) {
    try {
      process.kill(pid, 0)
      await new Promise((r) => setTimeout(r, 100))
    } catch {
      console.log(`[${new Date().toISOString()}] Owned PID ${pid} stopped gracefully.`)
      if (fs.existsSync(PID_FILE)) fs.unlinkSync(PID_FILE)
      return
    }
  }

  console.log(`[${new Date().toISOString()}] Owned PID ${pid} did not exit within 5s; sending SIGKILL...`)
  try {
    process.kill(pid, 'SIGKILL')
  } catch {}
  if (fs.existsSync(PID_FILE)) fs.unlinkSync(PID_FILE)
}

async function main() {
  console.log('='.repeat(80))
  console.log('MC-002-INTA-FE Authoritative Live Harness Guard Verification (R1)')
  console.log(`UTC Started: ${new Date().toISOString()}`)
  console.log(`Host: ${HARNESS_HOST}:${HARNESS_PORT}`)
  console.log(`Target runId: ${RUN_ID}`)
  console.log('='.repeat(80))

  // 1. Port conflict pre-check
  if (await isPortInUse(HARNESS_PORT)) {
    console.error(`FATAL: Port ${HARNESS_PORT} is already in use! Port conflict means STOP.`)
    process.exit(1)
  }
  if (await isPortInUse(UPSTREAM_PORT)) {
    console.error(`FATAL: Upstream port ${UPSTREAM_PORT} is already in use! Cannot start synthetic observer.`)
    process.exit(1)
  }

  // 2. Start pure synthetic upstream observer on 18086 to measure zero upstream calls
  console.log('\n--- Starting Synthetic Upstream Call Observer on 127.0.0.1:18086 ---')
  console.log('NOTE: Pure synthetic double for guard verification only — not real Go/PG.')
  let upstreamRequestsReceived = 0
  const upstreamServer = http.createServer((req, res) => {
    upstreamRequestsReceived++
    console.warn(`[UPSTREAM OBSERVER ALERT] Unexpected upstream call received: ${req.method} ${req.url}`)
    res.writeHead(500, { 'Content-Type': 'application/json' })
    res.end(JSON.stringify({ error: 'Unexpected upstream request during guard check' }))
  })
  await new Promise<void>((resolve) => upstreamServer.listen(UPSTREAM_PORT, HARNESS_HOST, () => resolve()))
  console.log(`Upstream observer listening on ${HARNESS_HOST}:${UPSTREAM_PORT}`)

  const results: GuardCheckResult[] = []

  // ============================================================================
  // Phase 1: Test Checks 1-5 with MC_INTA_ENABLE=1 (Default clean environment)
  // ============================================================================
  console.log('\n' + '='.repeat(80))
  console.log('=== Phase 1: Checks 1–5 with MC_INTA_ENABLE=1 (Enabled) ===')
  console.log('='.repeat(80))

  const envPhase1: Record<string, string | undefined> = {
    ...process.env,
    MC_INTA_ENABLE: '1',
    NODE_ENV: 'development',
    MC_INTA_GO_BASE_URL: `http://${HARNESS_HOST}:${UPSTREAM_PORT}`,
  }
  delete envPhase1.API_MODE
  delete envPhase1.API_TOKEN
  delete envPhase1.API_BASE_URL
  delete envPhase1.AUTH_ALLOW_ANONYMOUS
  delete envPhase1.AUTH_SECRET

  const nextBinary = path.join(process.cwd(), 'node_modules/.bin/next')
  const devProcess1 = spawn(nextBinary, ['dev', '-H', HARNESS_HOST, '-p', String(HARNESS_PORT), '--webpack'], {
    env: envPhase1 as NodeJS.ProcessEnv,
    cwd: process.cwd(),
    stdio: ['pipe', 'pipe', 'pipe'],
  })

  const pid1 = devProcess1.pid!
  fs.writeFileSync(PID_FILE, String(pid1), 'utf-8')
  console.log(`Next.js dev server spawned (PID ${pid1}) on ${HARNESS_HOST}:${HARNESS_PORT}`)

  devProcess1.stdout?.on('data', (d: Buffer) => {
    const s = d.toString()
    if (s.includes('Ready') || s.includes('Local:')) {
      console.log(`[Next Dev stdout]: ${s.trim()}`)
    }
  })
  devProcess1.stderr?.on('data', (d: Buffer) => {
    console.error(`[Next Dev stderr]: ${d.toString().trim()}`)
  })

  const ready1 = await waitForServer(`${HARNESS_BASE_URL}/harness/case`)
  if (!ready1) {
    console.error('FATAL: Harness dev server failed to become ready within timeout')
    await stopOwnedHarness(pid1)
    upstreamServer.close()
    process.exit(1)
  }
  console.log(`Harness server ready at ${HARNESS_BASE_URL}/harness/case`)

  // --- Check 1: GET /harness/case -> Expected 405 Method Not Allowed ---
  {
    console.log('\n--- Check 1: GET /harness/case -> Expected 405 Method Not Allowed ---')
    console.log(`curl -X GET "${HARNESS_BASE_URL}/harness/case"`)
    const res = await fetch(`${HARNESS_BASE_URL}/harness/case`, { method: 'GET', cache: 'no-store' })
    const bodyText = await res.text()
    let parsed: any = null
    try { parsed = JSON.parse(bodyText) } catch {}
    console.log(`HTTP Status: ${res.status} ${res.statusText}`)
    console.log(`Headers: cache-control=${res.headers.get('cache-control')}, allow=${res.headers.get('allow')}`)
    console.log(`Body: ${bodyText}`)

    const pass = res.status === 405 && parsed?.error === 'Method Not Allowed'
    console.log(`Computed Verdict: ${pass ? 'PASS' : 'FAIL'}`)
    results.push({
      checkNum: 1,
      name: 'GET method not allowed',
      method: 'GET',
      url: `${HARNESS_BASE_URL}/harness/case`,
      expectedStatus: 405,
      actualStatus: res.status,
      actualHeaders: Object.fromEntries(res.headers.entries()),
      actualBodyText: bodyText,
      parsedBody: parsed,
      pass,
    })
  }

  // --- Check 2: POST /harness/case with non-JSON body -> Expected 400 Bad Request ---
  {
    console.log('\n--- Check 2: POST /harness/case with non-JSON body -> Expected 400 Bad Request ---')
    console.log(`curl -X POST "${HARNESS_BASE_URL}/harness/case" -H "Content-Type: application/json" -d "this is not json"`)
    const res = await fetch(`${HARNESS_BASE_URL}/harness/case`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: 'this is not json',
      cache: 'no-store',
    })
    const bodyText = await res.text()
    let parsed: any = null
    try { parsed = JSON.parse(bodyText) } catch {}
    console.log(`HTTP Status: ${res.status} ${res.statusText}`)
    console.log(`Body: ${bodyText}`)

    const pass = res.status === 400 && parsed?.error === 'Invalid JSON body'
    console.log(`Computed Verdict: ${pass ? 'PASS' : 'FAIL'}`)
    results.push({
      checkNum: 2,
      name: 'Non-JSON body rejection',
      method: 'POST',
      url: `${HARNESS_BASE_URL}/harness/case`,
      payload: 'this is not json',
      expectedStatus: 400,
      actualStatus: res.status,
      actualHeaders: Object.fromEntries(res.headers.entries()),
      actualBodyText: bodyText,
      parsedBody: parsed,
      pass,
    })
  }

  // --- Check 3: POST /harness/case with valid runId and unknown caseId -> Expected 400 Bad Request ---
  {
    console.log('\n--- Check 3: POST /harness/case with valid runId and unknown caseId -> Expected 400 Bad Request ---')
    const payload = { runId: RUN_ID, caseId: 'UNKNOWN_99' }
    console.log(`curl -X POST "${HARNESS_BASE_URL}/harness/case" -H "Content-Type: application/json" -d '${JSON.stringify(payload)}'`)
    const res = await fetch(`${HARNESS_BASE_URL}/harness/case`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
      cache: 'no-store',
    })
    const bodyText = await res.text()
    let parsed: any = null
    try { parsed = JSON.parse(bodyText) } catch {}
    console.log(`HTTP Status: ${res.status} ${res.statusText}`)
    console.log(`Body: ${bodyText}`)

    const hasCaseIdIssue = parsed?.details?.some((d: any) => d.path?.includes('caseId'))
    const hasRunIdIssue = parsed?.details?.some((d: any) => d.path?.includes('runId'))
    const pass = res.status === 400 && Boolean(hasCaseIdIssue) && !hasRunIdIssue
    console.log(`Computed Verdict: ${pass ? 'PASS' : 'FAIL'} (hasCaseIdIssue=${hasCaseIdIssue}, noRunIdConfounding=${!hasRunIdIssue})`)
    results.push({
      checkNum: 3,
      name: 'Unknown caseId rejection without runId confounding',
      method: 'POST',
      url: `${HARNESS_BASE_URL}/harness/case`,
      payload,
      expectedStatus: 400,
      actualStatus: res.status,
      actualHeaders: Object.fromEntries(res.headers.entries()),
      actualBodyText: bodyText,
      parsedBody: parsed,
      pass,
    })
  }

  // --- Check 4: POST /harness/case with valid runId, valid caseId, and extra prohibited field -> Expected 400 Bad Request ---
  {
    console.log('\n--- Check 4: POST /harness/case with valid runId, valid caseId, and extra prohibited field -> Expected 400 Bad Request ---')
    const payload = { runId: RUN_ID, caseId: 'T1', prohibitedProxyField: 'malicious' }
    console.log(`curl -X POST "${HARNESS_BASE_URL}/harness/case" -H "Content-Type: application/json" -d '${JSON.stringify(payload)}'`)
    const res = await fetch(`${HARNESS_BASE_URL}/harness/case`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
      cache: 'no-store',
    })
    const bodyText = await res.text()
    let parsed: any = null
    try { parsed = JSON.parse(bodyText) } catch {}
    console.log(`HTTP Status: ${res.status} ${res.statusText}`)
    console.log(`Body: ${bodyText}`)

    const hasExtraFieldIssue = parsed?.details?.some((d: any) => d.message?.includes('prohibitedProxyField') || d.message?.includes('Unrecognized key'))
    const hasRunIdIssue = parsed?.details?.some((d: any) => d.path?.includes('runId'))
    const pass = res.status === 400 && Boolean(hasExtraFieldIssue) && !hasRunIdIssue
    console.log(`Computed Verdict: ${pass ? 'PASS' : 'FAIL'} (hasExtraFieldIssue=${hasExtraFieldIssue}, noRunIdConfounding=${!hasRunIdIssue})`)
    results.push({
      checkNum: 4,
      name: 'Extra prohibited field rejection without runId confounding',
      method: 'POST',
      url: `${HARNESS_BASE_URL}/harness/case`,
      payload,
      expectedStatus: 400,
      actualStatus: res.status,
      actualHeaders: Object.fromEntries(res.headers.entries()),
      actualBodyText: bodyText,
      parsedBody: parsed,
      pass,
    })
  }

  // --- Check 5: POST /harness/case with invalid runId pattern -> Expected 400 Bad Request ---
  {
    console.log('\n--- Check 5: POST /harness/case with invalid runId pattern -> Expected 400 Bad Request ---')
    const payload = { runId: 'bad_pattern!', caseId: 'T1' }
    console.log(`curl -X POST "${HARNESS_BASE_URL}/harness/case" -H "Content-Type: application/json" -d '${JSON.stringify(payload)}'`)
    const res = await fetch(`${HARNESS_BASE_URL}/harness/case`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
      cache: 'no-store',
    })
    const bodyText = await res.text()
    let parsed: any = null
    try { parsed = JSON.parse(bodyText) } catch {}
    console.log(`HTTP Status: ${res.status} ${res.statusText}`)
    console.log(`Body: ${bodyText}`)

    const hasRunIdIssue = parsed?.details?.some((d: any) => d.path?.includes('runId'))
    const hasCaseIdIssue = parsed?.details?.some((d: any) => d.path?.includes('caseId'))
    const pass = res.status === 400 && Boolean(hasRunIdIssue) && !hasCaseIdIssue
    console.log(`Computed Verdict: ${pass ? 'PASS' : 'FAIL'} (hasRunIdIssue=${hasRunIdIssue}, validCaseIdAccepted=${!hasCaseIdIssue})`)
    results.push({
      checkNum: 5,
      name: 'Invalid runId pattern rejection',
      method: 'POST',
      url: `${HARNESS_BASE_URL}/harness/case`,
      payload,
      expectedStatus: 400,
      actualStatus: res.status,
      actualHeaders: Object.fromEntries(res.headers.entries()),
      actualBodyText: bodyText,
      parsedBody: parsed,
      pass,
    })
  }

  // Stop Phase 1 process gracefully
  await stopOwnedHarness(pid1)

  // ============================================================================
  // Phase 2: Check 6 with MC_INTA_ENABLE unset (Disabled, Default) -> 404
  // ============================================================================
  console.log('\n' + '='.repeat(80))
  console.log('=== Phase 2: Check 6 without MC_INTA_ENABLE (Disabled, Default) ===')
  console.log('='.repeat(80))

  const envPhase2: Record<string, string | undefined> = {
    ...process.env,
    NODE_ENV: 'development',
    MC_INTA_GO_BASE_URL: `http://${HARNESS_HOST}:${UPSTREAM_PORT}`,
  }
  delete envPhase2.MC_INTA_ENABLE
  delete envPhase2.API_MODE

  const devProcess2 = spawn(nextBinary, ['dev', '-H', HARNESS_HOST, '-p', String(HARNESS_PORT), '--webpack'], {
    env: envPhase2 as NodeJS.ProcessEnv,
    cwd: process.cwd(),
    stdio: ['pipe', 'pipe', 'pipe'],
  })

  const pid2 = devProcess2.pid!
  fs.writeFileSync(PID_FILE, String(pid2), 'utf-8')
  console.log(`Next.js dev server spawned without MC_INTA_ENABLE (PID ${pid2})`)

  const ready2 = await waitForServer(`${HARNESS_BASE_URL}/harness/case`)
  if (!ready2) {
    console.error('FATAL: Phase 2 server failed to become ready')
    await stopOwnedHarness(pid2)
    upstreamServer.close()
    process.exit(1)
  }

  {
    console.log('\n--- Check 6: POST /harness/case when disabled -> Expected 404 Not Found ---')
    const payload = { runId: RUN_ID, caseId: 'T1' }
    console.log(`curl -X POST "${HARNESS_BASE_URL}/harness/case" -H "Content-Type: application/json" -d '${JSON.stringify(payload)}'`)
    const res = await fetch(`${HARNESS_BASE_URL}/harness/case`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
      cache: 'no-store',
    })
    const bodyText = await res.text()
    let parsed: any = null
    try { parsed = JSON.parse(bodyText) } catch {}
    console.log(`HTTP Status: ${res.status} ${res.statusText}`)
    console.log(`Body: ${bodyText}`)

    const pass = res.status === 404 && parsed?.error?.includes('MC_INTA_ENABLE=1 is required')
    console.log(`Computed Verdict: ${pass ? 'PASS' : 'FAIL'}`)
    results.push({
      checkNum: 6,
      name: 'Opt-in flag missing 404 refusal',
      method: 'POST',
      url: `${HARNESS_BASE_URL}/harness/case`,
      payload,
      expectedStatus: 404,
      actualStatus: res.status,
      actualHeaders: Object.fromEntries(res.headers.entries()),
      actualBodyText: bodyText,
      parsedBody: parsed,
      pass,
    })
  }

  // Stop Phase 2 process gracefully
  await stopOwnedHarness(pid2)

  // ============================================================================
  // Phase 3: Check 7 with Prohibited Product Auth Env -> Startup Refusal (INTA-FE-R07)
  // ============================================================================
  console.log('\n' + '='.repeat(80))
  console.log('=== Phase 3: Check 7 Startup Refusal with Product Auth Env (INTA-FE-R07) ===')
  console.log('='.repeat(80))

  const envPhase3: Record<string, string | undefined> = {
    ...process.env,
    MC_INTA_ENABLE: '1',
    API_MODE: 'demo', // Prohibited product auth key
    NODE_ENV: 'development',
    MC_INTA_GO_BASE_URL: `http://${HARNESS_HOST}:${UPSTREAM_PORT}`,
  }

  console.log('Attempting to boot Next.js dev server with API_MODE=demo...')
  console.log(`argv: ${nextBinary} dev -H ${HARNESS_HOST} -p ${HARNESS_PORT} --webpack`)

  let startupStderr = ''
  let startupExitCode: number | null = null

  const devProcess3 = spawn(nextBinary, ['dev', '-H', HARNESS_HOST, '-p', String(HARNESS_PORT), '--webpack'], {
    env: envPhase3 as NodeJS.ProcessEnv,
    cwd: process.cwd(),
    stdio: ['pipe', 'pipe', 'pipe'],
  })

  devProcess3.stderr?.on('data', (d: Buffer) => {
    startupStderr += d.toString()
  })

  await new Promise<void>((resolve) => {
    devProcess3.on('exit', (code) => {
      startupExitCode = code
      resolve()
    })
    // Safety timeout: if it didn't exit within 5s, it unexpectedly booted
    setTimeout(() => resolve(), 5000)
  })

  console.log(`Process Exit Code: ${startupExitCode}`)
  console.log(`Process stderr: ${startupStderr.trim()}`)

  // Verify that port 18085 was never opened
  const port18085NeverOpened = !(await isPortInUse(HARNESS_PORT))
  console.log(`Port ${HARNESS_PORT} remained closed: ${port18085NeverOpened}`)

  const startupRefusalPassed =
    startupExitCode !== 0 &&
    startupStderr.includes('product auth/secret env vars present (API_MODE)') &&
    port18085NeverOpened

  console.log(`Computed Verdict: ${startupRefusalPassed ? 'PASS' : 'FAIL'}`)
  results.push({
    checkNum: 7,
    name: 'Startup refusal before listen on product auth env (INTA-FE-R07)',
    method: 'STARTUP_EXECUTION',
    url: `${HARNESS_BASE_URL}/harness/case`,
    payload: { env: 'API_MODE=demo' },
    expectedStatus: 'EXIT_NONZERO_BEFORE_LISTEN',
    actualStatus: `EXIT_${startupExitCode}`,
    actualBodyText: startupStderr.trim(),
    pass: startupRefusalPassed,
  })

  // Close upstream observer
  upstreamServer.close()

  // ============================================================================
  // Summary & Zero Upstream Assertion
  // ============================================================================
  console.log('\n' + '='.repeat(80))
  console.log('MC-002-INTA-FE Authoritative Guard Verification Summary')
  console.log('='.repeat(80))

  let allChecksPassed = true
  for (const r of results) {
    console.log(`Check ${r.checkNum}: [${r.pass ? 'PASS' : 'FAIL'}] ${r.name} (Expected ${r.expectedStatus}, got ${r.actualStatus})`)
    if (!r.pass) allChecksPassed = false
  }

  console.log('\n--- Measured Upstream Calls ---')
  console.log(`Total HTTP requests received by synthetic upstream observer (127.0.0.1:${UPSTREAM_PORT}): ${upstreamRequestsReceived}`)
  const zeroUpstreamPassed = upstreamRequestsReceived === 0
  console.log(`Zero Upstream Assertion: ${zeroUpstreamPassed ? 'PASS' : 'FAIL'}`)

  // Final verification that port 18085 is completely closed
  const port18085Closed = !(await isPortInUse(HARNESS_PORT))
  console.log(`Port ${HARNESS_PORT} closed verification: ${port18085Closed ? 'PASS' : 'FAIL'}`)

  if (allChecksPassed && zeroUpstreamPassed && port18085Closed) {
    console.log('\nOVERALL RESULT: 7/7 LIVE GUARD CHECKS PASS + ZERO UPSTREAM CALLS MEASURED')
    console.log(`UTC Completed: ${new Date().toISOString()}`)
    process.exit(0)
  } else {
    console.error('\nOVERALL RESULT: FAILED GUARD VERIFICATION')
    console.log(`UTC Completed: ${new Date().toISOString()}`)
    process.exit(1)
  }
}

main().catch((err) => {
  console.error('Unhandled fatal error in live-guards:', err)
  process.exit(1)
})
