#!/usr/bin/env bash
# ==============================================================================
# MC-002-INTA-FE — Owned Process Graceful Stop Script (INTA-FE-R08)
# Stop ONLY the exact recorded owned PID from .run-state/harness.pid.
# NEVER kill by port, never use lsof/xargs kill, never killall.
# ==============================================================================
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
HARNESS_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"
PID_FILE="${HARNESS_ROOT}/.run-state/harness.pid"

echo "[$(date -u +"%Y-%m-%dT%H:%M:%SZ")] Stopping owned harness process..."

if [[ ! -f "${PID_FILE}" ]]; then
  echo "[$(date -u +"%Y-%m-%dT%H:%M:%SZ")] No PID file found at ${PID_FILE}. Harness process is not running or already stopped."
  exit 0
fi

TARGET_PID="$(cat "${PID_FILE}" | tr -d '[:space:]')"

if [[ -z "${TARGET_PID}" ]]; then
  echo "[$(date -u +"%Y-%m-%dT%H:%M:%SZ")] PID file was empty. Removing ${PID_FILE}."
  rm -f "${PID_FILE}"
  exit 0
fi

# Verify process is running
if ! kill -0 "${TARGET_PID}" 2>/dev/null; then
  echo "[$(date -u +"%Y-%m-%dT%H:%M:%SZ")] Process ${TARGET_PID} is not running. Stale PID file removed."
  rm -f "${PID_FILE}"
  exit 0
fi

echo "[$(date -u +"%Y-%m-%dT%H:%M:%SZ")] Sending SIGTERM to owned PID ${TARGET_PID}..."
kill -TERM "${TARGET_PID}" || true

# Wait up to 5 seconds for graceful exit
WAITED=0
while kill -0 "${TARGET_PID}" 2>/dev/null && [ ${WAITED} -lt 50 ]; do
  sleep 0.1
  WAITED=$((WAITED + 1))
done

if kill -0 "${TARGET_PID}" 2>/dev/null; then
  echo "[$(date -u +"%Y-%m-%dT%H:%M:%SZ")] Process ${TARGET_PID} did not stop gracefully within 5s. Sending SIGKILL to owned PID..."
  kill -KILL "${TARGET_PID}" || true
  sleep 0.2
else
  echo "[$(date -u +"%Y-%m-%dT%H:%M:%SZ")] Process ${TARGET_PID} stopped gracefully."
fi

rm -f "${PID_FILE}"
echo "[$(date -u +"%Y-%m-%dT%H:%M:%SZ")] Stopped owned PID ${TARGET_PID}. PID file removed."
exit 0
