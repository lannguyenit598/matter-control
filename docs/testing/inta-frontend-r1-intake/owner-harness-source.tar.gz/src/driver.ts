import fs from 'node:fs'
import path from 'node:path'
import { execSync } from 'node:child_process'
import {
  ALLOWED_CASE_IDS,
  type CaseId,
  REF_ID_REQUIRED_CASE_IDS,
  REF_ID_FORBIDDEN_CASE_IDS,
} from './schemas'
import type { HarnessEnvelope } from './envelope'

export interface CheckpointUserA {
  id: string
  email: string
  name: string
  version: number
  created_at: string
  updated_at: string
}

export interface DriverState {
  runId: string
  phase: string
  checkpointA: CheckpointUserA | null
  checkpointBId: string | null
  userXOutcome: 'OUTCOME_UNKNOWN' | null
  envelopes: Map<string, HarnessEnvelope[]>
  assertions: Map<string, { pass: boolean; notes: string; blocked?: boolean }>
}

export const CANONICAL_36_LOGICAL_IDS = [
  'INT-ENV-01',
  'INT-ENV-02',
  'INT-ENV-03',
  'INT-ENV-04',
  'INT-ENV-05',
  'INT-ENV-06',
  'INT-ENV-07',
  'T1',
  'T2',
  'W1',
  'W2',
  'T3',
  'T4',
  'T5',
  'T8',
  'W3',
  'T6-W',
  'T7-W',
  'INT-PERS-01',
  'INT-PERS-02',
  'T9',
  'W9',
  'T10',
  'T11a',
  'T11b',
  'T11c',
  'W11',
  'INT-PERS-03',
  'INT-PERS-04',
  'T12',
  'INT-COR-01',
  'INT-PRIV-01',
  'INT-ISO-01',
  'INT-ISO-02',
  'INT-ISO-03',
  'INT-CONF-01',
] as const

export type LogicalTestId = (typeof CANONICAL_36_LOGICAL_IDS)[number]

/**
 * Validates that an alphanumeric runId is 8-32 characters.
 */
export function validateRunId(runId: string): boolean {
  return /^[a-zA-Z0-9]{8,32}$/.test(runId)
}

/**
 * Generates an alphanumeric runId between 8 and 32 characters.
 */
export function generateRunId(prefix = 'inta'): string {
  const ts = Date.now().toString(36)
  const rand = Math.floor(Math.random() * 10000).toString(36)
  const runId = `${prefix}${ts}${rand}`.toLowerCase()
  if (runId.length < 8) {
    return runId.padEnd(8, '0')
  }
  if (runId.length > 32) {
    return runId.slice(0, 32)
  }
  return runId
}

/**
 * Refuses execution if runId collides with existing owned evidence, containers or state.
 */
export function assertNoRunIdCollision(
  runId: string,
  evidenceBaseDir = '/tmp/mc002-inta-evidence',
  stateBaseDir = path.join(process.cwd(), '.run-state'),
): void {
  if (!validateRunId(runId)) {
    throw new Error(`Invalid runId format (must be 8-32 alphanumeric): ${runId}`)
  }

  // 1. Check existing evidence directories
  const evidenceCheckDirs = [
    path.join(evidenceBaseDir, 'frontend', runId),
    path.join(evidenceBaseDir, 'backend', runId),
    path.join(evidenceBaseDir, 'environment', runId),
    path.join(evidenceBaseDir, 'qa', runId),
  ]
  for (const dir of evidenceCheckDirs) {
    if (fs.existsSync(dir)) {
      throw new Error(`RunId collision refused: existing evidence found at ${dir}`)
    }
  }

  // 2. Check local run state
  const stateCheckFiles = [
    path.join(stateBaseDir, `counters-${runId}.json`),
    path.join(stateBaseDir, 'envelopes', runId),
  ]
  for (const p of stateCheckFiles) {
    if (fs.existsSync(p)) {
      throw new Error(`RunId collision refused: existing run state found at ${p}`)
    }
  }

  // 3. Check for existing docker container mc002-inta-pg-<runId> if docker is available
  try {
    const containerName = `mc002-inta-pg-${runId}`
    const out = execSync(`docker ps -a --filter name=${containerName} --format "{{.Names}}"`, {
      encoding: 'utf-8',
      stdio: ['ignore', 'pipe', 'ignore'],
    }).trim()
    if (out.includes(containerName)) {
      throw new Error(`RunId collision refused: existing Docker container found: ${containerName}`)
    }
  } catch (err: any) {
    if (err.message?.includes('RunId collision refused')) {
      throw err
    }
    // Docker command not present / accessible; continue
  }
}

/**
 * RFC 3339 UTC timestamp check with 0-6 fraction digits.
 */
export const RFC3339_UTC_REGEX =
  /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d{1,6})?Z$/

/**
 * Canonical lowercase UUIDv7 check.
 */
export const UUID_LOWERCASE_REGEX =
  /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/

export class HarnessDriver {
  public readonly runId: string
  public readonly stateDir: string
  public readonly envelopeDir: string
  public state: DriverState

  constructor(runId?: string, stateDir?: string) {
    this.runId = runId ?? generateRunId()
    assertNoRunIdCollision(this.runId)

    this.stateDir = stateDir ?? path.join(process.cwd(), '.run-state')
    this.envelopeDir = path.join(this.stateDir, 'envelopes', this.runId)
    fs.mkdirSync(this.envelopeDir, { recursive: true })

    this.state = {
      runId: this.runId,
      phase: 'INITIALIZED',
      checkpointA: null,
      checkpointBId: null,
      userXOutcome: null,
      envelopes: new Map(),
      assertions: new Map(),
    }
  }

  /**
   * Persists an envelope to disk for auditability and compliance.
   */
  public persistEnvelope(caseId: string, envelopes: HarnessEnvelope[]): void {
    this.state.envelopes.set(caseId, envelopes)
    const outPath = path.join(this.envelopeDir, `${caseId}.json`)
    fs.writeFileSync(outPath, JSON.stringify(envelopes, null, 2), 'utf-8')
  }

  /**
   * Records an assertion result. If truncated evidence is detected, blocks body/equality assertions.
   */
  public recordAssertion(
    caseId: string,
    pass: boolean,
    notes: string,
    truncated = false,
  ): void {
    if (truncated) {
      this.state.assertions.set(caseId, {
        pass: false,
        blocked: true,
        notes: `BLOCKED: Body truncated (>16KiB cap) — cannot establish assertion (${notes})`,
      })
      return
    }
    this.state.assertions.set(caseId, { pass, notes })
  }

  /**
   * Asserts User A created state in T1 and saves immutable checkpoint.
   */
  public assertT1(envelope: HarnessEnvelope): CheckpointUserA {
    if (envelope.truncated) {
      this.recordAssertion('T1', false, 'Envelope body truncated', true)
      throw new Error('T1 assertion blocked: envelope body was truncated')
    }

    if (envelope.outcome !== 'value' || !envelope.value) {
      this.recordAssertion('T1', false, `Expected outcome value, got ${envelope.outcome}`)
      throw new Error(`T1 failed: unexpected outcome ${envelope.outcome}`)
    }

    const val = envelope.value as any
    if (!UUID_LOWERCASE_REGEX.test(val.id)) {
      this.recordAssertion('T1', false, `Invalid User A id format: ${val.id}`)
      throw new Error(`T1 failed: invalid User A id format: ${val.id}`)
    }

    if (val.version !== 1) {
      this.recordAssertion('T1', false, `Expected version 1, got ${val.version}`)
      throw new Error(`T1 failed: expected version 1, got ${val.version}`)
    }

    if (!RFC3339_UTC_REGEX.test(val.created_at)) {
      this.recordAssertion('T1', false, `Invalid created_at RFC 3339: ${val.created_at}`)
      throw new Error(`T1 failed: invalid created_at RFC 3339 UTC: ${val.created_at}`)
    }

    if (!RFC3339_UTC_REGEX.test(val.updated_at)) {
      this.recordAssertion('T1', false, `Invalid updated_at RFC 3339: ${val.updated_at}`)
      throw new Error(`T1 failed: invalid updated_at RFC 3339 UTC: ${val.updated_at}`)
    }

    this.state.checkpointA = {
      id: val.id,
      email: val.email,
      name: val.name,
      version: val.version,
      created_at: val.created_at,
      updated_at: val.updated_at,
    }

    this.recordAssertion('T1', true, 'User A created with version 1, valid UUID and RFC 3339 UTC timestamps')
    return this.state.checkpointA
  }

  /**
   * Asserts T2 readback matches T1 checkpoint field-for-field.
   */
  public assertT2(envelope: HarnessEnvelope): void {
    if (!this.state.checkpointA) {
      throw new Error('T2 assertion error: Checkpoint A missing')
    }
    if (envelope.truncated) {
      this.recordAssertion('T2', false, 'Envelope body truncated', true)
      throw new Error('T2 assertion blocked: envelope body was truncated')
    }

    const val = envelope.value as any
    const cp = this.state.checkpointA

    const match =
      val.id === cp.id &&
      val.email === cp.email &&
      val.name === cp.name &&
      val.version === cp.version &&
      val.created_at === cp.created_at &&
      val.updated_at === cp.updated_at

    if (!match) {
      this.recordAssertion('T2', false, 'T2 readback does not match T1 checkpoint field-for-field')
      throw new Error('T2 failed: readback mismatch vs checkpoint A')
    }

    this.recordAssertion('T2', true, 'T2 readback matches T1 checkpoint field-for-field')
  }

  /**
   * Pauses safely before any upstream action until Codex ENV handoff and owner readiness.
   */
  public pauseForUpstreamCoordination(envReady: boolean): void {
    if (!envReady) {
      this.state.phase = 'PAUSED_WAITING_ENV'
      return
    }
    this.state.phase = 'ENV_COORDINATED_READY'
  }
}
