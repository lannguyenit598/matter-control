import fs from 'node:fs'
import path from 'node:path'

export interface RequestIdGeneratorOptions {
  stateDir?: string
  initialSeq?: number
}

/**
 * Deterministic Request ID generator conforming to INTA-1 §3 and INTA-FE-R03.
 *
 * Emits IDs matching: mc-int-<runId>-<caseId>-<seq>
 * Total length <= 128 safe characters.
 *
 * Persists counter per runId in run-local storage (.run-state/counters.json)
 * so counters never reset on process restarts, dev module reloads, or runId switching.
 */
export class RequestIdGenerator {
  private seq: number
  private stateDir: string | null
  private stateFile: string | null

  constructor(
    public readonly runId: string,
    options?: RequestIdGeneratorOptions,
  ) {
    if (!/^[a-zA-Z0-9_-]{8,32}$/.test(runId)) {
      throw new Error(`Invalid runId format for RequestIdGenerator: ${runId}`)
    }

    this.stateDir =
      options?.stateDir ??
      process.env.MC_INTA_STATE_DIR ??
      path.join(process.cwd(), '.run-state')

    if (this.stateDir) {
      try {
        fs.mkdirSync(this.stateDir, { recursive: true })
        this.stateFile = path.join(this.stateDir, 'counters.json')
      } catch {
        this.stateFile = null
      }
    } else {
      this.stateFile = null
    }

    if (options?.initialSeq !== undefined) {
      this.seq = options.initialSeq
    } else {
      this.seq = this.loadPersistedSeq()
    }
  }

  private loadPersistedSeq(): number {
    if (!this.stateFile || !fs.existsSync(this.stateFile)) {
      return 0
    }
    try {
      const content = fs.readFileSync(this.stateFile, 'utf-8')
      const data = JSON.parse(content)
      return typeof data[this.runId] === 'number' ? data[this.runId] : 0
    } catch {
      return 0
    }
  }

  private persistSeq(seq: number): void {
    if (!this.stateFile) return
    try {
      let data: Record<string, number> = {}
      if (fs.existsSync(this.stateFile)) {
        try {
          data = JSON.parse(fs.readFileSync(this.stateFile, 'utf-8'))
        } catch {
          data = {}
        }
      }
      data[this.runId] = seq
      fs.writeFileSync(this.stateFile, JSON.stringify(data, null, 2), 'utf-8')
    } catch {
      // Ignore write failures in read-only / mock environments
    }
  }

  public currentSeq(): number {
    return this.seq
  }

  public next(caseId: string): string {
    this.seq += 1
    this.persistSeq(this.seq)

    const id = `mc-int-${this.runId}-${caseId}-${this.seq}`
    if (id.length > 128) {
      throw new Error(`RequestId exceeds 128 characters: ${id}`)
    }
    if (!/^[a-zA-Z0-9_-]+$/.test(id)) {
      throw new Error(`RequestId contains invalid characters: ${id}`)
    }
    return id
  }
}
