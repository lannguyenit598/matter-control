import { describe, expect, it, beforeEach, afterEach } from 'vitest'
import fs from 'node:fs'
import path from 'node:path'
import {
  HarnessDriver,
  generateRunId,
  validateRunId,
  assertNoRunIdCollision,
  CANONICAL_36_LOGICAL_IDS,
} from '../src/driver.js'
import type { HarnessEnvelope } from '../src/envelope.js'

describe('HarnessDriver (INTA-FE-R02)', () => {
  const testStateDir = path.join(process.cwd(), '.test-driver-state')
  const testEvidenceDir = path.join(process.cwd(), '.test-driver-evidence')

  beforeEach(() => {
    fs.mkdirSync(testStateDir, { recursive: true })
    fs.mkdirSync(testEvidenceDir, { recursive: true })
  })

  afterEach(() => {
    try {
      fs.rmSync(testStateDir, { recursive: true, force: true })
      fs.rmSync(testEvidenceDir, { recursive: true, force: true })
    } catch {}
  })

  it('generates valid 8-32 alphanumeric runId', () => {
    const runId = generateRunId()
    expect(validateRunId(runId)).toBe(true)
    expect(runId.length).toBeGreaterThanOrEqual(8)
    expect(runId.length).toBeLessThanOrEqual(32)
    expect(/^[a-zA-Z0-9]+$/.test(runId)).toBe(true)
  })

  it('refuses collision when evidence folder for runId already exists (R02)', () => {
    const existingRunId = 'existingrun1234'
    const collisionDir = path.join(testEvidenceDir, 'frontend', existingRunId)
    fs.mkdirSync(collisionDir, { recursive: true })

    expect(() =>
      assertNoRunIdCollision(existingRunId, testEvidenceDir, testStateDir),
    ).toThrow(/RunId collision refused: existing evidence found/)
  })

  it('contains all 36 required canonical logical IDs', () => {
    expect(CANONICAL_36_LOGICAL_IDS).toHaveLength(36)
    // Check key required IDs
    expect(CANONICAL_36_LOGICAL_IDS).toContain('INT-ENV-01')
    expect(CANONICAL_36_LOGICAL_IDS).toContain('INT-ENV-05')
    expect(CANONICAL_36_LOGICAL_IDS).toContain('INT-ENV-06')
    expect(CANONICAL_36_LOGICAL_IDS).toContain('INT-ENV-07')
    expect(CANONICAL_36_LOGICAL_IDS).toContain('T1')
    expect(CANONICAL_36_LOGICAL_IDS).toContain('T2')
    expect(CANONICAL_36_LOGICAL_IDS).toContain('T5')
    expect(CANONICAL_36_LOGICAL_IDS).toContain('T8')
    expect(CANONICAL_36_LOGICAL_IDS).toContain('T9')
    expect(CANONICAL_36_LOGICAL_IDS).toContain('T10')
    expect(CANONICAL_36_LOGICAL_IDS).toContain('T11a')
    expect(CANONICAL_36_LOGICAL_IDS).toContain('T11b')
    expect(CANONICAL_36_LOGICAL_IDS).toContain('T11c')
    expect(CANONICAL_36_LOGICAL_IDS).toContain('T12')
    expect(CANONICAL_36_LOGICAL_IDS).toContain('W1')
    expect(CANONICAL_36_LOGICAL_IDS).toContain('W9')
    expect(CANONICAL_36_LOGICAL_IDS).toContain('W11')
    expect(CANONICAL_36_LOGICAL_IDS).toContain('INT-PERS-01')
    expect(CANONICAL_36_LOGICAL_IDS).toContain('INT-PERS-02')
    expect(CANONICAL_36_LOGICAL_IDS).toContain('INT-PERS-03')
    expect(CANONICAL_36_LOGICAL_IDS).toContain('INT-PERS-04')
    expect(CANONICAL_36_LOGICAL_IDS).toContain('INT-COR-01')
    expect(CANONICAL_36_LOGICAL_IDS).toContain('INT-PRIV-01')
    expect(CANONICAL_36_LOGICAL_IDS).toContain('INT-ISO-01')
    expect(CANONICAL_36_LOGICAL_IDS).toContain('INT-ISO-02')
    expect(CANONICAL_36_LOGICAL_IDS).toContain('INT-ISO-03')
    expect(CANONICAL_36_LOGICAL_IDS).toContain('INT-CONF-01')
  })

  it('records Checkpoint A from valid T1 envelope and verifies RFC 3339 UTC timestamps (R01, R02)', () => {
    const driver = new HarnessDriver('drivertest123', testStateDir)
    const validT1Envelope: HarnessEnvelope = {
      runId: 'drivertest123',
      caseId: 'T1',
      requestId: 'mc-int-drivertest123-T1-1',
      mode: 'app-client',
      method: 'POST',
      routeTemplate: '/api/v1/users',
      startedAtUTC: '2026-10-25T03:00:00Z',
      latencyMs: 15,
      actualNextVersion: '16.4.2',
      harnessRevision: 'e25bbc6933264fc46a729e6a364a3bfa02d8038f',
      outcome: 'value',
      classification: 'success',
      value: {
        id: '0192e23b-6e9f-7b71-91ea-42b7e199db1c',
        email: 'inta-a-drivertest123@example.test',
        name: 'INTA_A_INITIAL',
        version: 1,
        created_at: '2026-10-25T03:00:00.123456Z',
        updated_at: '2026-10-25T03:00:00.123456Z',
      },
      apiError: null,
      wire: null,
      truncated: false,
    }

    const cp = driver.assertT1(validT1Envelope)
    expect(cp.id).toBe('0192e23b-6e9f-7b71-91ea-42b7e199db1c')
    expect(cp.version).toBe(1)
    expect(driver.state.assertions.get('T1')?.pass).toBe(true)

    // T2 assertion
    const validT2Envelope: HarnessEnvelope = {
      ...validT1Envelope,
      caseId: 'T2',
      requestId: 'mc-int-drivertest123-T2-1',
      method: 'GET',
      routeTemplate: '/api/v1/users/{id}',
    }
    expect(() => driver.assertT2(validT2Envelope)).not.toThrow()
    expect(driver.state.assertions.get('T2')?.pass).toBe(true)
  })

  it('blocks assertion acceptance when evidence is truncated (R05)', () => {
    const driver = new HarnessDriver('truncatetest1', testStateDir)
    const truncatedEnvelope: HarnessEnvelope = {
      runId: 'truncatetest1',
      caseId: 'T1',
      requestId: 'mc-int-truncatetest1-T1-1',
      mode: 'app-client',
      method: 'POST',
      routeTemplate: '/api/v1/users',
      startedAtUTC: '2026-10-25T03:00:00Z',
      latencyMs: 15,
      actualNextVersion: '16.4.2',
      harnessRevision: 'e25bbc6933264fc46a729e6a364a3bfa02d8038f',
      outcome: 'value',
      classification: 'success',
      value: 'truncated-string-content',
      apiError: null,
      wire: null,
      truncated: true,
    }

    expect(() => driver.assertT1(truncatedEnvelope)).toThrow(/T1 assertion blocked: envelope body was truncated/)
    expect(driver.state.assertions.get('T1')?.blocked).toBe(true)
  })

  it('pauses safely for upstream coordination before execution', () => {
    const driver = new HarnessDriver('pausetest123', testStateDir)
    driver.pauseForUpstreamCoordination(false)
    expect(driver.state.phase).toBe('PAUSED_WAITING_ENV')

    driver.pauseForUpstreamCoordination(true)
    expect(driver.state.phase).toBe('ENV_COORDINATED_READY')
  })
})
